package Common.Machine;

public enum ToolType {
    T1(30),
    T2(30),
    T3(30),
    T4(30);

    private final int timeToSwitchToTool;

    ToolType(int timeToSwitchToTool) {
        this.timeToSwitchToTool = timeToSwitchToTool;
    }

    public int getTimeTimeToSwitchToTool() {
        return this.timeToSwitchToTool;
    }

    public int toInt() {
        switch (this) {
            case T1:
                return 1;
            case T2:
                return 2;
            case T3:
                return 3;
            case T4:
                return 4;
            default:
                throw new IllegalStateException("Unhandled ToolType: " + this);
        }
    }

    public int maxPiecesForTools() {
        switch (this) {
            case T1:
                return 3;
            case T2:
                return 2;
            case T3:
                return 4;
            case T4:
                return 3;
            default:
                throw new IllegalStateException("Unhandled ToolType: " + this);
        }
    }
}