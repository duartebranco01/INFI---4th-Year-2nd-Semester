package Erp.Main;

import java.io.IOException;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import Erp.Gui.DayGUI;
import Erp.Gui.HelloApplication;
import Erp.Gui.OrderCostGUI;
import Erp.Gui.PurchasingPlanGUI;
import MasterProductionPlan.Day;
import MasterProductionPlan.*;
import Products.Warehouse;
import Common.Communication.SQL.DeleteDataFromTables;
import Common.Communication.SQL.InsertIntoTablesERP;
import Common.Communication.Tcp.*;
import Common.Communication.Udp.*;
import Common.Machine.Machine;
import Common.Machine.ToolType;
import Common.Piece.Piece;
import Common.Piece.PieceType;
import Erp.OrderInfo.OrderInfo;
import Erp.OrderInfo.PieceCost;
import Erp.OrderInfo.XmlParser;
import Common.Constants.*;
import Common.TimeCounting.*;

public class ErpMain {

    static int lastDaySent = -1;

    static UdpServer recieveOrderUdpServer;
    static TcpClient sendToMesTcpClient;
    static TcpClient sendInitTimeTcpClient;
    static UdpClient erpUdpClient;

    static NewMasterProductionSchedule masterProductionProductionSchedule;

    static XmlParser xmlFileParser;
    static TimeCounting dayCounter;
    static ArrayList<OrderInfo> orderList;

    static Day testDay1 = Day.produceT7_test();

    // static ArrayList<Day> dayListToGUI;

    static ArrayList<OrderCostGUI> orderCostGUIs = new ArrayList<OrderCostGUI>();

    static void recieveAndPlanOrder() {

        String incoming = recieveOrderUdpServer.popLeastRecent();
        if (null != incoming) {
            try {
                xmlFileParser.readXml(incoming);
            } catch (Exception e) {
                System.out.println("Error parsing XML");
            }
            ArrayList<OrderInfo> receivedOrders = xmlFileParser.createOrderInfo();
            if (null != receivedOrders) {
                // System.out.println(receivedOrders);
                receivedOrders = OrderSort.orderOrdersByMachiningTime(receivedOrders);
                masterProductionProductionSchedule.setCurrDay(dayCounter.getDay());
                masterProductionProductionSchedule.setCurrTime(dayCounter.getDayTime());
                for (OrderInfo order : receivedOrders) {
                    try {
                        if (true == masterProductionProductionSchedule.addNewOrderAndPlan(order)) {

                            ArrayList<Day> dayListToGUI = masterProductionProductionSchedule.getDayList();
                            int orderCost = calculateCostOfOrder(dayListToGUI, order.getNumber(), order.getLatePen());
                            OrderCostGUI orderCostGUI = new OrderCostGUI(order.getNumber(), orderCost);
                            orderCostGUIs.add(orderCostGUI);

                            InsertIntoTablesERP insertIntoTablesERP = new InsertIntoTablesERP();
                            insertIntoTablesERP.addOrderCost(orderCostGUIs);
                            insertIntoTablesERP.addProductionPlan(DayGUI.createDayGUIList(dayListToGUI));
                            insertIntoTablesERP
                                    .addPurchasingPlan(PurchasingPlanGUI.createPurchasingPlanGUIList(dayListToGUI));
                            insertIntoTablesERP.addOrderStatusERP(order.getNumber(), order.getQuantity(),
                                    calculateFinishedDate(dayListToGUI, order.getNumber()) * 60, "Pending", 0,
                                    order.getQuantity());

                        }
                    } catch (Exception e) {
                        System.out.println("Error inserting new order in the schedule");
                        e.printStackTrace();
                    }
                }
            }
        }

    }

    static int calculateFinishedDate(ArrayList<Day> dayList, int orderId) {

        int finishedDate = -1;

        for (Day currDay : dayList) {
            ArrayList<Activity> activities = currDay.getDayActivityList();

            for (Activity currActivity : activities) {

                if (currActivity instanceof ActivityUnloading && currActivity.getOrderId() == orderId) {
                    ActivityUnloading activityUnloading = (ActivityUnloading) currActivity;
                    finishedDate = activityUnloading.getDay();
                }
            }
        }
        return finishedDate;

    }

    static int calculateCostOfOrder(ArrayList<Day> dayList, int orderId, int latePen) {
        int cost = 0;

        boolean addLateCost = true;

        for (Day currDay : dayList) {
            ArrayList<Activity> activities = currDay.getDayActivityList();

            for (Activity currActivity : activities) {

                if (currActivity instanceof ActivityUnloading && currActivity.getOrderId() == orderId) {
                    ActivityUnloading activityUnloading = (ActivityUnloading) currActivity;

                    if (addLateCost == true) {
                        cost += (activityUnloading.getPiecesToUnload().get(0).getFinishedDispatchDate()
                                - activityUnloading.getPiecesToUnload().get(0).getDueDate()) * latePen;
                        addLateCost = false;
                    }

                    for (Piece currPiece : activityUnloading.getPiecesToUnload()) {
                        cost += PieceCost.calculateTotalPieceCost(currPiece.getSupplierType(),
                                currPiece.getRawStartType(), currPiece.getTotalMachinningTime(),
                                currPiece.getSuppliedArrivalDate(), currPiece.getFinishedDispatchDate());
                    }
                }
            }
        }
        return cost;
    }

    static Day getDayToSend(int currDay) throws IOException {
        if (currDay == -1) {
            currDay = 0;
        }

        Boolean isToSent = (currDay != lastDaySent);
        if (isToSent) {
            Day day = masterProductionProductionSchedule.getDayOfDayList(currDay);
            if (null == day) {
                return null;
            }
            lastDaySent = currDay;

            return day;
        }

        return null;
    }

    static void sincronizeClocksErp() throws Exception {
        int maxAttempts = 3; // Maximum number of retry attempts
        int attempt = 1; // Current attempt counter

        while (attempt <= maxAttempts) {
            try {
                sendInitTimeTcpClient.sendObject(dayCounter.getinitTime());
                break;
            } catch (IOException e) {
                System.out.println("Failed to send the init time to sincronize the clocks");
                attempt++;
                Thread.sleep(1000);
            }
        }

        if (attempt == maxAttempts) {
            throw new Exception("Error sincronizing the clocks");
        }
    }

    static void connectWithMes() throws Exception {
        int maxRetries = 20;
        int retryCount = 0;

        while (retryCount < maxRetries) {
            try {
                sendInitTimeTcpClient = new TcpClient(CommunicationConstants.MesIp,
                        CommunicationConstants.mesInitTimeTcpPort);
                sendToMesTcpClient = new TcpClient(CommunicationConstants.MesIp, CommunicationConstants.mesDayTcpPort);
                break;
            } catch (Exception e) {
                retryCount++;
                System.out.println("Failed to connect to MES. Retrying in 2 seconds...");

                Thread.sleep(2000);
            }
        }

        // Check if the connection was successful or exceeded the maximum retries
        if (retryCount == maxRetries) {
            System.out.println("Failed to connect to MES after " + maxRetries + " retries. Exiting...");
            System.exit(-1);
        } else {
            System.out.println("Connected to MES.");
            sincronizeClocksErp();
        }
    }

    static void setupErp() throws Exception {
        dayCounter = new TimeCounting();
        recieveOrderUdpServer = new UdpServer(CommunicationConstants.receiveOrderUdpPort);

        Piece freePieceToAdd = new Piece(-1, PieceType.P1);
        ArrayList<Piece> storedPieces = new ArrayList<Piece>();
        for (int i = 0; i < 1; i++) {
            storedPieces.add(freePieceToAdd);
        }

        Warehouse warehouse = new Warehouse();
        xmlFileParser = new XmlParser();
        masterProductionProductionSchedule = new NewMasterProductionSchedule(0, Machine.getMachinesList(), ToolType.T3,
                warehouse);

        if (!ErpConfig.ERP_STANDALONE_VERSION) {
            connectWithMes();
        }

        recieveOrderUdpServer.start();
        System.out.println("Starting ERP");
    }

    public static void main(String[] args) throws Exception {

        // HelloApplication.startGUI();

        // HelloApplication.startGUI();

        DeleteDataFromTables deleteDataFromTables = new DeleteDataFromTables();
        deleteDataFromTables.deleteTables();

        Boolean firstDayWasSent = false;

        try {
            setupErp();
        } catch (Exception e) {
            System.out.println("Error in erp setup");
            e.printStackTrace();
        }

        Day dayToSent = null;

        while (true) {

            if (ErpConfig.USE_TEST_DAY == true) {
                if (testDay1.getCurrDay() == dayCounter.getDay()) {
                    dayToSent = testDay1;
                }
            } else {
                recieveAndPlanOrder();
                try {
                    if (ErpConfig.ERP_STANDALONE_VERSION == false) {
                        // if (firstDayWasSent == false) {
                        // dayToSent = getDayToSend(0);

                        // while (dayToSent != null) {
                        // try {
                        // // sendToMesTcpClient = new TcpClient("localhost",
                        // // CommunicationConstants.mesDayTcpPort);
                        // System.out.println("-----------------------------Day to send:");
                        // System.out.println(dayToSent.toString());
                        // sendToMesTcpClient.sendObject(dayToSent);
                        // testDay1.setCurrDay(-1);
                        // System.out.println("-----------------------------Day was sent.");
                        // firstDayWasSent = true;
                        // dayToSent = null;
                        // } catch (SocketException e) {
                        // sendToMesTcpClient = new TcpClient("localhost",
                        // CommunicationConstants.mesDayTcpPort);
                        // System.out.println("Lost connection to MES. Reconnecting");
                        // } catch (IOException e) {
                        // System.out.println("Lost connection to MES. Reconnecting");
                        // }
                        // }
                        // }
                        dayToSent = getDayToSend(dayCounter.getDay());
                    }
                } catch (IOException e) {
                    System.out.println("Failed to get the current day");
                    e.printStackTrace();
                }
            }

            if (null != dayToSent && !ErpConfig.ERP_STANDALONE_VERSION) {

                while (dayToSent != null) {
                    try {
                        // sendToMesTcpClient = new TcpClient("localhost",
                        // CommunicationConstants.mesDayTcpPort);
                        System.out.println("-----------------------------Day to send:");
                        System.out.println(dayToSent.toString());
                        sendToMesTcpClient.sendObject(dayToSent);
                        testDay1.setCurrDay(-1);
                        System.out.println("-----------------------------Day was sent.");
                        dayToSent = null;
                    } catch (SocketException e) {
                        sendToMesTcpClient = new TcpClient(CommunicationConstants.MesIp,
                                CommunicationConstants.mesDayTcpPort);
                        System.out.println("Lost connection to MES. Reconnecting");
                    } catch (IOException e) {
                        System.out.println("Lost connection to MES. Reconnecting");
                    }
                }
            }
        }
    }
}