package MasterProductionPlan;

import java.util.ArrayList;

import Common.Machine.ToolType;
import Common.Piece.Piece;
import Common.Piece.PieceType;
import Common.Piece.Transition;

public class ActivityProduction extends Activity {

    // private ArrayList<Integer> piecesToProduceIDs;
    // private Transition transition;

    // public ActivityProduction(int activityDuration, int orderId,
    // ArrayList<Integer> piecesToProduceIDs, Transition transition){

    // super(ActivityType.Production, activityDuration, orderId);
    // this.piecesToProduceIDs = piecesToProduceIDs;
    // this.transition = transition;
    // }

    private ArrayList<Piece> piecesToProduce;
    private int currTransitionIndex;
    private Piece auxPiece;

    public ActivityProduction(int activityDuration, int orderId, ArrayList<Piece> piecesToProduce,
            int currTransitionIndex) {

        super(ActivityType.Production, activityDuration, orderId);
        this.piecesToProduce = piecesToProduce;
        this.currTransitionIndex = currTransitionIndex;
        this.auxPiece = this.piecesToProduce.get(0);
    }

    public ActivityProduction(ActivityType activityType, int activityStartTime, int activityEndTime,
            int activityDuration, int orderId, int day, ArrayList<Piece> piecesToProduce, int currTransitionIndex) {

        super(activityType, activityStartTime, activityEndTime, activityDuration, orderId, day);
        this.piecesToProduce = piecesToProduce;
        this.currTransitionIndex = currTransitionIndex;
        this.auxPiece = this.piecesToProduce.get(0);
    }

    public ArrayList<Piece> getPiecesToProduce() {
        return this.piecesToProduce;
    }

    public int getCurrTransitionIndex() {
        return this.currTransitionIndex;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append("\n\tCurrTransitionIndex: " + this.currTransitionIndex);
        sb.append(
                "\n\tTransition: " + auxPiece.getOrderedTransitionsList().get(currTransitionIndex).getStartType() + "->"
                        + auxPiece.getOrderedTransitionsList().get(currTransitionIndex).getFinalType());
        sb.append("\n\tPieces to produce: " + piecesToProduce.size());

        return sb.toString();
    }

    /**
     * Auxiliary method
     * Needed to create production action
     * 
     * @return number of pieces to produce
     */
    public int getNumberOfPieces() {
        return this.piecesToProduce.size();
    }

    /**
     * Auxiliary method
     * Needed to create production action
     * 
     * @return the needed tool to performe the next transition
     */
    public ToolType getNeededTool() {
        return auxPiece.getOrderedTransitionsList().get(currTransitionIndex).getNeededTool();
    }

    /**
     * Auxiliary method
     * Needed to create production action
     * 
     * @return the start type for the next transition
     */
    public PieceType getNextTransitionStartType() {
        return auxPiece.getOrderedTransitionsList().get(this.getCurrTransitionIndex()).getStartType();
    }

    @Override
    public ActivityProduction clone() {
        try {
            ActivityProduction clone = (ActivityProduction) super.clone();
            clone.piecesToProduce = new ArrayList<Piece>();

            for (Piece currPiece : this.piecesToProduce) {
                clone.piecesToProduce.add(currPiece.clone());
            }

            return clone;

        } catch (Exception e) {
            System.out.println(e.toString());
            return null;
        }
    }

}