package Common.Machine;

public enum MachineType {
    M1(5),
    M2(7),
    M3(10),
    M4(15);

    private final int timeInConveyor;

    MachineType(int timeInConveyor) {
        this.timeInConveyor = timeInConveyor;
    }

    public int getTimeInConveyor() {
        return timeInConveyor;
    }
}
