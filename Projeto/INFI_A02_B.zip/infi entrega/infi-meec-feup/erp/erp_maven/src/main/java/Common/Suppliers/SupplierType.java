package Common.Suppliers;

public enum SupplierType {
    A(4),
    B(2),
    C(1);

    private final int supplierTime;

    private SupplierType(int supplierTime) {
        this.supplierTime = supplierTime;
    }

    public int getSupplierTime() {
        return supplierTime;
    }

    public String toString() {
        switch (this) {
            case A:
                return "Supplier A";
            case B:
                return "Supplier B";
            case C:
                return "Supplier C";
            default:
                return "No supplier";
        }
    }

}
