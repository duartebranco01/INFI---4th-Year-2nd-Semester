package MasterProductionPlan;

import java.io.Serializable;

public class Slot implements Serializable {

    private int startTime;
    private int endTime;

    Slot(int startTime, int endTime) {
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public int calculateDuration() {
        return this.endTime - this.startTime;
    }

    public int getStartTime() {
        return startTime;
    }

    public int getEndTime() {
        return endTime;
    }

    public void setStartTime(int startTime) {
        this.startTime = startTime;
    }

    public void setEndTime(int endTime) {
        this.endTime = endTime;
    }

    public String toString() {
        return "\n\t Start time: " + Integer.toString(startTime)
                + "\n\t End time: " + Integer.toString(endTime)
                + "\n\t Duration: " + Integer.toString(calculateDuration());
    }

}
