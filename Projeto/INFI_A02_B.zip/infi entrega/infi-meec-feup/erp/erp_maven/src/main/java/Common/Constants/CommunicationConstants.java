package Common.Constants;

public class CommunicationConstants {
    public final static int receiveOrderUdpPort = 54321;
    public final static int mesDayTcpPort = 5555;
    public final static int mesInitTimeTcpPort = 5556;
    public static final String MesIp = "localhost";
}
