package Common.Machine;

import java.util.ArrayList;
import java.util.Arrays;

public class Machine {
    private int machineId;
    MachineType machineType;

    ToolType currentTool;
    ArrayList<ToolType> tools;

    public static ArrayList<Machine> getMachinesList() {
        ArrayList<ToolType> machine1Tools = new ArrayList<ToolType>(
                Arrays.asList(ToolType.T1, ToolType.T2, ToolType.T3));
        Machine machine1 = new Machine(1, MachineType.M1, ToolType.T1, machine1Tools);
        Machine machine2 = new Machine(2, MachineType.M2, ToolType.T1,
                new ArrayList<>(Arrays.asList(ToolType.T1, ToolType.T3, ToolType.T4)));
        Machine machine3 = new Machine(3, MachineType.M3, ToolType.T2,
                new ArrayList<>(Arrays.asList(ToolType.T2, ToolType.T3, ToolType.T4)));
        Machine machine4 = new Machine(4, MachineType.M4, ToolType.T1,
                new ArrayList<>(Arrays.asList(ToolType.T1, ToolType.T3, ToolType.T4)));

        ArrayList<Machine> machineList = new ArrayList<Machine>();
        machineList.add(machine1);
        machineList.add(machine2);
        machineList.add(machine3);
        machineList.add(machine4);

        return machineList;
    }

    public Machine(int machineId, MachineType machineType, ToolType currentTool, ArrayList<ToolType> tools) {
        this.machineId = machineId;
        this.machineType = machineType;
        this.currentTool = currentTool;
        this.tools = tools;
    }

    public boolean switchCurrentTool(ToolType neededTool) {
        boolean success = false;
        if (tools.contains(neededTool)) {
            this.currentTool = neededTool;
            success = true;
        }

        return success;
    }

    public int getMachineId() {
        return machineId;
    }

    public MachineType getMachineType() {
        return machineType;
    }

    public ToolType getCurrentTool() {
        return currentTool;
    }

    public void setCurrentTool(ToolType currentTool) {
        this.currentTool = currentTool;
    }

    public ArrayList<ToolType> getTools() {
        return tools;
    }

}
