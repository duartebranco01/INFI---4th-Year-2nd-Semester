package Erp.Main;

import Common.Piece.Piece;
import Common.Piece.Transition;
import Erp.OrderInfo.OrderInfo;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class OrderSort {

    public static int calculateMachiningTimeForOrder(OrderInfo order) {

        ArrayList<Piece> pieceList = order.getPieceList();

        int orderMachingTime = 0;

        for (Piece piece : pieceList) {

            ArrayList<Transition> transitionList = piece.decomposeInTransitionsList();

            for (Transition transition : transitionList) {

                int machiningTime = transition.getMachiningTime();
                orderMachingTime = orderMachingTime + machiningTime;

            }
        }
        return orderMachingTime;
    }

    public static ArrayList<OrderInfo> orderOrdersByMachiningTime(ArrayList<OrderInfo> orders) {

        Comparator<OrderInfo> machiningTimeComparator = new Comparator<OrderInfo>() {

            @Override
            public int compare(OrderInfo order1, OrderInfo order2) {
                int machiningTime1 = calculateMachiningTimeForOrder(order1);
                int machiningTime2 = calculateMachiningTimeForOrder(order2);
                return Integer.compare(machiningTime1, machiningTime2);

            }
        };

        Collections.sort(orders, machiningTimeComparator);

        return orders;
    }

    public static OrderInfo leastMachiningTimeOrder(ArrayList<OrderInfo> orders) {

        OrderInfo leastMachiningTimeOrder = null;

        if (orders != null && !orders.isEmpty()) {

            leastMachiningTimeOrder = orderOrdersByMachiningTime(orders).get(0);

        }

        return leastMachiningTimeOrder;

    }

    public static void main(String[] args) {

        OrderInfo order1 = new OrderInfo("feup", 3, Common.Piece.PieceType.P5, 4, 8, 14, 15);
        OrderInfo order2 = new OrderInfo("fmup", 7, Common.Piece.PieceType.P7, 2, 9, 14, 11);
        OrderInfo order3 = new OrderInfo("www", 1, Common.Piece.PieceType.P8, 1, 3, 14, 10);

        ArrayList<OrderInfo> orders = new ArrayList<>();
        orders.add(order1);
        orders.add(order2);
        orders.add(order3);

        int machiningTime1 = OrderSort.calculateMachiningTimeForOrder(order1);
        System.out.println("Machining time for order 1: " + machiningTime1);
        System.out.println(order1);
        System.out.println(" ");

        int machiningTime2 = OrderSort.calculateMachiningTimeForOrder(order2);
        System.out.println("Machining time for order 2: " + machiningTime2);
        System.out.println(order2);
        System.out.println(" ");

        int machiningTime3 = OrderSort.calculateMachiningTimeForOrder(order3);
        System.out.println("Machining time for order 3: " + machiningTime3);
        System.out.println(order3);
        System.out.println(" ");

        System.out.println(" ");

        ArrayList<OrderInfo> orderedOrders = OrderSort.orderOrdersByMachiningTime(orders);
        System.out.println("Ordered orders by machining time: ");
        for (OrderInfo order : orderedOrders) {
            System.out.println(order);
        }

        System.out.println(" ");

        OrderInfo leastMachiningTimeOrder = OrderSort.leastMachiningTimeOrder(orders);
        if (leastMachiningTimeOrder != null) {
            System.out.println("Order with the least machining time: " + leastMachiningTimeOrder);
        } else {
            System.out.println("No orders");
        }
    }

}
