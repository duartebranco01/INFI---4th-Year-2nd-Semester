package Common.Communication.Udp;

import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class XmlUdpClient {

    public static String receive() throws Exception {
        int port = 54321;
        DatagramSocket socket = new DatagramSocket(port);
        byte[] buffer = new byte[1024];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

        while (true) {
            socket.receive(packet);
            String xml = new String(packet.getData(), 0, packet.getLength());
            xml = xml.substring(xml.indexOf("<DOCUMENT>"), xml.indexOf("</DOCUMENT>") + "</DOCUMENT>".length());
            System.out.println("Received XML: " + xml);
            return xml;
        }
    }
}
