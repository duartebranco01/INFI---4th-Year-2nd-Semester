package Common.Communication.SQL;

import java.sql.Connection;
import java.sql.Statement;

public class DeleteDataFromTables extends DataBase {
    public boolean deleteTables() {

        Connection c = null;
        Statement st = null;

        c = super.connect();
        if (c == null)
            return false;

        try {
            String deleteQuery = "DELETE FROM \"INFI\".\"MachineStats\";";
            st = c.createStatement();
            st.executeUpdate(deleteQuery);

            String deleteQuery1 = "DELETE FROM \"INFI\".\"OrderCost\";";
            st = c.createStatement();
            st.executeUpdate(deleteQuery1);

            String deleteQuery2 = "DELETE FROM \"INFI\".\"OrderStats\";";
            st = c.createStatement();
            st.executeUpdate(deleteQuery2);

            String deleteQuery3 = "DELETE FROM \"INFI\".\"ProductionPlan\";";
            st = c.createStatement();
            st.executeUpdate(deleteQuery3);

            String deleteQuery4 = "DELETE FROM \"INFI\".\"PurchasingPlan\";";
            st = c.createStatement();
            st.executeUpdate(deleteQuery4);

            String deleteQuery5 = "DELETE FROM \"INFI\".\"UnloadingStats\";";
            st = c.createStatement();
            st.executeUpdate(deleteQuery5);

            String deleteQuery6 = "DELETE FROM \"INFI\".\"machinetime\";";
            st = c.createStatement();
            st.executeUpdate(deleteQuery6);

            String deleteQuery7 = "DELETE FROM \"INFI\".\"unloadingdocktotal\";";
            st = c.createStatement();
            st.executeUpdate(deleteQuery7);

            String deleteQuery8 = "DELETE FROM \"INFI\".\"warehouse\";";
            st = c.createStatement();
            st.executeUpdate(deleteQuery8);

        } catch (Exception e) {
            System.out.println(e.getMessage());

            return false;
        }
        return true;
    }
}