package Common.Communication.Udp;

import java.io.IOException;
import java.net.*;
import java.util.LinkedList;

public class UdpServer extends Thread {

    private DatagramSocket datagramSocket;
    private LinkedList<String> receivedBuffer = new LinkedList<String>();

    public UdpServer(int port) throws SocketException {
        datagramSocket = new DatagramSocket(port, null);
    }

    @Override
    public void run() {
        byte[] buffer = new byte[1024];

        while (!Thread.currentThread().isInterrupted()) {
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
            try {
                datagramSocket.receive(packet);
            } catch (IOException e) {
                e.printStackTrace();
            }

            String received = new String(packet.getData(), 0, packet.getLength());

            synchronized (receivedBuffer) {
                receivedBuffer.addLast(received);
                receivedBuffer.notifyAll();
            }
        }
    }

    public String popLeastRecent() {
        synchronized (receivedBuffer) {
            if (receivedBuffer.isEmpty()) {
                return null;
            }
            return receivedBuffer.pollFirst();
        }
    }

    public static void main(String[] args) throws IOException {
        int port = 1234;
        UdpServer server = new UdpServer(port);
        server.start();
        System.out.println("test");

        // Example usage: pop the least recent string from the buffer
        while (true) {
            String leastRecent = server.popLeastRecent();
            System.out.println("Least recent string: " + leastRecent);
        }
    }
}