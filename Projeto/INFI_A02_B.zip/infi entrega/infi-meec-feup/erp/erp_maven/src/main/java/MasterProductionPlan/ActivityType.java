package MasterProductionPlan;

public enum ActivityType {

    Supplies,
    SwitchTools,
    Production,
    Unloading,
    TransportToMachines,
    Supplier;

    @Override
    public String toString() {
        switch (this) {
            case Supplies:
                return "Supplies";
            case SwitchTools:
                return "SwitchTools";
            case Production:
                return "Production";
            case Unloading:
                return "Unloading";
            case TransportToMachines:
                return "TransportToMachines";
            default:
                return "";
        }
    }
}
