package MasterProductionPlan;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import Common.Constants.TimeConstants;
import Common.Machine.Machine;
import Common.Machine.ToolType;
import Common.Piece.Piece;
import Common.Piece.PieceType;
import Common.Piece.Transition;
import Common.Suppliers.SupplierType;
import Erp.OrderInfo.OrderInfo;
import Products.UnloadingDockType;
import Products.Warehouse;
import javafx.util.Pair;

public class NewMasterProductionSchedule {

    private int currDay;
    private int currTime;
    private ArrayList<Day> dayList;
    private ArrayList<Machine> machineList;
    private ArrayList<OrderInfo> ordersList;
    // private ToolType startingTool;
    private Warehouse warehouse;
    ToolType lastTool;

    public NewMasterProductionSchedule(int startDay, ArrayList<Machine> machineList, ToolType startingTool,
            Warehouse warehouse) {
        this.currDay = startDay;
        this.dayList = new ArrayList<Day>();
        this.machineList = machineList;
        this.ordersList = new ArrayList<OrderInfo>();
        // this.startingTool = startingTool;
        this.warehouse = warehouse;
        this.lastTool = ToolType.T3;

    }

    public boolean addNewOrderAndPlan(OrderInfo newOrder) throws Exception {

        boolean result = false;

        System.out.println("Planing order with number " + newOrder.getNumber() + "...");

        int realDueDateIndex = calculateRealDueDateIndex(newOrder.getDueDate());
        int finishedDeliveryDateIndex = realDueDateIndex;

        while (finishedDeliveryDateIndex < realDueDateIndex + 3) {

            // only update if planning sucessfull
            Pair<Warehouse, ArrayList<Day>> warehouseAndDays = PlanNewOrder(newOrder, finishedDeliveryDateIndex);
            if (warehouseAndDays != null) {
                System.out.println("ORDER with ID: " + newOrder.getNumber() + " SUCCESSFULL with dueDate: "
                        + newOrder.getDueDate() + " finishedDeliveryDate: "
                        + (finishedDeliveryDateIndex + 1)
                        + ". Updating warehouse and days list");
                this.warehouse = warehouseAndDays.getKey();
                this.dayList = warehouseAndDays.getValue();
                this.ordersList.add(newOrder);
                result = true;
                break;

            } else {
                System.out.println("\nORDER REJECTED");
            }

            finishedDeliveryDateIndex += 1;

        }

        System.out.println("Warehouse stored pieces: " + this.warehouse.getStoredPieces().size());

        return result;
    }

    public Day getDayOfDayList(int dayIndex) {
        Day day_ = null;
        try {
            day_ = this.dayList.get(dayIndex);

        } catch (Exception e) {
            day_ = null;
        }
        return day_;
    }

    private Pair<Warehouse, ArrayList<Day>> PlanNewOrder(OrderInfo newOrder, int finishedDeliveryDateIndex)
            throws Exception {

        // deep copy of this.dayList
        ArrayList<Day> inDays = new ArrayList<Day>();
        for (Day currDayOriginal : this.dayList) {
            inDays.add((Day) ObjectCloner.deepCopy(currDayOriginal));
        }
        // deep copy of this.warehouse
        Warehouse inWarehouse = (Warehouse) ObjectCloner.deepCopy(this.warehouse);
        // deep copy newOrder
        OrderInfo inOrderInfo = (OrderInfo) ObjectCloner.deepCopy(newOrder);
        ArrayList<Piece> inPieces = inOrderInfo.getPieceList();

        // int finishedDeliveryDateIndex =
        // calculateRealDueDateIndex(inOrderInfo.getDueDate());
        if (finishedDeliveryDateIndex < 0) {
            System.out.println("Real due date < this.currDay, ret");
            return null;
        }

        // make sure i have enough days, add if needed
        addDaysToDayListSorted(finishedDeliveryDateIndex, inDays);
        // System.out.println("inDays.size: " + inDays.size());

        int lastPossibleDaySwitchToolsIndex = -1;
        int lastPossibleDayProductionIndex = -1;
        int lastPossibleDayUnloadingIndex = -1;
        int lastPossibleDaySuppliesIndex = -1;

        StringBuilder sb = new StringBuilder();
        sb.append("\nOrder schedule info:\n");

        // UNLOADIND-------------------------------------------------------------------------------------------------------------------------------------------------------------
        lastPossibleDayUnloadingIndex = scheduleUnloading(inPieces, finishedDeliveryDateIndex, inWarehouse, inDays);

        sb.append("\n\tLast day index of unloading: " + lastPossibleDayUnloadingIndex);
        if (-1 == lastPossibleDayUnloadingIndex) {
            System.out.println(sb);
            // System.out.println(inDays);
            return null;
        }

        ArrayList<Transition> transitions = inPieces.get(0).getOrderedTransitionsList();

        lastPossibleDaySwitchToolsIndex = lastPossibleDayUnloadingIndex;

        // TRANSTION + SWITCH TOOLS
        // ----------------------------------------------------------------------------------------------------------------------------------------------
        for (int currTransitionIndex = transitions.size() - 1; currTransitionIndex >= 0; currTransitionIndex--) {
            // TRANSITION
            // -------------------------------------------------------------------------------------------------
            lastPossibleDayProductionIndex = scheduleProduction(inPieces, lastPossibleDaySwitchToolsIndex, inDays,
                    currTransitionIndex);

            if (-1 == lastPossibleDayProductionIndex) {
                sb.append("\n\tLast day index of production: " + lastPossibleDayProductionIndex);
                System.out.println(sb);
                // System.out.println(inDays);
                return null;
            }

            // SWITCH TOOLS
            // -------------------------------------------------------------------------------------------------

            ToolType neededTool = inPieces.get(0).getOrderedTransitionsList().get(currTransitionIndex).getNeededTool();

            lastPossibleDaySwitchToolsIndex = scheduleSwitchTools(inPieces, lastPossibleDayProductionIndex,
                    neededTool,
                    inDays);

            if (-1 == lastPossibleDaySwitchToolsIndex) {
                sb.append("\n\tLast day index of switch tools: " + lastPossibleDaySwitchToolsIndex);
                System.out.println(sb);
                // System.out.println(inDays);
                return null;
            }

            // para verificar que quando há muitas orders, não estou a colocar o switch
            // tools da ordem seguinte antes de uma ordem anteriror
            // logo tem que ser no dia da produçao
            if (lastPossibleDayProductionIndex - lastPossibleDaySwitchToolsIndex > 1) {
                sb.append("lastPossibleDayProductionIndex - lastPossibleDaySwitchToolsIndex > 1, ret null");
                System.out.println(sb);
                // System.out.println(inDays);
                return null;
            }
        }

        sb.append("\n\tLast day index of production: " + lastPossibleDayProductionIndex);
        // sb.append("\n\tLast day index of trasnport to machines: " +
        // lastPossibleDayTransportToMachines);
        sb.append("\n\tLast day index of switch tools: " + lastPossibleDaySwitchToolsIndex);

        // SUPPLIES---------------------------------------------------------------------------------------------------------------------------------------------------
        lastPossibleDaySuppliesIndex = scheduleSupplies(inPieces, lastPossibleDaySwitchToolsIndex, this.currDay,
                inWarehouse,
                inDays);

        sb.append("\n\tLast day index of supplies: " + lastPossibleDaySuppliesIndex);
        if (-1 == lastPossibleDaySuppliesIndex) {
            System.out.println(sb);
            // System.out.println(inDays);
            return null;
        }

        System.out.println(sb);
        System.out.println(inDays);

        // check if 1st activity, which is added last, is after this.currTime
        if (inDays.get(this.currDay).dayActivityList.size() != 0 && inDays.get(this.currDay).dayActivityList
                .get(inDays.get(this.currDay).dayActivityList.size() - 1).getStartTime() < this.currTime) {
            System.out.println("1st activity start time < this.currTime, ret null");
            return null;
        }

        return new Pair<Warehouse, ArrayList<Day>>(inWarehouse, inDays);

    }

    private int scheduleSupplies(ArrayList<Piece> inPieces, int lastPossibleDay, int startingDay, Warehouse inWarehouse,
            ArrayList<Day> inDays) {

        if (null == inPieces) {
            throw new IllegalArgumentException("Invalid pieces list in scheduleSupplies");
        }

        if (lastPossibleDay < this.currDay || startingDay < 0 || inWarehouse == null
                || inDays.size() == 0 || inDays.size() == 0) {
            // inDays = null;
            System.out.println("Schedule supplies: ret -1;");
            return -1;
        }

        PieceType rawStarType = inPieces.get(0).getRawStartType();
        PieceType finalType = inPieces.get(0).getFinalType();
        ArrayList<Transition> transitions = inPieces.get(0).getOrderedTransitionsList();
        int startingOrderId = inPieces.get(0).getOrderId();
        int dueDate = inPieces.get(0).getDueDate();

        int freePiecesNum = inWarehouse.countFreePiecesOfTypeOnDay(rawStarType, lastPossibleDay);
        int piecesToNotSupplieNum = Math.min(freePiecesNum, inPieces.size()); // cuz size can be less

        // alocate free pieces
        // inWarehouse.allocateFreePieces(rawStarType, finalType, transitions,
        // startingOrderId, piecesToNotSupplieNum,
        // dueDate);
        // remove free and add to warehouse the ones i dont need to supplie from
        // inPieces list so i can reference them later by referance
        if (piecesToNotSupplieNum > 0) {
            Pair<ArrayList<Integer>, ArrayList<SupplierType>> supplierDaysAndTypesOfRemovedFreePieces = inWarehouse
                    .removeFreePiecesByQuantityAndDay(piecesToNotSupplieNum, lastPossibleDay);
            ArrayList<Integer> suppliedDaysOfRemovedFreePieces = supplierDaysAndTypesOfRemovedFreePieces.getKey();
            ArrayList<SupplierType> supplierTypesOfRemovedFreePieces = supplierDaysAndTypesOfRemovedFreePieces
                    .getValue();
            ArrayList<Piece> piecesToNotSupplie = new ArrayList<Piece>();

            for (int i = 0; i < piecesToNotSupplieNum - 1 + 1; i++) {
                Piece currPieceToNotSupply = inPieces.get(i);
                currPieceToNotSupply.setSuppliedArrivalDate(suppliedDaysOfRemovedFreePieces.get(i));
                currPieceToNotSupply.setSupplier(supplierTypesOfRemovedFreePieces.get(i));
                piecesToNotSupplie.add(currPieceToNotSupply);
            }
            inWarehouse.addPiecesToWarehouse(piecesToNotSupplie);
        }

        int piecesToSupplieNum = inPieces.size() - piecesToNotSupplieNum;
        int availableDaysToWait = lastPossibleDay - startingDay + 1; // +1 cuz if i want it on day 3 and is on day 0,
                                                                     // 3-0 = 3 but i still have day 0 so 3 - 0 + 1 = 4

        // if dont need to get supplies, ret lastPossibleDay recebido
        if (piecesToSupplieNum == 0) {
            System.out.println("No need to supplie, piecesToSupplieNum == 0");
            // remover apenas as inPieces. logo freePieces permanecem no warehouse
            // os supplies sao a ultima coisa a ser calculada logo:
            // isto aqui porque como só faço uma order de cada vez, no fim o warehouse nao
            // vai ter as peças pedidas
            inWarehouse.removePiecesFromWarehouseByPieceId(inPieces);
            return lastPossibleDay;
        } else if (availableDaysToWait < 1 || inWarehouse.freeSpace() < piecesToSupplieNum
                || inWarehouse.countTotalStoredPieces() + piecesToSupplieNum > inWarehouse.getMaxCapacity()) {
            // inDays = null;
            System.out.println("Schedule supplies: no time or space, ret -1 ");
            return -1;

        }

        // System.out.println("Pieces to not supplie: " + piecesToNotSupplieNum);
        ArrayList<Piece> piecesToSupply = new ArrayList<Piece>();
        piecesToSupply.addAll(inPieces.subList(piecesToNotSupplieNum - 1 + 1, inPieces.size() - 1)); // -1 cuz index +1
                                                                                                     // cuz i want the
                                                                                                     // next
        piecesToSupply.add(inPieces.get(inPieces.size() - 1)); // add last cuz sublist doenst include it
        SupplierType supplier = ActivitySupplies.pickSupplier(piecesToSupply.size(), availableDaysToWait,
                inWarehouse.freeSpace());
        if (supplier == null) {
            // inDays = null;
            System.out.println("Schedule supplies: No supplier, ret -1");
            return -1;
        }

        int supplierMinPiecesNum = ActivitySupplies.checkMinOrderOfSupplier(supplier);

        System.out
                .println("supplierMinPiecesNum: " + supplierMinPiecesNum + " piecesToSupply: " + piecesToSupply.size());

        // add free pieces if below minimum order quantity
        if (piecesToSupply.size() < supplierMinPiecesNum) {
            for (int i = piecesToSupply.size() - 1; i < supplierMinPiecesNum - 1; i++) {
                Piece freePiece = new Piece(-1, rawStarType, supplier);
                piecesToSupply.add(freePiece);

            }
        }
        System.out.println("pieces to Supply after free pieces: " + piecesToSupply.size());
        // System.out.println("piecesToSupply.size: " + piecesToSupply.size());

        ArrayList<ActivitySupplies> activitiesSupplies = scheduleSuppliesTask(lastPossibleDay,
                TimeConstants.getSuppliesTransportTime(), supplier,
                piecesToSupply, inDays);

        if (activitiesSupplies == null || activitiesSupplies.isEmpty()) {
            System.out.println("Schedule supplies: Coudnt create activities supplies, ret -1");
            return -1;
        }

        // check if Tried to add supplies in curr day but startTime < this.currTime
        if (activitiesSupplies.get(activitiesSupplies.size() - 1).getDay() == this.currDay
                && activitiesSupplies.get(activitiesSupplies.size() - 1).getStartTime() < this.currTime) {
            System.out.println(
                    "Schedule supplies: Tried to add supplies in curr day but startTime < this.currTime, ret -1");
            return -1;
        }

        for (ActivitySupplies currActivityProduction : activitiesSupplies) {
            inDays.get(currActivityProduction.getDay()).addToDayActivityListSorted(currActivityProduction);

        }

        // add pieces to warehouse
        inWarehouse.addPiecesToWarehouse(piecesToSupply);

        // remover apenas as inPieces. logo freePieces permanecem no warehouse
        // os supplies sao a ultima coisa a ser calculada logo:
        // isto aqui porque como só faço uma order de cada vez, no fim o warehouse nao
        // vai ter as peças pedidas
        inWarehouse.removePiecesFromWarehouseByPieceId(inPieces);

        ActivitySupplies lastActivActionSupplies = activitiesSupplies.get(activitiesSupplies.size() - 1);

        return lastActivActionSupplies.getDay();

    }

    private ArrayList<ActivitySupplies> scheduleSuppliesTask(int lastPossibleDay, int minActivityDuration,
            SupplierType supplier, ArrayList<Piece> inPieces, ArrayList<Day> inDays) {

        int orderId = inPieces.get(0).getOrderId();

        ArrayList<ActivitySupplies> activitiesSupplies = new ArrayList<ActivitySupplies>();

        int currPieceIndex = 0;
        // go trough all days from last possible
        for (int currDayIndex = lastPossibleDay; currDayIndex >= 0; currDayIndex--) {
            // if have inserted all pieces break
            if (currPieceIndex > inPieces.size() - 1)
                break;

            Day currDay = inDays.get(currDayIndex);

            ArrayList<Slot> freeSlots = currDay.calculateFreeSlotsByActivity(currDay.getDayActivityList(),
                    ActivityType.Supplies);
            // i want to start checking from last free slot, its better to try to insert
            // production in the end of the day
            // Collections.reverse(freeSlots);
            Collections.sort(freeSlots, Comparator.comparingInt(Slot::getEndTime));
            // go trough all free slots
            for (Slot currFreeSlot : freeSlots) {
                // if have inserted all pieces break
                if (currPieceIndex > inPieces.size() - 1)
                    break;

                int availableDuration = currFreeSlot.calculateDuration();

                if (availableDuration >= minActivityDuration) {

                    ArrayList<Piece> piecesToTryToSupplie = new ArrayList<Piece>(
                            inPieces.subList(currPieceIndex, inPieces.size() - 1)); // last element is exclusive
                    piecesToTryToSupplie.add(inPieces.get(inPieces.size() - 1)); // add last

                    // create Activity Supplies
                    Pair<Integer, ArrayList<Piece>> timePiecesPair = calculatePiecesIntoActivity(piecesToTryToSupplie,
                            availableDuration, TimeConstants.getSuppliesTransportTime(),
                            TimeConstants.getPoppingOutWarehouse(), TimeConstants.getPoppingInUnloading(), 0, null);
                    if (timePiecesPair == null)
                        continue;

                    int activityDuration = timePiecesPair.getKey();
                    ArrayList<Piece> piecesToSupplie = new ArrayList<Piece>();

                    if (timePiecesPair.getValue() == null)
                        continue;

                    for (Piece pieceToAddToList : timePiecesPair.getValue()) {
                        pieceToAddToList.setSuppliedArrivalDate(currDayIndex);
                        piecesToSupplie.add(pieceToAddToList);
                    }

                    // i want to insert as late as possible
                    int endTime = currFreeSlot.getEndTime();
                    int startTime = endTime - activityDuration;

                    ActivitySupplies activitySupplies = new ActivitySupplies(ActivityType.Supplies, startTime, endTime,
                            endTime - startTime, orderId, currDayIndex, supplier, piecesToSupplie);

                    // add activity and increment currPieceIndex
                    currPieceIndex += activitySupplies.getPiecesFromSupplier().size() - 1 + 1; // -1 cuz index +1 cuz i
                                                                                               // want next

                    activitiesSupplies.add(activitySupplies);

                }
            }
        }

        // no size -1 cuz currPieceIndex is next
        if (currPieceIndex != inPieces.size()) {
            System.out.println("Schedule Supplies Task: Pieces were not inserted");
            return null; // no size-1 cuz currPieces is supossed to be the next
        }
        return activitiesSupplies;
    }

    /**
     * @return Return the last days when the activity was inserted.
     *         Return -1 when he cannot insert;
     */
    private int scheduleSwitchTools(ArrayList<Piece> inPieces, int lastPossibleDay, ToolType neededTool,
            ArrayList<Day> inDays) {

        if (inPieces == null || lastPossibleDay < this.currDay || neededTool == null || inDays.size() == 0) {
            System.out.println("Schedule Production: ret -1");
            return -1;
        }

        boolean inserted = false;
        int insertedDay = lastPossibleDay;

        int orderId = inPieces.get(0).getOrderId();
        int minActivityDuration = TimeConstants.switchToolsTime;

        for (int currDayIndex = lastPossibleDay; currDayIndex >= 0; currDayIndex--) {

            if (inserted)
                break;

            Day currDay = inDays.get(currDayIndex);

            // check if already has switchtools, se ja tem no dia nao posso mudar tools
            // outra vez
            boolean foundSwitchTools = false;
            for (Activity checkActivity : currDay.getDayActivityList()) {
                if (checkActivity instanceof ActivitySwitchTools)
                    foundSwitchTools = true;
            }
            if (foundSwitchTools == true)
                continue;

            ArrayList<Slot> freeSlots = currDay.calculateFreeSlotsByActivity(currDay.getDayActivityList(),
                    ActivityType.SwitchTools);
            // i want to start checking from last free slot, its better to try to insert
            // production in the end of the day
            // Collections.reverse(freeSlots);
            Collections.sort(freeSlots, Comparator.comparingInt(Slot::getEndTime));
            // go trough all free slots
            for (Slot currFreeSlot : freeSlots) {

                // if (inserted == true)
                // break;

                int availableDuration = currFreeSlot.calculateDuration();
                if (availableDuration >= minActivityDuration) {

                    int endTime = currFreeSlot.getEndTime();
                    int startTime = endTime - minActivityDuration;
                    ActivitySwitchTools activitySwitchTools = new ActivitySwitchTools(ActivityType.SwitchTools,
                            startTime, endTime, minActivityDuration, orderId, currDayIndex, neededTool);
                    inDays.get(currDayIndex).addToDayActivityListSorted(activitySwitchTools);
                    inserted = true;
                    insertedDay = currDayIndex;

                }

                if (inserted == true)
                    break;
            }

            if (inserted == true)
                break;

        }

        if (inserted == false) {
            System.out.println("Schedule Switch Tools: Coudnt create activity Swtich Tools, ret -1");
            return -1;

        }

        return insertedDay;

    }

    private int scheduleProduction(ArrayList<Piece> inPieces, int lastPossibleDay, ArrayList<Day> inDays,
            int currTransitionIndex) {

        if (inPieces == null || lastPossibleDay < this.currDay || inDays.size() == 0 || currTransitionIndex < 0) {
            System.out.println("Schedule Production: ret -1");
            return -1;
        }

        Pair<ArrayList<ActivityProduction>, ArrayList<ActivityTransportToMachines>> activitiesProductionAndTransport = scheduleProductionAndTransportToMachinesTask(
                lastPossibleDay,
                TimeConstants.getProductionTransportTimeToMachines()
                        + TimeConstants.getProductionTransportTimeBackToWarehouse(),
                currTransitionIndex, inPieces, inDays);

        if (activitiesProductionAndTransport == null/* activitiesProduction == null || activitiesProduction.isEmpty() */) {
            System.out.println(
                    "Schedule Production: Coudnt create activities Production and Transport to machines, ret -1");
            return -1;
        }

        // System.out.println("LastPossDayProduction: " + lastPossibleDay);

        ArrayList<ActivityProduction> activitiesProduction = activitiesProductionAndTransport.getKey();
        ArrayList<ActivityTransportToMachines> activitiesTransportToMachines = activitiesProductionAndTransport
                .getValue();

        for (int i = 0; i < activitiesProduction.size(); i++) {
            inDays.get(activitiesProduction.get(i).getDay()).addToDayActivityListSorted(activitiesProduction.get(i));
            inDays.get(activitiesTransportToMachines.get(i).getDay())
                    .addToDayActivityListSorted(activitiesTransportToMachines.get(i));
        }

        return activitiesProduction.get(activitiesTransportToMachines.size() - 1).getDay();
    }

    private Pair<ArrayList<ActivityProduction>, ArrayList<ActivityTransportToMachines>> scheduleProductionAndTransportToMachinesTask(
            int lastPossibleDay, int minActivityDuration,
            int currTransitionIndex,
            ArrayList<Piece> inPieces, ArrayList<Day> inDays) {

        int orderId = inPieces.get(0).getOrderId();
        Transition transition = inPieces.get(0).getOrderedTransitionsList().get(currTransitionIndex);

        ArrayList<ActivityProduction> activitiesProduction = new ArrayList<ActivityProduction>();
        ArrayList<ActivityTransportToMachines> activitiesTransportToMachines = new ArrayList<ActivityTransportToMachines>();

        int currPieceIndex = 0;
        // go trough all days from last possible
        for (int currDayIndex = lastPossibleDay; currDayIndex >= 0; currDayIndex--) {
            // if have inserted all pieces break
            if (currPieceIndex > inPieces.size() - 1)
                break;

            Day currDay = inDays.get(currDayIndex);

            ArrayList<Slot> freeSlots = currDay.calculateFreeSlotsByActivity(currDay.getDayActivityList(),
                    ActivityType.Production);

            // i want to start checking from last free slot, its better to try to insert
            // production in the end of the day
            Collections.sort(freeSlots, Comparator.comparingInt(Slot::getEndTime));

            // go trough all free slots
            for (Slot currFreeSlot : freeSlots) {
                // if have inserted all pieces break
                if (currPieceIndex > inPieces.size() - 1)
                    break;

                int availableDuration = currFreeSlot.calculateDuration();

                if (availableDuration >= minActivityDuration) {

                    // System.out.println("piece index: " + currPieceIndex + "availb duration: " +
                    // availableDuration);

                    ArrayList<Piece> piecesToTryToProduce = new ArrayList<Piece>(
                            inPieces.subList(currPieceIndex, inPieces.size() - 1)); // last element is exclusive
                    piecesToTryToProduce.add(inPieces.get(inPieces.size() - 1)); // add last

                    int productionActivityDuration = 0;
                    int piecesToProduceNum = piecesToTryToProduce.size();
                    boolean piecesToProduceSuccess = false;

                    while (piecesToProduceNum > 0) {
                        productionActivityDuration = ProductionTimeEstimator.calculateProductionTime(piecesToProduceNum,
                                transition.getNeededTool(), transition.getMachiningTime());
                        if (productionActivityDuration <= availableDuration) {
                            piecesToProduceSuccess = true;
                            // System.out.println("prod duration: " + productionActivityDuration);
                            // System.out.println("Prod curr day: " + currDayIndex);
                            break;
                        }
                        piecesToProduceNum--;
                    }

                    if (piecesToProduceSuccess == false)
                        continue;
                    ArrayList<Piece> piecesToProduce = new ArrayList<Piece>();
                    piecesToProduce.addAll(piecesToTryToProduce.subList(0, piecesToProduceNum - 1));
                    piecesToProduce.add(piecesToTryToProduce.get(piecesToProduceNum - 1));

                    // i want to insert as late as possible

                    // production duration subtract transport to machine times + popping out time,
                    // so i can put it in the activity transport
                    int productionEndTime = currFreeSlot.getEndTime();
                    int productionStartTime = productionEndTime - (productionActivityDuration
                            - TimeConstants.getProductionTransportTimeToMachines()
                            - TimeConstants.getPoppingOutWarehouse() * piecesToProduce.size());

                    int transportToMachinesEndTime = productionStartTime;
                    int transportToMachinesStartTime = productionEndTime - productionActivityDuration;

                    ActivityProduction activityProduction = new ActivityProduction(ActivityType.Production,
                            productionStartTime,
                            productionEndTime, productionEndTime - productionStartTime, orderId, currDayIndex,
                            piecesToProduce, currTransitionIndex);

                    ActivityTransportToMachines activityTransportToMachines = new ActivityTransportToMachines(
                            ActivityType.TransportToMachines, transportToMachinesStartTime, transportToMachinesEndTime,
                            transportToMachinesEndTime - transportToMachinesStartTime, orderId, currDayIndex,
                            piecesToProduce, currTransitionIndex);

                    // add activity and increment currPieceIndex
                    currPieceIndex += activityProduction.getPiecesToProduce().size() - 1 + 1; // -1 cuz index +1 cuz i
                                                                                              // want next

                    activitiesProduction.add(activityProduction);
                    activitiesTransportToMachines.add(activityTransportToMachines);

                }

            }

        }
        // no size -1 cuz currPieceIndex is next
        if (currPieceIndex != inPieces.size()) {
            System.out.println("Schedule Production Task: Pieces were not inserted");
            return null; // no size-1 cuz currPieces is supossed to be the next
        }

        Pair<ArrayList<ActivityProduction>, ArrayList<ActivityTransportToMachines>> activitiesProductionAndTransport = new Pair<ArrayList<ActivityProduction>, ArrayList<ActivityTransportToMachines>>(
                activitiesProduction, activitiesTransportToMachines);

        return activitiesProductionAndTransport;

    }

    // Isto passa warehouse por referencia
    private int scheduleUnloading(ArrayList<Piece> inPieces, int lastPossibleDay, Warehouse warehouse,
            ArrayList<Day> inDays) {

        if (inPieces == null || lastPossibleDay < this.currDay || inDays.size() == 0) {
            System.out.println("Schedule Unloading: ret -1");
            return -1;
        }

        ArrayList<ActivityUnloading> activitiesUnloading = scheduleUnloadingTask(lastPossibleDay,
                TimeConstants.getUnloadingTransportTime(), inPieces,
                inDays);

        if (activitiesUnloading == null) {
            return -1;
        }

        // if cant schedule task, order is not possible
        if (activitiesUnloading.isEmpty()) {
            System.out.println("Schedule Unloading: Coudnt insert activities unloading, ret -1");
            return -1;
        }

        for (ActivityUnloading currActivityUnloading : activitiesUnloading) {
            inDays.get(currActivityUnloading.getDay()).addToDayActivityListSorted(currActivityUnloading);
        }
        // so uma order de cada vez logo:
        // isto nao é aqui, o inloading é calculado primerio logo o warehouse é
        // anteriror (nao é alterado)
        // warehouse.removePiecesFromWarehouseByPieceId(inPieces);

        return activitiesUnloading.get(activitiesUnloading.size() - 1).getDay();
    }

    private ArrayList<ActivityUnloading> scheduleUnloadingTask(int lastPossibleDay, int minActivityDuration,
            ArrayList<Piece> inPieces, ArrayList<Day> inDays) {

        int orderId = inPieces.get(0).getOrderId();

        ArrayList<ActivityUnloading> activitiesUnloading = new ArrayList<ActivityUnloading>();

        int currPieceIndex = 0;

        // go trough all days from last possible
        for (int currDayIndex = lastPossibleDay; currDayIndex >= 0; currDayIndex--) {
            // if have inserted all pieces break
            if (currPieceIndex > inPieces.size() - 1)
                break;

            Day currDay = inDays.get(currDayIndex);

            ArrayList<Slot> freeSlots = currDay.calculateFreeSlotsByActivity(currDay.getDayActivityList(),
                    ActivityType.Unloading);
            // i want to start checking from last free slot, its better to try to insert
            // unloading in the end of the day
            Collections.sort(freeSlots, Comparator.comparingInt(Slot::getEndTime));

            // go trough all free slots
            for (Slot currFreeSlot : freeSlots) {
                // if have inserted all pieces break
                if (currPieceIndex > inPieces.size() - 1)
                    break;

                int availableDuration = currFreeSlot.calculateDuration();

                if (availableDuration >= minActivityDuration) {

                    ArrayList<Piece> piecesToTryToUnload = new ArrayList<Piece>(
                            inPieces.subList(currPieceIndex, inPieces.size() - 1)); // last element is exclusive
                    piecesToTryToUnload.add(inPieces.get(inPieces.size() - 1)); // add last

                    // create Activity Unloading
                    Pair<Integer, ArrayList<Piece>> timePiecesPair = calculatePiecesIntoActivity(piecesToTryToUnload,
                            availableDuration, TimeConstants.getUnloadingTransportTime(),
                            TimeConstants.getPoppingOutWarehouse(), TimeConstants.getPoppingInUnloading(), 0, null);
                    if (timePiecesPair == null)
                        continue;

                    int activityDuration = timePiecesPair.getKey();
                    ArrayList<Piece> piecesToUnload = new ArrayList<Piece>();
                    if (timePiecesPair.getValue() == null)
                        continue;

                    for (Piece currPieceToAddToUnload : timePiecesPair.getValue()) {
                        currPieceToAddToUnload.setFinishedDispatchDate(currDayIndex + 1); // +1 cuz currDay is index
                        piecesToUnload.add(currPieceToAddToUnload);
                    }

                    ArrayList<UnloadingDockType> unloadingDocks = new ArrayList<UnloadingDockType>();
                    unloadingDocks.add(UnloadingDockType.UnloadingDock1);
                    if (piecesToUnload.size() > 4)
                        unloadingDocks.add(UnloadingDockType.UnloadingDock2);

                    // i want to insert as late as possible
                    int endTime = currFreeSlot.getEndTime();
                    int startTime = endTime - activityDuration;
                    ActivityUnloading activityUnloading = new ActivityUnloading(startTime, endTime, endTime - startTime,
                            orderId, currDayIndex, piecesToUnload, unloadingDocks);

                    // add activity and increment currPieceIndex
                    currPieceIndex += activityUnloading.getPiecesToUnload().size() - 1 + 1; // -1 cuz index +1 cuz i
                                                                                            // want next
                    activitiesUnloading.add(activityUnloading);
                }
            }
        }
        // no size -1 cuz currPieceIndex is next
        if (currPieceIndex != inPieces.size()) {
            System.out.println("Schedule Unloading Task: Pieces were not inserted");
            return null; // no size-1 cuz currPieces is supossed to be the next
        }
        return activitiesUnloading;
    }

    private Pair<Integer, ArrayList<Piece>> calculatePiecesIntoActivity(ArrayList<Piece> pieces, int availableDuration,
            int transportTime, int poppingOutTime, int poppingInTime, int machinningTime, ToolType neededTool) {

        ArrayList<Piece> piecesIntoActivity = new ArrayList<Piece>();

        // 1st piece
        Piece currPiece = pieces.get(0);
        int activityDuration = transportTime + poppingOutTime + poppingInTime + machinningTime;
        availableDuration -= transportTime + poppingOutTime + poppingInTime + machinningTime;
        if (availableDuration < 0)
            return null;

        piecesIntoActivity.add(currPiece);

        int i = 1;

        int moreMachinningTime = 0;

        // while i have time and havent inserted all
        while (availableDuration > poppingOutTime + poppingInTime + moreMachinningTime
                && pieces.size() > piecesIntoActivity.size()) {

            currPiece = pieces.get(i);
            piecesIntoActivity.add(currPiece);

            activityDuration += poppingOutTime + poppingInTime + moreMachinningTime;
            availableDuration -= poppingOutTime + poppingInTime + moreMachinningTime;

            moreMachinningTime = 0;

            if (neededTool != null) {
                if ((neededTool == ToolType.T1 && i % 3 == 0) || (neededTool == ToolType.T2 && i % 2 == 0)
                        || (neededTool == ToolType.T3 && i % 4 == 0) || (neededTool == ToolType.T4 && i % 3 == 0)) {
                    moreMachinningTime = machinningTime;
                    System.out.println("MORE MACHINNING TIME, ToolTyoe: " + neededTool + " on i: " + i);
                }
            }

            i++;

        }

        Pair<Integer, ArrayList<Piece>> timePiecesPair = new Pair<Integer, ArrayList<Piece>>(activityDuration,
                piecesIntoActivity);

        return timePiecesPair;
    }

    // days is changed by referance
    private void addDaysToDayListSorted(int lastDayIndex, ArrayList<Day> days) {

        int startDayIndex = Math.max(0, days.size() /*- 1*/); // no -1 cuz i want next

        // dont need to create day if it alredy exists
        if (lastDayIndex < startDayIndex)
            return;

        for (int i = startDayIndex; i <= lastDayIndex; i++) {
            days.add(new Day(i));
            // System.out.println("i: " + i);
        }

    }

    private int calculateRealDueDateIndex(int dueDate) {

        // cuz 1st day is index 0
        int dueDateIndex = dueDate - 1;

        if (dueDateIndex < this.currDay)
            return -1;

        return dueDateIndex + this.currDay;
    }

    @Override
    public String toString() {

        StringBuilder sb = new StringBuilder();

        for (Day day : this.dayList) {
            if (day.getDayActivityList().isEmpty()) {
                continue;
            }

            sb.append(day.toString());
            sb.append("\n");
        }
        return sb.toString();
    }

    public static void main(String[] args) throws Exception {

        int startDay = 0;
        int dueDate = 30;
        int quantity = 6;
        PieceType pieceType = PieceType.P8;

        Piece freePieceToAdd = new Piece(-1, PieceType.P1);
        ArrayList<Piece> storedPieces = new ArrayList<Piece>();
        for (int i = 0; i < 4; i++) {
            storedPieces.add(freePieceToAdd);
        }

        Warehouse warehouse = new Warehouse(storedPieces);
        NewMasterProductionSchedule newMasterProductionSchedule = new NewMasterProductionSchedule(startDay,
                Machine.getMachinesList(), ToolType.T3, warehouse);

        OrderInfo orderInfo = new OrderInfo("FEUP", 8, pieceType, quantity, dueDate, 2, 1);

        newMasterProductionSchedule.addNewOrderAndPlan(orderInfo);

        System.out.println(newMasterProductionSchedule.toString());
        System.out.println("plan.day.size: " + newMasterProductionSchedule.getDayList().size());
    }

    public int getCurrDay() {
        return currDay;
    }

    public void setCurrDay(int currDay) {
        System.out.println("-------------------------------Updated day to: " + currDay);
        this.currDay = currDay;
    }

    public ArrayList<Day> getDayList() {
        return dayList;
    }

    public void setDayList(ArrayList<Day> dayList) {
        this.dayList = dayList;
    }

    public ArrayList<Machine> getMachineList() {
        return machineList;
    }

    public void setMachineList(ArrayList<Machine> machineList) {
        this.machineList = machineList;
    }

    public ArrayList<OrderInfo> getOrdersList() {
        return ordersList;
    }

    public void setOrdersList(ArrayList<OrderInfo> ordersList) {
        this.ordersList = ordersList;
    }

    public Warehouse getWarehouse() {
        return warehouse;
    }

    public void setWarehouse(Warehouse warehouse) {
        this.warehouse = warehouse;
    }

    public void setCurrTime(int currTime) {
        System.out.println("-------------------------------Update curr time: " + currTime);
        this.currTime = currTime;
    }

}
