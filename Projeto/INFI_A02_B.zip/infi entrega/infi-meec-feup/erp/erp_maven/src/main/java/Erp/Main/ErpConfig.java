package Erp.Main;

public class ErpConfig {
    final static Boolean ERP_STANDALONE_VERSION = false;
    final static Boolean USE_TEST_DAY = false && !ERP_STANDALONE_VERSION;
}
