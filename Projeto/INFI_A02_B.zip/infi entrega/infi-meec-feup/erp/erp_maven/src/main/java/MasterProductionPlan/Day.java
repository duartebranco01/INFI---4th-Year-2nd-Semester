package MasterProductionPlan;

import java.io.Serializable;
import java.util.*;

import Common.Machine.*;
import Common.Piece.Piece;
import Common.Piece.PieceType;
import Common.Suppliers.SupplierType;
import Products.UnloadingDockType;

public class Day implements Serializable {

    private int currDay;
    ArrayList<Activity> dayActivityList;

    public static Day produceT7_test() {

        Piece peice = new Piece(0, 0, 0, PieceType.P7);
        ArrayList<Piece> pieceList = new ArrayList<Piece>();
        pieceList.add(peice);

        ActivityProduction actProd1 = new ActivityProduction(50, 0, pieceList, 0);
        ActivityProduction actProd2 = new ActivityProduction(50, 0, pieceList, 1);

        ArrayList<Activity> actList1 = new ArrayList<Activity>();

        actList1.add(actProd1);
        actList1.add(actProd2);

        return new Day(1, actList1);
    }

    public void setDayActivityList(ArrayList<Activity> dayActivityList) {
        this.dayActivityList = dayActivityList;
    }

    public Day(int currDay) {
        this.currDay = currDay;
        this.dayActivityList = new ArrayList<Activity>();
    }

    public Day(int currDay, ArrayList<Activity> dayActivityList) {
        this.currDay = currDay;
        this.dayActivityList = dayActivityList;
    }

    public int scheduleDayActivity(Activity inActivity) {

        int ret = -1;

        switch (inActivity.getActivityType()) {

            case Unloading:

                ret = insertIntoActivityListAnySlot(inActivity, 0, 60);

                break;

            case Production:

                ret = insertIntoActivityListAnySlot(inActivity, 0, 60);
                break;

            case Supplies:

                ret = insertIntoActivityListAnySlot(inActivity, 0, 60);
                break;

            case SwitchTools:
                ret = insertIntoActivityListAnySlot(inActivity, 0, 60);
                break;

            default:
                return ret;

        }
        return ret;

    }

    private int insertIntoActivityListAnySlot(Activity inActivity, int timeZero, int timeFinal) {

        if (inActivity == null || timeZero < 0 || timeZero >= 60 || timeFinal < 0 || timeFinal > 60
                || inActivity.getDuration() > 60 || inActivity.getDuration() <= 0)
            return -1;

        ArrayList<Slot> freeSlots = calculateFreeSlotsByActivity(this.dayActivityList,
                inActivity.getActivityType());

        // do this cuz i want supplies to start from the beginning
        if (inActivity.getActivityType() != ActivityType.Supplies)
            Collections.reverse(freeSlots);

        if (freeSlots.isEmpty()) {
            return -1;
        }

        System.out.println("printting free slots");
        System.out.println(freeSlots);

        int startTime = -1;
        int endTime = -1;

        for (Slot currFreeSlot : freeSlots) {

            // check if slot is valid: starts after timeZero, activity end =slotstart +
            // activity duration before timeFinal, has enough duration
            if (currFreeSlot.getStartTime() >= timeZero
                    && currFreeSlot.getStartTime() + inActivity.getDuration() <= timeFinal
                    && currFreeSlot.calculateDuration() >= inActivity.getDuration()) {

                // if supplies start from begginng
                if (inActivity.getActivityType() == ActivityType.Supplies) {
                    startTime = currFreeSlot.getStartTime();
                    endTime = startTime + inActivity.getDuration();
                }
                // everything else cant start from the end
                else {
                    endTime = currFreeSlot.getEndTime();
                    startTime = endTime - inActivity.getDuration();
                }

                System.out.println("-----------startTime: " + startTime);
                System.out.println("-----------endTime: " + endTime);

                inActivity.setActivityStartTime(startTime);
                inActivity.setActivityEndTime(endTime);

                break;

            }
        }

        System.out.println("startTime: " + startTime);
        System.out.println("endTime: " + endTime);

        if (startTime < timeZero || endTime > timeFinal || startTime == -1 || endTime == -1)
            return -1;

        addToDayActivityListSorted(inActivity);

        return 0;
    }

    void addToDayActivityListSorted(Activity inActivity) {

        int currActivityIdex = 0;

        if (this.dayActivityList.size() == 0)
            this.dayActivityList.add(inActivity);
        else {

            ArrayList<Activity> reversedActivityList = new ArrayList<Activity>(this.dayActivityList);
            Collections.reverse(reversedActivityList);

            for (Activity currActivity : reversedActivityList) {
                if (inActivity.getStartTime() >= currActivity.getStartTime()) {
                    break;
                }
                currActivityIdex++;
            }

            int originalCurrActivityIndex = this.dayActivityList.size() - 1 - currActivityIdex;

            // +1 cuz need to add after currActivity
            this.dayActivityList.add(originalCurrActivityIndex + 1, inActivity);
        }
    }

    public ArrayList<Slot> calculateOcupiedSlotsByActivity(ArrayList<Activity> activitiesList,
            ActivityType activityType) {

        ArrayList<Slot> occupiedSlotsList = new ArrayList<Slot>();

        for (Activity currActivity : activitiesList) {
            if (currActivity.getActivityType() == activityType) {
                Slot occupiedSlot = new Slot(currActivity.getStartTime(), currActivity.getEndTime());
                occupiedSlotsList.add(occupiedSlot);
            }
        }

        return occupiedSlotsList;

    }

    public ArrayList<Slot> calculateNotFreeSlotsByActivity(ArrayList<Activity> activitiesList,
            ActivityType activityType) {

        ArrayList<Slot> notFreeSlotsList = new ArrayList<Slot>();

        if (activityType == ActivityType.Unloading) {

            notFreeSlotsList.addAll(calculateOcupiedSlotsByActivity(activitiesList, ActivityType.Supplies));
            notFreeSlotsList.addAll(calculateOcupiedSlotsByActivity(activitiesList, ActivityType.TransportToMachines));
            notFreeSlotsList.addAll(calculateOcupiedSlotsByActivity(activitiesList, ActivityType.Production));
            notFreeSlotsList.addAll(calculateOcupiedSlotsByActivity(activitiesList, ActivityType.Unloading));

        } else if (activityType == ActivityType.Production) {

            notFreeSlotsList.addAll(calculateOcupiedSlotsByActivity(activitiesList, ActivityType.Supplies));
            notFreeSlotsList.addAll(calculateOcupiedSlotsByActivity(activitiesList, ActivityType.SwitchTools));
            notFreeSlotsList.addAll(calculateOcupiedSlotsByActivity(activitiesList, ActivityType.TransportToMachines));
            notFreeSlotsList.addAll(calculateOcupiedSlotsByActivity(activitiesList, ActivityType.Production));
            notFreeSlotsList.addAll(calculateOcupiedSlotsByActivity(activitiesList, ActivityType.Unloading));

        } else if (activityType == ActivityType.SwitchTools) {

            notFreeSlotsList.addAll(calculateOcupiedSlotsByActivity(activitiesList, ActivityType.SwitchTools));
            notFreeSlotsList.addAll(calculateOcupiedSlotsByActivity(activitiesList, ActivityType.Production));

        } else if (activityType == ActivityType.Supplies) {

            notFreeSlotsList.addAll(calculateOcupiedSlotsByActivity(activitiesList, ActivityType.Supplies));
            notFreeSlotsList.addAll(calculateOcupiedSlotsByActivity(activitiesList, ActivityType.TransportToMachines));
            notFreeSlotsList.addAll(calculateOcupiedSlotsByActivity(activitiesList, ActivityType.Production));
            notFreeSlotsList.addAll(calculateOcupiedSlotsByActivity(activitiesList, ActivityType.Unloading));

        } else if (activityType == ActivityType.TransportToMachines) {
            notFreeSlotsList.addAll(calculateOcupiedSlotsByActivity(activitiesList, ActivityType.Supplies));
            notFreeSlotsList.addAll(calculateOcupiedSlotsByActivity(activitiesList, ActivityType.TransportToMachines));
            notFreeSlotsList.addAll(calculateOcupiedSlotsByActivity(activitiesList, ActivityType.Production));
            notFreeSlotsList.addAll(calculateOcupiedSlotsByActivity(activitiesList, ActivityType.Unloading));
        }

        return notFreeSlotsList;

    }

    public ArrayList<Slot> calculateFreeSlotsByActivity(ArrayList<Activity> activitiesList, ActivityType activityType) {

        ArrayList<Slot> freeSlotsList = new ArrayList<Slot>();

        ArrayList<Slot> notFreeSlotsList = calculateNotFreeSlotsByActivity(activitiesList, activityType);

        // dar sort para nao haver coisas estranhas
        Collections.sort(notFreeSlotsList, Comparator.comparingInt(Slot::getStartTime));

        if (notFreeSlotsList.isEmpty()) {
            Slot freeSlot = new Slot(0, 60);
            freeSlotsList.add(freeSlot);
        } else {

            if (notFreeSlotsList.get(0).getStartTime() > 0) {
                Slot freeSlot = new Slot(0, notFreeSlotsList.get(0).getStartTime());
                freeSlotsList.add(freeSlot);
                // System.out.println("------berfore 1st");
            }

            // between two freeSlots,<.size() -1 cuz i want to stop at 2nd last
            for (int currNotFreeSlotIndex = 0; currNotFreeSlotIndex < notFreeSlotsList.size()
                    - 1; currNotFreeSlotIndex++) {

                // freeSlot existe entre o fim do notFree atual e o start do notFree seguinte
                if (notFreeSlotsList.get(currNotFreeSlotIndex + 1).getStartTime()
                        - notFreeSlotsList.get(currNotFreeSlotIndex).getEndTime() > 0) {
                    Slot freeSlot = new Slot(notFreeSlotsList.get(currNotFreeSlotIndex).getEndTime(),
                            notFreeSlotsList.get(currNotFreeSlotIndex + 1).getStartTime());
                    freeSlotsList.add(freeSlot);
                    // System.out.println("-----between");
                }

            }

            // after last notFree slot, if there is only 1 not free it is also the last so
            // it checks
            if (notFreeSlotsList.get(notFreeSlotsList.size() - 1).getEndTime() < 60) {
                Slot freeSlot = new Slot(notFreeSlotsList.get(notFreeSlotsList.size() - 1).getEndTime(), 60);
                freeSlotsList.add(freeSlot);
                // System.out.println("------after last");
            }
        }

        return freeSlotsList;
        //
    }

    // ic ArrayList<Slot> calculateFreeSlots(ArrayList<Activity> activitiesList) {

    // ArrayList<Slot> freeSlots = new ArrayList<Slot>();

    // vity currActivity = null;
    // Activity nextActivity = null;

    // if (activitiesList.isEmpty()) {

    // Slot freeSlot = new Slot(0, 60);

    // Slots.add(freeSlot);
    // se {
    // // if slot before 1st activity
    // if (activitiesList.get(0).getActivityStartTime() > 0) {
    // Slot freeSlot = new Slot(0, activitiesList.get(0).getActivityStartTime());
    // freeSlots.add(freeSlot);
    //

    // // if slot between activities
    // (int i = 0; i < activitiesList.size() - 1; i++) {
    //

    // = activitiesList.get(i);
    // Activity = activitiesList.get(i + 1);

    // if (nextActivity.getActivityStartTime() - currActivity.getActivityEndTime() >
    // 0) {
    // Slot freeSlot = new Slot(currActivity.getActivityEndTime(),
    // nextActivity.getActivityStartTime());
    //
    // freeSlots.add(freeSlot);
    //
    // }
    // }
    // // if slot after last activity
    // if (60 - activitiesList.get(activitiesList.size() - 1).getActivityEndTime() >
    // 0) {
    // Slot freeSlot = new Slot(activitiesList.get(activitiesList.size() -
    // 1).getActivityEndTime(), 60);
    // freeSlots.add(freeSlot);
    // }
    // }

    // return freeSlots;
    // }

    public int getCurrDay() {
        return currDay;
    }

    public ArrayList<Activity> getDayActivityList() {
        return this.dayActivityList;
    }

    public void setCurrDay(int currDay) {
        this.currDay = currDay;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Day ").append(currDay).append(": \n");
        for (Activity activity : this.dayActivityList) {
            sb.append(activity.toString()).append("\n");
        }
        return sb.toString();
    }

    public static void main(String[] args) throws Exception {

        Day day = new Day(1);
        // Activity activity1 = new Activity(ActivityType.Unloading, 20, 1);
        // Activity activity2 = new Activity(ActivityType.Production, 4, 2);
        // Activity activity3 = new Activity(ActivityType.Unloading, 4, 3);
        // Activity activity4 = new Activity(ActivityType.Production, 4, 4);
        // Activity activity5 = new Activity(ActivityType.SwitchTools, 4, 5);
        // Activity activity6 = new Activity(ActivityType.Supplies, 4, 6);

        Piece p10 = new Piece(1, 0, 10, PieceType.P8);
        Piece p11 = new Piece(1, 1, 10, PieceType.P8);
        Piece p12 = new Piece(1, 2, 10, PieceType.P8);
        Piece p13 = new Piece(1, 3, 10, PieceType.P8);
        ArrayList<Piece> piecesFromSupplier1 = new ArrayList<Piece>();
        piecesFromSupplier1.add(p10);
        piecesFromSupplier1.add(p11);
        piecesFromSupplier1.add(p12);
        piecesFromSupplier1.add(p13);
        Piece p23 = new Piece(2, 3, 1, PieceType.P8);
        Piece p24 = new Piece(2, 4, 1, PieceType.P8);
        Piece p25 = new Piece(2, 5, 1, PieceType.P8);
        ArrayList<Piece> piecesFromSupplier2 = new ArrayList<Piece>();
        piecesFromSupplier2.add(p23);
        piecesFromSupplier2.add(p24);
        piecesFromSupplier2.add(p25);
        ActivitySupplies activity1 = new ActivitySupplies(null, 10, 1, 0, 0, 0, null, piecesFromSupplier1);
        activity1.setSupplier(SupplierType.A);
        // ActivitySupplies activity2 = new ActivitySupplies(15, 1, SupplierType.A/* ,
        // piecesFromSupplier2*/);

        ArrayList<MachineType> machineToChange = new ArrayList<MachineType>();
        machineToChange.add(MachineType.M1);

        ArrayList<UnloadingDockType> unloadingDocks = new ArrayList<UnloadingDockType>();
        unloadingDocks.add(UnloadingDockType.UnloadingDock1);

        // System.out.println(activity1.toString());

        int ret1 = day.scheduleDayActivity(activity1);
        // int ret2 = day.scheduleDayActivity(activity2);
        // int ret3 = day.scheduleDayActivity(activity3);
        // int ret4 = day.scheduleDayActivity(activity4);
        // int ret5 = day.scheduleDayActivity(activity5);
        // int ret6 = day.scheduleDayActivity(activity6);

        System.out.println(day.toString());
        System.out.println("day.dayActivityList.size(): " + day.dayActivityList.size());
        System.out.println("ret1:" + ret1);

        Day dayClone = (Day) ObjectCloner.deepCopy(day);
        System.out.println("----------------------------------------DAYCLONE");
        System.out.println(dayClone.toString());
        // System.out.println("ret2:" + ret2);
        // System.out.println("ret3:" + ret3);
        // System.out.println("ret4:" + ret4);
        // System.out.println("ret5:" + ret5);
        // System.out.println("ret6:" + ret6);

        // System.out.println(day.calculateFreeSlots(day.dayActivityList).toString());

        System.out.println("Bazinga, revert para o pomx a dar");

    }

}
