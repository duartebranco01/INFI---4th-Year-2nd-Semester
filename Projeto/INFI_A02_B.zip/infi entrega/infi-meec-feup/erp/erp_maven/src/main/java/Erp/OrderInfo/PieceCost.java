package Erp.OrderInfo;

import Common.Piece.PieceType;
import Common.Suppliers.SupplierType;

//hello
public class PieceCost {
    private static int checkRawMaterialPrice(SupplierType supplierType, PieceType pieceType) {

        int rawMaterialPrice = 0;

        if (supplierType == SupplierType.A) {

            if (pieceType == PieceType.P1)
                rawMaterialPrice = 30;
            else if (pieceType == PieceType.P2)
                rawMaterialPrice = 10;
        } else if (supplierType == SupplierType.B) {

            if (pieceType == PieceType.P1)
                rawMaterialPrice = 45;
            else if (pieceType == PieceType.P2)
                rawMaterialPrice = 15;
        } else if (supplierType == SupplierType.C) {

            if (pieceType == PieceType.P1)
                rawMaterialPrice = 55;
            else if (pieceType == PieceType.P2)
                rawMaterialPrice = 18;
        }
        return rawMaterialPrice;
    }

    private static int calculateProductionCost(int totalProductionTime) {
        return totalProductionTime * 1;
    }

    private static int calculateDepreciationCost(int arrivalDate, int dispatchDate, int rawMaterialCost) {
        int depreciationCost = rawMaterialCost * (dispatchDate - arrivalDate) * (1 / 100);
        return depreciationCost;
    }

    public static int calculateTotalPieceCost(SupplierType supplierType, PieceType rawPieceType,
            int totalProductionTime,
            int suppliedArrivalDate, int finishedDispatchDate) {
        int rawMaterialCost = checkRawMaterialPrice(supplierType, rawPieceType);
        return rawMaterialCost + calculateProductionCost(totalProductionTime)
                + calculateDepreciationCost(suppliedArrivalDate, finishedDispatchDate, rawMaterialCost);
    }

}
