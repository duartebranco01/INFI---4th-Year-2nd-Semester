package Common.Piece;

import java.io.Serializable;
import java.util.ArrayList;

import Common.Suppliers.SupplierType;

public class Piece implements Cloneable, Serializable {
    // ids for tracking
    private int orderId;
    private int pieceId;

    // information from production time for statistics
    private SupplierType supplier;

    private int suppliedArrivalDate;
    private int totalMachinningTime;

    private int dueDate;
    private int finishedDispatchDate;

    // piece type status
    private PieceType rawStartType;
    private PieceType finalType;

    private ArrayList<Transition> orderedTransitionsList;

    // new constructor
    public Piece(int orderId, int pieceId, int dueDate, PieceType finalType, SupplierType supplier) {

        this.orderId = orderId;
        this.pieceId = pieceId;
        this.supplier = supplier;
        this.dueDate = dueDate;
        this.finalType = finalType;

        this.orderedTransitionsList = decomposeInTransitionsList();
        this.totalMachinningTime = calculateTotalProductionTime(this.orderedTransitionsList);

        this.rawStartType = this.orderedTransitionsList.get(0).getStartType();
    }

    // new constructor for free piece
    public Piece(int orderId, PieceType rawStartType, SupplierType supplier) {
        this.orderId = orderId;
        this.pieceId = -1;
        this.rawStartType = rawStartType;
        this.supplier = supplier;
        this.dueDate = -1;
        this.rawStartType = rawStartType;
        this.finalType = rawStartType;
        this.orderedTransitionsList = new ArrayList<Transition>();
    }

    public Piece(int orderId, int pieceId, int dueDate, PieceType finalType) {

        this.orderId = orderId;
        this.pieceId = pieceId;
        this.dueDate = dueDate;
        this.finalType = finalType;

        // this.currTransitionIndex = 0;

        this.orderedTransitionsList = decomposeInTransitionsList();
        this.totalMachinningTime = calculateTotalProductionTime(this.orderedTransitionsList);

        // if cuz of freePiece
        if (this.orderedTransitionsList.isEmpty())
            this.rawStartType = finalType;
        else
            this.rawStartType = this.orderedTransitionsList.get(0).getStartType();
        // currType = rawStartType;
    }

    // constructor for free piece
    public Piece(int orderId, PieceType rawStartType) {
        this.orderId = orderId;
        this.pieceId = -1;
        this.rawStartType = rawStartType;
        this.dueDate = -1;
        this.rawStartType = rawStartType;
        this.finalType = rawStartType;
    }

    private int calculateTotalProductionTime(ArrayList<Transition> transitions) {

        int totalProductionTime = 0;

        for (Transition currTransition : transitions) {
            totalProductionTime += currTransition.getMachiningTime();
        }
        return totalProductionTime;
    }

    public ArrayList<Transition> decomposeInTransitionsList() {
        ArrayList<Transition> transitionsList = new ArrayList<>();

        if (getFinalType() == PieceType.P3) {
            transitionsList.add(new Transition(this.pieceId, this.dueDate, 1, PieceType.P2, PieceType.P3));
        } else if (getFinalType() == PieceType.P4) {

            transitionsList.add(new Transition(this.pieceId, this.dueDate, 1, PieceType.P2, PieceType.P4));
        } else if (getFinalType() == PieceType.P5) {

            transitionsList.add(new Transition(this.pieceId, this.dueDate, 1, PieceType.P2, PieceType.P4));
            transitionsList.add(new Transition(this.pieceId, this.dueDate, 2, PieceType.P4, PieceType.P7));
            transitionsList.add(new Transition(this.pieceId, this.dueDate, 3, PieceType.P7, PieceType.P9));
            transitionsList.add(new Transition(this.pieceId, this.dueDate, 4, PieceType.P9, PieceType.P5));
        } else if (getFinalType() == PieceType.P6) {
            transitionsList.add(new Transition(this.pieceId, this.dueDate, 1, PieceType.P1, PieceType.P6));
        } else if (getFinalType() == PieceType.P7) {

            transitionsList.add(new Transition(this.pieceId, this.dueDate, 1, PieceType.P2, PieceType.P4));
            transitionsList.add(new Transition(this.pieceId, this.dueDate, 2, PieceType.P4, PieceType.P7));
        } else if (getFinalType() == PieceType.P8) {
            transitionsList.add(new Transition(this.pieceId, this.dueDate, 1, PieceType.P1, PieceType.P6));
            transitionsList.add(new Transition(this.pieceId, this.dueDate, 2, PieceType.P6, PieceType.P8));
        } else if (getFinalType() == PieceType.P9) {

            transitionsList.add(new Transition(this.pieceId, this.dueDate, 1, PieceType.P2, PieceType.P4));
            transitionsList.add(new Transition(this.pieceId, this.dueDate, 2, PieceType.P4, PieceType.P7));
            transitionsList.add(new Transition(this.pieceId, this.dueDate, 3, PieceType.P7, PieceType.P9));
        }

        return transitionsList;
    }

    public void updateInfoFromProduction(int totalProductionTime, int finishedDispatchDate) {

        this.totalMachinningTime = totalProductionTime;
        this.finishedDispatchDate = finishedDispatchDate;
    }

    // public PieceType getCurretnPieceType() {
    // int index = this.currTransitionIndex;
    // Transition transition = this.orderedTransitionsList.get(index);
    // return transition.getStartType();
    // }

    @Override
    public String toString() {
        return "\n\t\tPiece{\n" +
                " \t\t\t pieceId=" + pieceId
                // ",\n \t\t\t productionTime=" + productionTime +
                // ",\n \t\t\t finishedDispatchDate=" + finishedDispatchDate +
                // ",\n \t\t\t orderId=" + orderId +
                // ",\n \t\t\t priority=" + priority +
                // ",\n \t\t\t rawStartType=" + rawStartType +
                // ",\n \t\t\t currType=" + currType +
                // ",\n \t\t\t finalType=" + finalType +
                // // ",\n \t\t\t currPos=" + currTransitionIndex +
                // ",\n \t\t\t transitionsList=" + orderedTransitionsList +
                + "\t\t\t totalMachiningTime: " + this.totalMachinningTime
                + "\t\t\t suppliedDay: " + this.suppliedArrivalDate
                + "\t\t\t dueDate: " + this.dueDate
                + "\t\t\t finishedDay: " + this.finishedDispatchDate
                + "\n}";
    }

    public PieceType getFinalType() {
        return this.finalType;
    }

    public void setFinalType(PieceType finalType) {
        this.finalType = finalType;
    }

    public int getOrderId() {
        return this.orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getPieceId() {
        return this.pieceId;
    }

    public void setPieceId(int pieceId) {
        this.pieceId = pieceId;
    }

    public int getTotalMachinningTime() {
        return this.totalMachinningTime;
    }

    public void setTotalMachinningTime(int productionTime) {
        this.totalMachinningTime = productionTime;
    }

    public int getFinishedDispatchDate() {
        return this.finishedDispatchDate;
    }

    public void setFinishedDispatchDate(int finishedDispatchDate) {
        this.finishedDispatchDate = finishedDispatchDate;
    }

    public void setSupplier(SupplierType supplier) {
        this.supplier = supplier;
    }

    public SupplierType getSupplierType() {
        return this.supplier;
    }

    public int getDueDate() {
        return this.dueDate;
    }

    public void setDueDate(int dueDate) {
        this.dueDate = dueDate;
    }

    public PieceType getRawStartType() {
        return this.rawStartType;
    }

    public void setRawStartType(PieceType rawStartType) {
        this.rawStartType = rawStartType;
    }

    // public PieceType getCurrType() {
    // return this.currType;
    // }

    // public void setCurrType(PieceType currType) {
    // this.currType = currType;
    // }

    public ArrayList<Transition> getOrderedTransitionsList() {
        return this.orderedTransitionsList;
    }

    public void setOrderedTransitionsList(ArrayList<Transition> orderedTransitionsList) {
        this.orderedTransitionsList = orderedTransitionsList;
    }

    public int getSuppliedArrivalDate() {
        return this.suppliedArrivalDate;
    }

    public void setSuppliedArrivalDate(int suppliedArrivalDate) {
        this.suppliedArrivalDate = suppliedArrivalDate;
    }

    @Override
    public Piece clone() {
        try {
            Piece clone = (Piece) super.clone();
            clone.orderedTransitionsList = new ArrayList<Transition>();

            for (Transition currTransition : this.orderedTransitionsList) {
                clone.orderedTransitionsList.add(currTransition.clone());
            }

            return clone;

        } catch (Exception e) {
            System.out.println(e.toString());
            return null;
        }
    }
}
