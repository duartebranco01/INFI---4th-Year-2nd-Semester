package Products;

public enum UnloadingDockType {

    UnloadingDock1(10),
    UnloadingDock2(15);

    private final int timeToUnloadingDock;

    UnloadingDockType(int timeToUnloadingDock) {
        this.timeToUnloadingDock = timeToUnloadingDock;
    }

    public int getTimteToUnloadingDock() {
        return this.timeToUnloadingDock;
    }

}