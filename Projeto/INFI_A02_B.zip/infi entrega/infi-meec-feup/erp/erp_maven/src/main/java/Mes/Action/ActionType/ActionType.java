package Mes.Action.ActionType;

import java.util.concurrent.ExecutionException;

import Common.TimeCounting.FactoryTimeFormat;

public interface ActionType {

    public void execute() throws InterruptedException, ExecutionException;

    public FactoryTimeFormat getDuration();

    public String getName();

    public String toString();

}
