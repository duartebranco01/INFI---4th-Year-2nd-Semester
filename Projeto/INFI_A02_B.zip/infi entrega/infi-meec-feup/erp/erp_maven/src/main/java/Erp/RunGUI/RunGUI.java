package Erp.RunGUI;

import java.io.IOException;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

import Erp.Gui.DayGUI;
import Erp.Gui.HelloApplication;
import Erp.Gui.OrderCostGUI;
import Erp.Gui.PurchasingPlanGUI;
import MasterProductionPlan.Day;
import MasterProductionPlan.*;
import Products.Warehouse;
import Common.Communication.SQL.InsertIntoTablesERP;
import Common.Communication.Tcp.*;
import Common.Communication.Udp.*;
import Common.Machine.Machine;
import Common.Machine.ToolType;
import Common.Piece.Piece;
import Common.Piece.PieceType;
import Erp.OrderInfo.OrderInfo;
import Erp.OrderInfo.PieceCost;
import Erp.OrderInfo.XmlParser;
import Common.Constants.*;
import Common.TimeCounting.*;

public class RunGUI {

    public static void main(String[] args) throws Exception {

         HelloApplication.startGUI();

    }
}
