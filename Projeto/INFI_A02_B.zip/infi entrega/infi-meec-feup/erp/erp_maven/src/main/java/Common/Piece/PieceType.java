package Common.Piece;

public enum PieceType {
    P1,
    P2,
    P3,
    P4,
    P5,
    P6,
    P7,
    P8,
    P9;

    public static PieceType fromString(String str) {
        switch (str.toUpperCase()) {
            case "P1":
                return PieceType.P1;
            case "P2":
                return PieceType.P2;
            case "P3":
                return PieceType.P3;
            case "P4":
                return PieceType.P4;
            case "P5":
                return PieceType.P5;
            case "P6":
                return PieceType.P6;
            case "P7":
                return PieceType.P7;
            case "P8":
                return PieceType.P8;
            case "P9":
                return PieceType.P9;
            default:
                throw new IllegalArgumentException("Invalid PieceType: " + str);
        }
    }

    public int toInt() {
        switch (this) {
            case P1:
                return 1;
            case P2:
                return 2;
            case P3:
                return 3;
            case P4:
                return 4;
            case P5:
                return 5;
            case P6:
                return 6;
            case P7:
                return 7;
            case P8:
                return 8;
            case P9:
                return 9;
            default:
                throw new IllegalStateException("Unhandled PieceType: " + this);
        }
    }

}