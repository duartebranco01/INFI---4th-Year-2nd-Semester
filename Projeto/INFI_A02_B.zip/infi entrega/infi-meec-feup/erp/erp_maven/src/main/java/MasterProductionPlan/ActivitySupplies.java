package MasterProductionPlan;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import Common.Piece.Piece;
import Common.Piece.PieceType;
import Common.Suppliers.SupplierType;
import Products.*;
import javafx.util.Pair;
//import Products.PieceType;

public class ActivitySupplies extends Activity {

    // masterplan checka o warehouse para ver se tem peças livres, e se tiver aloca
    // warehouse.addPiecesToWarehouse em que adicionas as peças que faltam
    // correctOrderedPieces
    // suppliesDeliveryTime

    // this.piecesFromSupplier = piecesFromSupplier;

    private SupplierType supplier;
    private ArrayList<Piece> piecesFromSupplier;

    // public ActivitySupplies(int activityDuration, int orderId, ArrayList<Piece>
    // piecesToOrder/*
    // * ,
    // * int
    // * availableSuppliesWaitTime,
    // * SupplierType supplier,
    // * int warehouseFreeSpac
    // */) {

    // super(ActivityType.Supplies, activityDuration, orderId);
    // this.supplier = null;
    // this.piecesFromSupplier = piecesToOrder;
    // // this.supplier = pickSupplier(piecesToOrder.size(),
    // availableSuppliesWaitTime,
    // // warehouseFreeSpace);

    // }

    public ActivitySupplies(ActivityType activityType, int activityStartTime, int activityEndTime, int activityDuration,
            int orderId, int day, SupplierType supplier, ArrayList<Piece> piecesFromSupplier) {

        super(activityType, activityStartTime, activityEndTime, activityDuration, orderId, day);
        this.supplier = supplier;
        this.piecesFromSupplier = piecesFromSupplier;
    }

    public void setSupplier(SupplierType supplier) {
        this.supplier = supplier;
    }

    public SupplierType getSupplierType() {
        return this.supplier;
    }

    public ArrayList<Piece> getPiecesFromSupplier() {
        return this.piecesFromSupplier;
    }

    public String toString() {
        return super.toString()
                + "\t PieceType: " + piecesFromSupplier.get(0).getRawStartType() + '\n'
                + "\t\t" + this.supplier.toString() + "\n"
                + "\t\t Supplied pieces: " + this.piecesFromSupplier.size()
                + "\t Pieces: " + this.piecesFromSupplier.toString()
                + "\n";
        // + this.piecesFromSupplier.toString() + "\n";
    }

    public void calculateSupplier(int availableSuppliesWaitTime, int warehouseFreeSpace) {
        this.supplier = pickSupplier(this.piecesFromSupplier.size(), availableSuppliesWaitTime, warehouseFreeSpace);
    }

    public static List<SupplierType> getPossibleSupplierByDays(int days) {
        List<SupplierType> possibleSuppliers = new ArrayList<>();

        if (days >= 4) {
            possibleSuppliers.add(SupplierType.A);
            possibleSuppliers.add(SupplierType.B);
            possibleSuppliers.add(SupplierType.C);
        } else if (days < 4 && days >= 2) {
            possibleSuppliers.add(SupplierType.B);
            possibleSuppliers.add(SupplierType.C);
        } else if (days < 2 && days >= 1) {
            possibleSuppliers.add(SupplierType.C);
        }

        return possibleSuppliers;
    }

    public static List<Pair<SupplierType, Integer>> getMinOrderQuantities(List<SupplierType> supplierTypes) {
        List<Pair<SupplierType, Integer>> minOrderQuantities = new ArrayList<>();

        for (SupplierType supplierType : supplierTypes) {
            int minOrderQuantity = 0;

            if (supplierType == SupplierType.A)
                minOrderQuantity = 16;
            else if (supplierType == SupplierType.B)
                minOrderQuantity = 8;
            else if (supplierType == SupplierType.C)
                minOrderQuantity = 4;

            Pair<SupplierType, Integer> pair = new Pair<>(supplierType, minOrderQuantity);
            minOrderQuantities.add(pair);
        }

        return minOrderQuantities;
    }

    public static int checkMinOrderOfSupplier(SupplierType supplierType) {

        int minOrderQuantity = 4;

        if (supplierType == SupplierType.A)
            minOrderQuantity = 16;
        else if (supplierType == SupplierType.B)
            minOrderQuantity = 8;
        else if (supplierType == SupplierType.C)
            minOrderQuantity = 4;

        return minOrderQuantity;
    }

    public static SupplierType pickSupplier(int quantity, int availableDays, int freeSpaceWarehouse) {

        List<SupplierType> possibleSuppliers = getPossibleSupplierByDays(availableDays);

        List<Pair<SupplierType, Integer>> minOrderQuantities = getMinOrderQuantities(possibleSuppliers);
        Collections.sort(minOrderQuantities, Comparator.comparing(Pair::getValue));

        SupplierType selectedSupplierType = null;

        if (!minOrderQuantities.isEmpty()) {
            for (Pair<SupplierType, Integer> pair : minOrderQuantities) {
                if (quantity >= pair.getValue()) {
                    if (pair.getValue() > freeSpaceWarehouse)
                        continue;

                    selectedSupplierType = pair.getKey();
                } else
                    break;

            }
        }

        if (selectedSupplierType == null && quantity <= freeSpaceWarehouse && availableDays >= 1)
            selectedSupplierType = SupplierType.C;

        return selectedSupplierType;
    }

    public int suppliesDeliveryTime(SupplierType supplier) {
        int deliveryTime = 0;

        if (supplier == SupplierType.A)
            deliveryTime = 4;

        else if (supplier == SupplierType.B)
            deliveryTime = 2;

        else if (supplier == SupplierType.C)
            deliveryTime = 1;

        return deliveryTime;
    }

    public int getNumberOfPieces() {
        return this.piecesFromSupplier.size();
    }

    public PieceType getPieceType() {
        return this.piecesFromSupplier.get(0).getRawStartType();
    }

    /*
     * public Pair<SupplierType, Pair<Integer, PieceType>>
     * getOrderSupplierAndQuantity(Warehouse warehouse,
     * int suppliesTime, PieceType rawType, int quantity, int orderID) {
     * 
     * int availableSpace = warehouse.freeSpace();
     * int availablePieces = warehouse.countFreePieces(rawType);
     * int quantityNeedToOrder = 0;
     * 
     * SupplierType supplier = null;
     * 
     * boolean unableToOrder = false;
     * 
     * if (availablePieces > quantity)
     * warehouse.allocateOrderIDToFreePieces(rawType, orderID, quantity);
     * 
     * else if (availablePieces < quantity && suppliesTime >= 1)
     * {
     * if (availablePieces > 0) {
     * quantityNeedToOrder = quantity - availablePieces;
     * 
     * if (availableSpace >= quantityNeedToOrder) {
     * warehouse.allocateOrderIDToFreePieces(rawType, orderID, availablePieces);
     * supplier = pickSupplier(quantityNeedToOrder, suppliesTime, availableSpace);
     * }
     * 
     * else
     * unableToOrder = true;
     * 
     * }
     * 
     * else if (availablePieces == 0) {
     * quantityNeedToOrder = quantity;
     * 
     * if (availableSpace >= quantityNeedToOrder)
     * supplier = pickSupplier(quantity, suppliesTime, availableSpace);
     * 
     * else
     * unableToOrder = true;
     * 
     * }
     * }
     * 
     * else
     * unableToOrder = true; // suppliesTime nao é suficiente
     * 
     * if (unableToOrder)
     * return null;
     * 
     * this.supplier = supplier;
     * 
     * Pair<Integer, PieceType> quantityAndType = new Pair<>(quantityNeedToOrder,
     * rawType);
     * return new Pair<>(supplier, quantityAndType);
     * }
     */

    // chama-se isto depois de "encomendar" as peças necessárias, e se encomendarmos
    // a mais, ele tira o orderID dessas peças extra
    public void correctOrderedPieces(int quantityNeedToOrder, Warehouse warehouse, PieceType rawType, int orderID) {
        if (quantityNeedToOrder < 4)
            warehouse.removeOrderIdFromPiece(rawType, orderID, quantityNeedToOrder);
    }

    public static void main(String[] args) {

        // ArrayList<Piece> piecesFromSupplier2 = new ArrayList<Piece>();
        // Piece p23 = new Piece(2, 3, 1, PieceType.P8);
        // Piece p24 = new Piece(2, 4, 1, PieceType.P8);
        // Piece p25 = new Piece(2, 5, 1, PieceType.P8);
        // piecesFromSupplier2.add(p23);
        // piecesFromSupplier2.add(p24);
        // piecesFromSupplier2.add(p25);
        // ActivitySupplies activity2 = new ActivitySupplies(15, 1, SupplierType.A,
        // piecesFromSupplier2);
        //
        // ArrayList<Piece> warehousePieces = new ArrayList<>();
        // Warehouse warehouse = new Warehouse(warehousePieces);
        // warehouse.addPiecesToWarehouse(new Piece(-2, PieceType.P1), 1);
        //
        // int suppliesTime = 1;
        // PieceType rawType = PieceType.P2;
        // int quantity1 = 10;
        // int orderID = 1;
        //
        // // test for pickSupplier method
        // /*
        // * SupplierType supplier;
        // *
        // *
        // * supplier = activity2.pickSupplier(quantity, days, freespace);
        // *
        // * System.out.println("DAYS: " + days);
        // * System.out.println("QUANTITY: " + quantity);
        // * System.out.println("SUPPLIER: " + (supplier != null ? supplier.toString() :
        // * "No supplier selected"));
        // */
        //
        // // test for getOrderSupplierAndQuantity method
        //
        // Pair<SupplierType, Pair<Integer, PieceType>> result =
        // activity2.getOrderSupplierAndQuantity(warehouse,
        // suppliesTime, rawType, quantity1, orderID);
        //
        // SupplierType supplier2 = result.getKey();
        // int quantityNeedToOrder = result.getValue().getKey();
        // PieceType rawType1 = result.getValue().getValue();
        //
        // System.out.println("Supplier: " + (supplier2 != null ? supplier2.toString() :
        // "No supplier selected"));
        // System.out.println("Piece type: " + rawType1);
        // System.out.println("Quantity needed to order: " + quantityNeedToOrder);

    }

    @Override
    public ActivitySupplies clone() {
        try {
            ActivitySupplies clone = (ActivitySupplies) super.clone();
            clone.piecesFromSupplier = new ArrayList<Piece>();

            for (Piece currPiece : this.piecesFromSupplier) {
                clone.piecesFromSupplier.add(currPiece.clone());
            }

            return clone;
        } catch (Exception e) {
            System.out.println(e.toString());
            return null;
        }
    }

}
