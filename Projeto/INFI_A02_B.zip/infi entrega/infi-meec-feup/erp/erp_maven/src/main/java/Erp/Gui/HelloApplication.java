package Erp.Gui;

import Common.Piece.Piece;
import Common.Piece.PieceType;
import Common.TimeCounting.TimeCounting;
import MasterProductionPlan.*;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.io.IOException;
import java.util.ArrayList;

import static Erp.Gui.DayGUI.createDayGUIList;
import static Erp.Gui.PurchasingPlanGUI.createPurchasingPlanGUIList;

public class HelloApplication extends Application {


        @Override
        public void start(Stage stage) throws IOException {
                FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("erp-hello-view.fxml"));
                Parent root = fxmlLoader.load();
                HelloController controller = fxmlLoader.getController();

//                controller.setProductionDay("2");
//                controller.setProductionTime("45");

                Scene scene = new Scene(root);
                stage.setTitle("\u2728 \u273F ERP  \u273F \u2728");

                stage.setResizable(false);
                stage.setScene(scene);
                stage.show();

                startDatabaseUpdate(controller);


        }

    private void startDatabaseUpdate(HelloController controller) {

        TimeCounting time = new TimeCounting();

        Thread databaseUpdateThread = new Thread(() -> {
            while (true) {
                try {

                    Thread.sleep(5000);

                    Platform.runLater(() -> {
                        controller.connectDB();
                        controller.setOrderCostFromDatabase();
                        controller.setPurchasingPlanFromDatabase();
                        controller.setActivitiesFromDatabase();
                        controller.setProductionDay(Integer.toString(time.getDay()));
                        controller.setProductionTime(Integer.toString(time.getDayTime()));
                        controller.disconnectDB();
                    });
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        databaseUpdateThread.setDaemon(true);
        databaseUpdateThread.start();
    }


    public static void startGUI() {
                launch();
        }

}
