package Mes.Scheduler;

import Common.TimeCounting.FactoryTimeFormat;
import Mes.Action.*;
import javafx.scene.control.TableRow;

import java.io.FilterInputStream;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.concurrent.ExecutionException;

public class Timeline {
    ArrayList<Action> actionsList;

    FactoryTimeFormat startTime;
    FactoryTimeFormat duration;
    FactoryTimeFormat currentTime;
    private Throwable e;

    public ArrayList<Action> getActionsList() {
        return this.actionsList;
    }

    public void setActionsList(ArrayList<Action> actionsList) {
        this.actionsList = actionsList;
    }

    public Timeline(FactoryTimeFormat startTime) {
        this.actionsList = new ArrayList<Action>();
        this.startTime = startTime;
        this.duration = new FactoryTimeFormat(0, 0);
    }

    /**
     *
     * @param time
     * @return the activity that the is occuring for the given time;
     */
    public Action getActionForTime(FactoryTimeFormat time) {

        if (null == time) {
            throw new IllegalArgumentException("Time is null in getActionForTime");
        }
        for (Action action : actionsList) {
            FactoryTimeFormat actionEndTime = action.getEndTime();
            FactoryTimeFormat actionStartTime = action.getStartTime();

            if ((actionEndTime.difference(time).toSeconds() > 0) &&
                    (actionStartTime.difference(time).toSeconds() < 0)) {
                return action;
            }
        }
        return null;
    }

    public Action getActionEndingAfterTime(FactoryTimeFormat time) {
        Action matchingAction = null;
        FactoryTimeFormat latestEndTime = null;

        for (Action action : actionsList) {
            FactoryTimeFormat actionEndTime = action.getEndTime();

            // Check if activity ends after the given time
            if (actionEndTime.difference(time).toSeconds() > 0) {
                // Check if this activity has the latest end time so far
                if (latestEndTime == null || actionEndTime.difference(latestEndTime).toSeconds() > 0) {
                    latestEndTime = actionEndTime;
                    matchingAction = actionsList.get(actionsList.size() - 1);
                    matchingAction = action;
                }
            }
        }

        return matchingAction;
    }

    public Action getActionStartingBeforeTime(FactoryTimeFormat time) {
        Action matchingAction = null;
        FactoryTimeFormat latestStartTime = null;

        for (Action action : actionsList) {
            FactoryTimeFormat actionStartTime = action.getStartTime();

            // Check if activity starts before the given time
            if (actionStartTime.difference(time).toSeconds() < 0) {
                // Check if this activity has the latest start time so far
                if (latestStartTime == null || actionStartTime.difference(latestStartTime).toSeconds() > 0) {
                    latestStartTime = actionStartTime;
                    matchingAction = action;
                }
            }
        }
        // If no activity was found, return the last activity in the timeline
        if (matchingAction == null) {
            return actionsList.get(actionsList.size() - 1);
        }
        return matchingAction;
    }

    public Action getActionStartingAfterTime(FactoryTimeFormat time) {
        Action matchingAction = null;
        FactoryTimeFormat earliestStartTime = null;

        for (Action action : actionsList) {
            FactoryTimeFormat actionStartTime = action.getStartTime();

            // Check if activity starts after the given time
            if (actionStartTime.difference(time).toSeconds() > 0) {
                // Check if this activity has the earliest start time so far
                if (earliestStartTime == null || actionStartTime.difference(earliestStartTime).toSeconds() < 0) {
                    earliestStartTime = actionStartTime;
                    matchingAction = action;
                }
            }
        }
        return matchingAction;
    }

    private void insertActionRaw(Action action, FactoryTimeFormat time) {
        action.setStartTime(time);
        actionsList.add(action);
    }

    private FactoryTimeFormat getEarlyStart(FactoryTimeFormat initTime) {
        if (this.currentTime == null) {
            throw new IllegalArgumentException("Current cannot be null");
        }

        if (this.actionsList.size() == 0) {
            return this.currentTime;
        }

        Action action = getActionStartingBeforeTime(initTime);

        System.out.print("init time: ");
        System.out.println(initTime);

        if (action != null) {
            return action.getEndTime();
        }

        throw new IllegalArgumentException("Could not calculate early start");

    }

    public Action getActionOverlappingTime(FactoryTimeFormat startTime, FactoryTimeFormat endTime) {
        for (Action action : actionsList) {
            FactoryTimeFormat activityStartTime = action.getStartTime();
            FactoryTimeFormat activityEndTime = activityStartTime
                    .add(action.getDuration());

            if (activityStartTime.difference(endTime).toSeconds() < 0
                    && activityEndTime.difference(startTime).toSeconds() > 0) {
                return action;
            }
        }

        return null;
    }

    private boolean checkTimeWindowFitting(FactoryTimeFormat startTime, FactoryTimeFormat duration) {
        if (startTime == null) {
            throw new IllegalArgumentException("startTime cannot be null");
        }
        if (duration == null) {
            throw new IllegalArgumentException("duration cannot be null");
        }

        FactoryTimeFormat endTime = getEndTime();

        FactoryTimeFormat possibleEndTime = startTime.add(duration);

        // Check if there is an activity that starts after the possible end time
        Action nextAction = getActionStartingAfterTime(startTime);
        if (nextAction != null) {
            FactoryTimeFormat nextActionStartTime = nextAction.getStartTime();
            if (nextActionStartTime.difference(possibleEndTime).toSeconds() < 0) {
                // There is not enough time between the end of the current activity and the
                // start of the next one
                return false;
            }
        }

        // Check if there is an activity that ends after the possible end time
        Action overlappingAction = getActionOverlappingTime(startTime, possibleEndTime);
        if (overlappingAction != null) {
            FactoryTimeFormat overlappingActionEndTime = overlappingAction.getEndTime();
            if (overlappingActionEndTime.difference(startTime).toSeconds() < 0) {
                // There is not enough time between the start of the current activity and the
                // end of the overlapping activity
                return false;
            }
        }

        // if (endTime.toSeconds() - possibleEndTime.toSeconds() < 0) {
        // System.out.println("action is too long to fit in the timeline");

        // return false;
        // }
        return true;
    }

    public FactoryTimeFormat insertActionCheck(Action action, FactoryTimeFormat initTime, Boolean pushBack) {

        if (initTime == null) {
            throw new IllegalArgumentException("initTime cannot be null");
        }

        FactoryTimeFormat duration = action.getDuration();

        if (null == duration) {
            throw new IllegalArgumentException("duration cannot be null");

        }

        Boolean thereIsAActionAtInitTime = (null != this.getActionForTime(initTime));

        if (thereIsAActionAtInitTime && !pushBack) {
            System.out.println("To busy to insert!");
            return null;
        }

        FactoryTimeFormat startTime = initTime;
        if (pushBack) {
            startTime = getEarlyStart(initTime);
            System.out.println(startTime);

            if (null == startTime) {
                System.out.println(action);
                System.out.println("No unvalaible start time!");

                return null;
            }
        }

        if (!checkTimeWindowFitting(startTime, duration)) {
            System.out.println("Action dont fit the window!");
            return null;
        }

        return startTime;
    }

    public void insertActionByTime(Action action, FactoryTimeFormat initTime, boolean pushBack,
            FactoryTimeFormat currentTime)
            throws Exception {

        this.currentTime = currentTime;
        if (null == initTime) {
            throw new IllegalArgumentException("initTime cannot be null");
        }

        FactoryTimeFormat newInitTime = insertActionCheck(action, initTime, pushBack);

        if (newInitTime != null) {
            insertActionRaw(action, newInitTime);
        } else {
            throw new Exception("Not possible to insert the action.");
        }
    }

    public void insertActionEarly(Action action, FactoryTimeFormat currentTime) throws Exception {

        if (this.getLastActionEndTime().toSeconds() > currentTime.toSeconds()) {
            FactoryTimeFormat time = this.getLastActionEndTime();
            System.out.println(time);
            insertActionByTime(action, time, true, currentTime);
            return;
        }

        insertActionByTime(action, currentTime, true, currentTime);
    }

    public static String upperScale() {

        int zoom = 2;

        String scaleNumbers = "0" + " ".repeat(15 * zoom - 1) + "15" + " ".repeat(15 * zoom - 2) + "30"
                + " ".repeat(15 * zoom - 2) + "45" + " ".repeat(15 * zoom - 2) + "60";
        String scale = "|" + " ".repeat(15 * zoom - 1) + "|" + " ".repeat(15 * zoom - 1) + "|"
                + " ".repeat(15 * zoom - 1) + "|" + " ".repeat(15 * zoom - 1) + "|";

        return scaleNumbers + "\n" + scale;

    }

    public static String downScale() {

        int zoom = 2;

        String scaleNumbers = "0" + " ".repeat(15 * zoom - 1) + "15" + " ".repeat(15 * zoom - 2) + "30"
                + " ".repeat(15 * zoom - 2) + "45" + " ".repeat(15 * zoom - 2) + "60";
        String scale = "|" + " ".repeat(15 * zoom - 1) + "|" + " ".repeat(15 * zoom - 1) + "|"
                + " ".repeat(15 * zoom - 1) + "|" + " ".repeat(15 * zoom - 1) + "|";

        return scale + "\n" + scaleNumbers;

    }

    public int getSize() {
        return this.actionsList.size();
    }

    public FactoryTimeFormat getEndTime() {
        return this.startTime.add(this.duration);
    }

    public FactoryTimeFormat getLastActionEndTime() {
        int size = getSize();
        if (size > 0) {
            return this.actionsList.get(size - 1).getEndTime();
        }
        return new FactoryTimeFormat(0, 0);
    }

    public ArrayList<Action> getActionsForDay(int day) {

        ArrayList<Action> actionForDay = new ArrayList<Action>();

        if (this.actionsList.isEmpty()) {
            System.out.println("Actions list is empty");
            return actionForDay;
        }

        for (Action action : this.actionsList) {
            int actionDayStart = action.getStartTime().getDay();
            int actionDayEnd = action.getEndTime().getDay();

            if (actionDayStart == day || actionDayEnd == day) {
                actionForDay.add(action);
            }
        }
        return actionForDay;
    }

    public String dayString(int day) throws Exception {

        final int ZOOM = 2;

        ArrayList<Action> actions = getActionsForDay(day);

        System.out.println();
        String lineString = "-".repeat(60 * ZOOM + 1);
        String dayString = "|" + " ".repeat(60 * ZOOM - 1) + "|";

        char[] charArray = dayString.toCharArray();

        for (Action action : actions) {
            int start = 0;
            int end = 120;

            if (action.getStartTime().getDay() == day) {
                start = action.getStartTime().getHour() * ZOOM;
            }
            if (action.getEndTime().getDay() == day) {
                end = action.getEndTime().getHour() * ZOOM;
            }
            charArray[start] = '|';
            charArray[end] = '|';

            if (start != end) {
                String name;
                if (action.getName().length() > (end - start)) {
                    name = action.getName().substring(0, end - start);
                } else {
                    name = action.getName();
                }
                int index = start + ((end - start) / 2) - name.length() / 2;
                char[] nameCharArray = name.toCharArray();

                int i = 0;
                for (char c : nameCharArray) {
                    charArray[index + i] = c;
                    i++;
                }
            }
        }
        dayString = new String(charArray);

        return lineString + "\n" + dayString + "\n" + lineString;
    }

    public void execute(FactoryTimeFormat currentTime) {
        Iterator<Action> iterator = actionsList.iterator();

        while (iterator.hasNext()) {
            Action action = iterator.next();
            if (action.getStartTime().toSeconds() < currentTime.toSeconds()) {
                // System.out.println("executing in timeline, delete this and remove the comment
                // in the line below");
                try {
                    action.execute();
                    System.out.println("Sending action: " + action.toString());
                } catch (InterruptedException | ExecutionException e) {

                    System.out.println("Error in executing action");
                    // e.printStackTrace();
                }
                iterator.remove(); // Remove the action from the list
            } else {
                break;
            }
        }
    }
}