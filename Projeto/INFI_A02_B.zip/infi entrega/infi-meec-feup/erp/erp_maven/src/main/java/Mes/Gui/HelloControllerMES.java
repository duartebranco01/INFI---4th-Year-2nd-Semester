package Mes.Gui;

import Common.Communication.SQL.DataBase;
import Erp.Gui.OrderCostGUI;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.net.URL;


public class HelloControllerMES {

    @FXML
    private Label m1operationTime;

    @FXML
    private TableView<MachineStatsGUI> m1table;

    @FXML
    private TableColumn<MachineStatsGUI, String> m1PieceTypeColumn;

    @FXML
    private TableColumn<MachineStatsGUI, Integer> m1PieceNumberColumn;

    @FXML
    private Label m2operationTime2;

    @FXML
    private TableView<MachineStatsGUI> m2table;

    @FXML
    private TableColumn<MachineStatsGUI, String> m2PieceTypeColumn;

    @FXML
    private TableColumn<MachineStatsGUI, Integer> m2PieceNumberColumn;

    @FXML
    private Label m3operationTime1;

    @FXML
    private TableView<MachineStatsGUI> m3table;

    @FXML
    private TableColumn<MachineStatsGUI, String> m3PieceTypeColumn;

    @FXML
    private TableColumn<MachineStatsGUI, Integer> m3PieceNumberColumn;

    @FXML
    private Label m4operationTime3;

    @FXML
    private TableView<MachineStatsGUI> m4table;

    @FXML
    private TableColumn<MachineStatsGUI, String> m4PieceTypeColumn;

    @FXML
    private TableColumn<MachineStatsGUI, Integer> m4PieceNumberColumn;

    @FXML
    private Label mesDay;

    @FXML
    private Label mesDayTime;

    @FXML
    private TableView<UnloadingStatsGUI> u1table;

    @FXML
    private TableColumn<UnloadingStatsGUI, String> u1PieceTypeColumn;

    @FXML
    private TableColumn<UnloadingStatsGUI, Integer> u1PieceNumberColumn;

    @FXML
    private TableView<UnloadingStatsGUI> u2table;

    @FXML
    private TableColumn<UnloadingStatsGUI, String> u2PieceTypeColumn;

    @FXML
    private TableColumn<UnloadingStatsGUI, Integer> u2PieceNumberColumn;

    @FXML
    private Label ud1totalPieces;

    @FXML
    private Label ud2totalPieces;

    @FXML
    private Label whStoredPieces;

    @FXML
    private TableView<OrderStatusGUI> orderStatusTable;

    @FXML
    private TableColumn<OrderStatusGUI, String> orderIDColumn;

    @FXML
    private TableColumn<OrderStatusGUI, Integer> statusColumn;

    @FXML
    private TableColumn<OrderStatusGUI, Integer> producedPiecesColumn;

    @FXML
    private TableColumn<OrderStatusGUI, Integer> pendingPiecesColumn;

    @FXML
    private TableColumn<OrderStatusGUI, Integer> totalProductionTimeColumn;

    Connection c = null;
    Statement st = null;
    ResultSet rs = null;


    public void initialize(URL url, ResourceBundle resourceBundle) {

        m1PieceTypeColumn.setCellValueFactory(new PropertyValueFactory<>("pieceType"));
        m1PieceNumberColumn.setCellValueFactory(new PropertyValueFactory<>("pieceNumber"));

    }

    public void setm1operationTime(String value) {
        m1operationTime.setText(value);
    }

    public void setm2operationTime(String value) {
        m2operationTime2.setText(value);
    }

    public void setm3operationTime(String value) {
        m3operationTime1.setText(value);
    }

    public void setm4operationTime(String value) {
        m4operationTime3.setText(value);
    }

    public void setmesDay(String value) {
        mesDay.setText(value);
    }

    public void setmesDayTime(String value) {
        mesDayTime.setText(value);
    }

    public void setud1totalPieces(String value) {
        ud1totalPieces.setText(value);
    }

    public void setud2totalPieces(String value) {
        ud2totalPieces.setText(value);
    }

    public void setwhStoredPieces(String value) {
        whStoredPieces.setText(value);
    }

    public String intToString(int number) {
        return String.valueOf(number);
    }


    public void disconnectDB(){
        try {
            if (st != null)
                st.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null)
                    rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (c != null)
                        c.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public Connection connectDB() {c = null;

        try {
            c = DataBase.connect();
            if (c == null) {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();

        }

        return c;
    }
    
    //// MACHINE 1
    public ArrayList<MachineStatsGUI> getM1StatsFromDatabase() {
        ArrayList<MachineStatsGUI> m1StatsData = new ArrayList<>();
        st = null;
        rs = null;

        try {
            st = c.createStatement();
            String query = "SELECT * FROM \"INFI\".\"MachineStats\" WHERE machinenumber=1";
            rs = st.executeQuery(query);

            while (rs.next()) {
                String piecetype = rs.getString("piecetype");
                int numberpieces = rs.getInt("numberpieces");

                MachineStatsGUI m1Stats = new MachineStatsGUI(piecetype, numberpieces);
                m1StatsData.add(m1Stats);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return m1StatsData;
    }

    public int getM1TimeFromDatabase() {
        st = null;
        rs = null;
        int totaloperationtime = 0;

        try {
            st = c.createStatement();
            String query = "SELECT * FROM \"INFI\".\"machinetime\" WHERE machinenumber=1 ORDER BY totaloperationtime DESC LIMIT 1";
            rs = st.executeQuery(query);

            while (rs.next()) {
                totaloperationtime = rs.getInt("totaloperationtime");
    
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return totaloperationtime;
    }

    public void setM1StatsFromDatabase() {
        ArrayList<MachineStatsGUI> m1StatsData = getM1StatsFromDatabase();
        int totaloperationtime=getM1TimeFromDatabase();

        Platform.runLater(() -> {
            m1table.getItems().clear();
            m1table.getColumns().clear();

            m1table.getItems().addAll(m1StatsData);

            m1PieceTypeColumn.setCellValueFactory(new PropertyValueFactory<>("pieceType"));
            m1PieceNumberColumn.setCellValueFactory(new PropertyValueFactory<>("pieceNumber"));

            m1table.getColumns().addAll(m1PieceTypeColumn, m1PieceNumberColumn);

            setm1operationTime(intToString(totaloperationtime));

            m1table.refresh();
        });
    }


    //// MACHINE 2
    public ArrayList<MachineStatsGUI> getM2StatsFromDatabase() {
        ArrayList<MachineStatsGUI> m2StatsData = new ArrayList<>();
        st = null;
        rs = null;

        try {
            st = c.createStatement();
            String query = "SELECT * FROM \"INFI\".\"MachineStats\" WHERE machinenumber=2";
            rs = st.executeQuery(query);

            while (rs.next()) {
                String piecetype = rs.getString("piecetype");
                int numberpieces = rs.getInt("numberpieces");

                MachineStatsGUI m2Stats = new MachineStatsGUI(piecetype, numberpieces);
                m2StatsData.add(m2Stats);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return m2StatsData;
    }

    public int getM2TimeFromDatabase() {
        st = null;
        rs = null;
        int totaloperationtime = 0;

        try {
            st = c.createStatement();
            String query = "SELECT * FROM \"INFI\".\"machinetime\" WHERE machinenumber=2 ORDER BY totaloperationtime DESC LIMIT 1";
            rs = st.executeQuery(query);

            while (rs.next()) {
                totaloperationtime = rs.getInt("totaloperationtime");

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return totaloperationtime;
    }

    public void setM2StatsFromDatabase() {
        ArrayList<MachineStatsGUI> m2StatsData = getM2StatsFromDatabase();
        int totaloperationtime=getM2TimeFromDatabase();

        Platform.runLater(() -> {
            m2table.getItems().clear();
            m2table.getColumns().clear();

            m2table.getItems().addAll(m2StatsData);

            m2PieceTypeColumn.setCellValueFactory(new PropertyValueFactory<>("pieceType"));
            m2PieceNumberColumn.setCellValueFactory(new PropertyValueFactory<>("pieceNumber"));

            m2table.getColumns().addAll(m2PieceTypeColumn, m2PieceNumberColumn);

            setm2operationTime(intToString(totaloperationtime));

            m2table.refresh();
        });
    }

    //// MACHINE 3
    public ArrayList<MachineStatsGUI> getM3StatsFromDatabase() {
        ArrayList<MachineStatsGUI> m3StatsData = new ArrayList<>();
        st = null;
        rs = null;

        try {
            st = c.createStatement();
            String query = "SELECT * FROM \"INFI\".\"MachineStats\" WHERE machinenumber=3";
            rs = st.executeQuery(query);

            while (rs.next()) {
                String piecetype = rs.getString("piecetype");
                int numberpieces = rs.getInt("numberpieces");

                MachineStatsGUI m3Stats = new MachineStatsGUI(piecetype, numberpieces);
                m3StatsData.add(m3Stats);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return m3StatsData;
    }

    public int getM3TimeFromDatabase() {
        st = null;
        rs = null;
        int totaloperationtime = 0;

        try {
            st = c.createStatement();
            String query = "SELECT * FROM \"INFI\".\"machinetime\" WHERE machinenumber=3 ORDER BY totaloperationtime DESC LIMIT 1";
            rs = st.executeQuery(query);

            while (rs.next()) {
                totaloperationtime = rs.getInt("totaloperationtime");

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return totaloperationtime;
    }

    public void setM3StatsFromDatabase() {
        ArrayList<MachineStatsGUI> m3StatsData = getM3StatsFromDatabase();
        int totaloperationtime=getM3TimeFromDatabase();

        Platform.runLater(() -> {
            m3table.getItems().clear();
            m3table.getColumns().clear();

            m3table.getItems().addAll(m3StatsData);

            m3PieceTypeColumn.setCellValueFactory(new PropertyValueFactory<>("pieceType"));
            m3PieceNumberColumn.setCellValueFactory(new PropertyValueFactory<>("pieceNumber"));

            m3table.getColumns().addAll(m3PieceTypeColumn, m3PieceNumberColumn);

            setm3operationTime(intToString(totaloperationtime));

            m3table.refresh();
        });
    }

    //// MACHINE 4
    public ArrayList<MachineStatsGUI> getM4StatsFromDatabase() {
        ArrayList<MachineStatsGUI> m4StatsData = new ArrayList<>();
        st = null;
        rs = null;

        try {
            st = c.createStatement();
            String query = "SELECT * FROM \"INFI\".\"MachineStats\" WHERE machinenumber=4";
            rs = st.executeQuery(query);

            while (rs.next()) {
                String piecetype = rs.getString("piecetype");
                int numberpieces = rs.getInt("numberpieces");

                MachineStatsGUI m4Stats = new MachineStatsGUI(piecetype, numberpieces);
                m4StatsData.add(m4Stats);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return m4StatsData;
    }

    public int getM4TimeFromDatabase() {
        st = null;
        rs = null;
        int totaloperationtime = 0;

        try {
            st = c.createStatement();
            String query = "SELECT * FROM \"INFI\".\"machinetime\" WHERE machinenumber=4 ORDER BY totaloperationtime DESC LIMIT 1";
            rs = st.executeQuery(query);

            while (rs.next()) {
                totaloperationtime = rs.getInt("totaloperationtime");

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return totaloperationtime;
    }

    public void setM4StatsFromDatabase() {
        ArrayList<MachineStatsGUI> m4StatsData = getM4StatsFromDatabase();
        int totaloperationtime=getM4TimeFromDatabase();

        Platform.runLater(() -> {
            m4table.getItems().clear();
            m4table.getColumns().clear();

            m4table.getItems().addAll(m4StatsData);

            m4PieceTypeColumn.setCellValueFactory(new PropertyValueFactory<>("pieceType"));
            m4PieceNumberColumn.setCellValueFactory(new PropertyValueFactory<>("pieceNumber"));

            m4table.getColumns().addAll(m4PieceTypeColumn, m4PieceNumberColumn);

            setm4operationTime(intToString(totaloperationtime));

            m4table.refresh();
        });
    }


    //// UNLOADING DOCK 1

    public ArrayList<UnloadingStatsGUI> getU1StatsFromDatabase() {
        ArrayList<UnloadingStatsGUI> u1StatsData = new ArrayList<>();
        st = null;
        rs = null;

        try {
            st = c.createStatement();
            String query = "SELECT * FROM \"INFI\".\"UnloadingStats\" WHERE unloadingdocknumber=1";
            rs = st.executeQuery(query);

            while (rs.next()) {
                String piecetype = rs.getString("piecetype");
                int numberunloadedpieces = rs.getInt("numberunloadedpieces");

                UnloadingStatsGUI u1Stats = new UnloadingStatsGUI(piecetype, numberunloadedpieces);
                u1StatsData.add(u1Stats);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return u1StatsData;
    }

    public int getU1TotalPiecesFromDatabase() {
        st = null;
        rs = null;
        int totalunloadedpieces = 0;

        try {
            st = c.createStatement();
            String query = "SELECT * FROM \"INFI\".\"unloadingdocktotal\" WHERE unloadingdocknumber=1 ORDER BY totalunloadedpieces DESC LIMIT 1";
            rs = st.executeQuery(query);

            while (rs.next()) {
                totalunloadedpieces = rs.getInt("totalunloadedpieces");

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return totalunloadedpieces;
    }

    public void setU1StatsFromDatabase() {
        ArrayList<UnloadingStatsGUI> u1StatsData = getU1StatsFromDatabase();
        int totalpieces=getU1TotalPiecesFromDatabase();

        Platform.runLater(() -> {
            u1table.getItems().clear();
            u1table.getColumns().clear();

            u1table.getItems().addAll(u1StatsData);

            u1PieceTypeColumn.setCellValueFactory(new PropertyValueFactory<>("pieceType"));
            u1PieceNumberColumn.setCellValueFactory(new PropertyValueFactory<>("pieceNumber"));

            u1table.getColumns().addAll(u1PieceTypeColumn, u1PieceNumberColumn);

            setud1totalPieces(intToString(totalpieces));

            u1table.refresh();
        });
    }

    //// UNLOADING DOCK 2

    public ArrayList<UnloadingStatsGUI> getU2StatsFromDatabase() {
        ArrayList<UnloadingStatsGUI> u2StatsData = new ArrayList<>();
        st = null;
        rs = null;

        try {
            st = c.createStatement();
            String query = "SELECT * FROM \"INFI\".\"UnloadingStats\" WHERE unloadingdocknumber=2";
            rs = st.executeQuery(query);

            while (rs.next()) {
                String piecetype = rs.getString("piecetype");
                int numberunloadedpieces = rs.getInt("numberunloadedpieces");

                UnloadingStatsGUI u2Stats = new UnloadingStatsGUI(piecetype, numberunloadedpieces);
                u2StatsData.add(u2Stats);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return u2StatsData;
    }

    public int getU2TotalPiecesFromDatabase() {
        st = null;
        rs = null;
        int totalunloadedpieces = 0;

        try {
            st = c.createStatement();
            String query = "SELECT * FROM \"INFI\".\"unloadingdocktotal\" WHERE unloadingdocknumber=2 ORDER BY totalunloadedpieces DESC LIMIT 1";
            rs = st.executeQuery(query);

            while (rs.next()) {
                totalunloadedpieces = rs.getInt("totalunloadedpieces");

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return totalunloadedpieces;
    }

    public void setU2StatsFromDatabase() {
        ArrayList<UnloadingStatsGUI> u2StatsData = getU2StatsFromDatabase();
        int totalpieces=getU2TotalPiecesFromDatabase();

        Platform.runLater(() -> {
            u2table.getItems().clear();
            u2table.getColumns().clear();

            u2table.getItems().addAll(u2StatsData);

            u2PieceTypeColumn.setCellValueFactory(new PropertyValueFactory<>("pieceType"));
            u2PieceNumberColumn.setCellValueFactory(new PropertyValueFactory<>("pieceNumber"));

            u2table.getColumns().addAll(u2PieceTypeColumn, u2PieceNumberColumn);

            setud2totalPieces(intToString(totalpieces));

            u2table.refresh();
        });
    }


    // ORDER STATUS

    public ArrayList<OrderStatusGUI> getOrderStatusFromDatabase() {
        ArrayList<OrderStatusGUI> orderData = new ArrayList<>();
        st = null;
        rs = null;

        try {
            st = c.createStatement();
            String query = "SELECT * FROM \"INFI\".\"OrderStats\"";
            rs = st.executeQuery(query);

            while (rs.next()) {
                int orderid = rs.getInt("orderid");
                String status = rs.getString("status");
                int producedpieces = rs.getInt("producedpieces");
                int pendingpieces = rs.getInt("pendingpieces");
                int totalproductiontime = rs.getInt("totalproductiontime");

                OrderStatusGUI order = new OrderStatusGUI(orderid,status,producedpieces,pendingpieces,totalproductiontime );
                orderData.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return orderData;
    }

    public void setOrderFromDatabase() {
        ArrayList<OrderStatusGUI> orderData = getOrderStatusFromDatabase();

        Platform.runLater(() -> {
            orderStatusTable.getItems().clear();
            orderStatusTable.getColumns().clear();

            orderStatusTable.getItems().addAll(orderData);

            orderIDColumn.setCellValueFactory(new PropertyValueFactory<>("orderID"));
            statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
            producedPiecesColumn.setCellValueFactory(new PropertyValueFactory<>("producedPieces"));
            pendingPiecesColumn.setCellValueFactory(new PropertyValueFactory<>("pendingPieces"));
            totalProductionTimeColumn.setCellValueFactory(new PropertyValueFactory<>("totalProductionTime"));

            orderStatusTable.getColumns().addAll(orderIDColumn, statusColumn, producedPiecesColumn, pendingPiecesColumn, totalProductionTimeColumn);


            orderStatusTable.refresh();
        });
    }

    // WAREHOUSE

    public int getWarehousePiecesFromDatabase() {
        st = null;
        rs = null;
        int warehousestoredpieces = 0;

        try {
            st = c.createStatement();
            String query = "SELECT * FROM \"INFI\".\"warehouse\" ORDER BY warehousestoredpieces DESC LIMIT 1";
            rs = st.executeQuery(query);

            while (rs.next()) {
                warehousestoredpieces = rs.getInt("warehousestoredpieces");

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return warehousestoredpieces;
    }

    public void setWarehousePiecesFromDatabase() {

        int totalpieces=getWarehousePiecesFromDatabase();

        Platform.runLater(() -> {

            setwhStoredPieces(intToString(totalpieces));

        });
    }

}