package Erp.Gui;

import Common.Piece.Piece;
import Common.Piece.PieceType;
import MasterProductionPlan.*;

import java.util.ArrayList;

public class PurchasingPlanGUI {

    private int arrivalDate;

    private String supplierType;

    private String pieceType;

    private int pieceQuantity;

    private int requestDate;

    public PurchasingPlanGUI(int requestDate, int arrivalDate, String supplierType, String pType, int pieceQuantity) {
        this.arrivalDate = arrivalDate;
        this.requestDate = requestDate;
        this.supplierType = supplierType;
        this.pieceType = pType;
        this.pieceQuantity = pieceQuantity;

    }

    public static ArrayList<PurchasingPlanGUI> createPurchasingPlanGUIList(ArrayList<Day> days) {
        ArrayList<PurchasingPlanGUI> purchasePlan = new ArrayList<>();

        for (Day day : days) {
            for (Activity activity : day.getDayActivityList()) {
                if (activity.getActivityType() == ActivityType.Supplies) {

                    ActivitySupplies suppliesActivity = (ActivitySupplies) activity;

                    int arrivalDate = suppliesActivity.getDay() + 1;
                    String supplier = extractSupplierName(suppliesActivity.getSupplierType().toString());
                    String pieceType = suppliesActivity.getPieceType().toString();
                    int pieceQuantity = suppliesActivity.getNumberOfPieces();
                    int requestDate = suppliesActivity.getDay() + 1
                            - suppliesActivity.suppliesDeliveryTime(suppliesActivity.getSupplierType());

                    PurchasingPlanGUI plan = new PurchasingPlanGUI(requestDate, arrivalDate, supplier, pieceType,
                            pieceQuantity);
                    purchasePlan.add(plan);

                }
            }
        }

        return purchasePlan;
    }

    public int getArrivalDate() {
        return arrivalDate;
    }

    public void setArrivalDate(int arrivalDate) {
        this.arrivalDate = arrivalDate;
    }

    public String getSupplierType() {
        return supplierType;
    }

    public void setSupplierType(String supplierType) {
        this.supplierType = supplierType;
    }

    public String getPieceType() {
        return pieceType;
    }

    public void setPieceType(String pType) {
        this.pieceType = pType;
    }

    public int getPieceQuantity() {
        return pieceQuantity;
    }

    public void setPieceQuantity(int pieceQuantity) {
        this.pieceQuantity = pieceQuantity;
    }

    public int getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(int requestDate) {
        this.requestDate = requestDate;
    }

    public static String extractSupplierName(String supplierString) {
        int index = supplierString.lastIndexOf(" ");
        if (index != -1 && index < supplierString.length() - 1) {
            return supplierString.substring(index + 1);
        }
        return "";
    }

    public static void main(String[] args) {

        ArrayList<Activity> activitiesList = new ArrayList<>();

        ArrayList<Piece> piecesFromSupplier2 = new ArrayList<Piece>();
        Piece p23 = new Piece(2, 3, 1, PieceType.P8);
        Piece p24 = new Piece(2, 4, 1, PieceType.P8);
        Piece p25 = new Piece(2, 5, 1, PieceType.P8);
        piecesFromSupplier2.add(p23);
        piecesFromSupplier2.add(p24);
        piecesFromSupplier2.add(p25);

        ArrayList<Piece> piecesFromSupplier3 = new ArrayList<Piece>();
        Piece p233 = new Piece(2, 3, 1, PieceType.P3);
        Piece p243 = new Piece(2, 4, 1, PieceType.P3);
        Piece p253 = new Piece(2, 5, 1, PieceType.P3);
        Piece p254 = new Piece(2, 5, 1, PieceType.P3);
        piecesFromSupplier3.add(p233);
        piecesFromSupplier3.add(p243);
        piecesFromSupplier3.add(p253);
        piecesFromSupplier3.add(p254);

        ActivitySupplies suppliesActivity1 = new ActivitySupplies(ActivityType.Supplies, 0, 15,
                40, 4, 8, Common.Suppliers.SupplierType.A, piecesFromSupplier2);

        ActivitySupplies suppliesActivity2 = new ActivitySupplies(ActivityType.Supplies, 0, 15,
                40, 4, 15, Common.Suppliers.SupplierType.B, piecesFromSupplier2);

        ActivitySupplies suppliesActivity3 = new ActivitySupplies(ActivityType.Supplies, 0, 15,
                40, 4, 5, Common.Suppliers.SupplierType.C, piecesFromSupplier3);

        ActivityProduction production = new ActivityProduction(ActivityType.Production, 1, 1,
                1, 1, 1, piecesFromSupplier2, 1);
        ActivityProduction production2 = new ActivityProduction(ActivityType.Production, 1, 1,
                1, 1, 1, piecesFromSupplier2, 1);

        activitiesList.add(suppliesActivity1);
        activitiesList.add(production2);
        activitiesList.add(suppliesActivity2);
        activitiesList.add(production);
        activitiesList.add(suppliesActivity3);

        // ArrayList<PurchasingPlanGUI> purchasingPlanList =
        // createPurchasingPlanGUIList(activitiesList);

        // for (PurchasingPlanGUI plan : purchasingPlanList) {
        // System.out.println("Arrival Date: " + plan.getArrivalDate());
        // System.out.println("Request Date: " + plan.getRequestDate());
        // System.out.println("Supplier Type: " + plan.getSupplierType());
        // System.out.println("Piece Type: " + plan.getPieceType());
        // System.out.println("Piece Quantity: " + plan.getPieceQuantity());
        // System.out.println("------------------------");
        // }
    }

}
