package Mes.Action;

import java.util.concurrent.ExecutionException;

import Common.TimeCounting.FactoryTimeFormat;
import Mes.Action.ActionType.ActionType;

public class Action {
    ActionType actionType;
    int priority;
    FactoryTimeFormat startTime;
    FactoryTimeFormat endTime;
    FactoryTimeFormat duration;

    public Action(ActionType actionType, int priority) {
        this.actionType = actionType;
        this.priority = priority;
        this.duration = actionType.getDuration();
    }

    public String getName() {
        return this.actionType.getName();
    }

    public ActionType getActionType() {
        return this.actionType;
    }

    public FactoryTimeFormat getDuration() {
        return this.duration;
    }

    public void setStartTime(FactoryTimeFormat startTime) {
        this.startTime = startTime;
        this.endTime = startTime.add(this.getDuration());
    }

    public void setDuration(FactoryTimeFormat newDuration) {
        this.duration = newDuration;
        if (null != startTime) {
            setEndTime(startTime.add(newDuration));
        }
    }

    public FactoryTimeFormat getStartTime() {
        return this.startTime;
    }

    public FactoryTimeFormat getEndTime() {
        return this.endTime;
    }

    public int getPriority() {
        return this.priority;
    }

    public void setEndTime(FactoryTimeFormat endTime) {
        this.endTime = endTime;
    }

    public void execute() throws InterruptedException, ExecutionException {
        this.actionType.execute();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        if (startTime == null) {
            sb.append("No start time yet \n");

        } else {
            sb.append(this.startTime.toString() + '\n');

        }
        if (endTime == null) {
            sb.append("No end time yet \n");

        } else {
            sb.append(this.endTime.toString() + '\n');

        }
        sb.append("Action Type: ");
        sb.append(actionType.toString() + '\n');

        return sb.toString();
    }
}
