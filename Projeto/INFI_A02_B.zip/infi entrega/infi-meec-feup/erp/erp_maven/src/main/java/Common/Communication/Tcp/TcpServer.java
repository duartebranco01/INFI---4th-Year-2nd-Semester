package Common.Communication.Tcp;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class TcpServer extends Thread {

    private ServerSocket serverSocket;
    private boolean running;
    private Object lastObject = null;

    public TcpServer(int port) throws IOException {
        serverSocket = new ServerSocket(port);
        running = true;
    }

    @Override
    public void run() {
        System.out.println("Server started, listening on port " + serverSocket.getLocalPort() + "...");
        while (running) {
            try (Socket clientSocket = serverSocket.accept();
                    ObjectInputStream objectInputStream = new ObjectInputStream(clientSocket.getInputStream())) {

                // read the object sent by the client
                Object object = objectInputStream.readObject();

                synchronized (this) {
                    lastObject = object;
                    this.notifyAll();
                }
            } catch (IOException e) {
                System.err.println("Error accepting client connection: " + e.getMessage());
            } catch (ClassNotFoundException e) {
                System.err.println("Error reading object from client: " + e.getMessage());
            }
        }
        System.out.println("Server stopped.");
    }

    public synchronized Object receiveObject() {
        while (lastObject == null) {
            try {
                this.wait();
            } catch (InterruptedException e) {
                return null;
            }
        }
        return lastObject;
    }

    public void stopServer() {
        running = false;
        interrupt();
        try {
            serverSocket.close();
        } catch (IOException e) {
            System.err.println("Error closing server socket: " + e.getMessage());
        }
    }

    public static void main(String[] args) throws IOException, ClassNotFoundException {

        int port = 1234;

        TcpServer server = new TcpServer(port);
        server.start();

        // let the server run for a while
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            System.err.println("Interrupted while waiting for server to run: " + e.getMessage());
        }

        // stop the server
        // server.stopServer();
    }

    public boolean getRunning() {
        return this.running;
    }
}
