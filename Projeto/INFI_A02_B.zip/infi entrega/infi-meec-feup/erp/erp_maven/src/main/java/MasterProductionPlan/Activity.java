package MasterProductionPlan;

import java.io.Serializable;

public class Activity implements Cloneable, Serializable {

    private ActivityType activityType;
    private int activityStartTime;
    private int activityEndTime;
    private int activityDuration;
    private int orderId;
    private int day;

    public Activity(ActivityType activityType, int activityDuration, int orderId) {
        this.activityType = activityType;
        this.activityDuration = activityDuration;
        this.orderId = orderId;
    }

    public Activity(ActivityType activityType, int activityStartTime, int activityEndTime, int activityDuration,
            int orderId, int day) {
        this.activityType = activityType;
        this.activityStartTime = activityStartTime;
        this.activityEndTime = activityEndTime;
        this.activityDuration = activityDuration;
        this.orderId = orderId;

        setDay(day);
    }

    /*
     * public Activity(int activityStartTime, int activityDuration) {
     * this.activityStartTime = activityStartTime;
     * this.activityDuration = activityDuration;
     * }
     */

    public void setDay(int day) {
        if (this.day < 0) {
            throw new IllegalArgumentException("Day number should be greater than zero");
        }
        this.day = day;
    }

    public int getDay() {

        return this.day;
    }

    public int getOrderId() {
        return this.orderId;
    }

    public ActivityType getActivityType() {
        return this.activityType;
    }

    public void setActivityType(ActivityType activityType) {
        this.activityType = activityType;
    }

    public int getStartTime() {
        return this.activityStartTime;
    }

    public void setActivityStartTime(int activityStartTime) {
        this.activityStartTime = activityStartTime;
        this.activityEndTime = activityStartTime + activityDuration;
    }

    public int getEndTime() {
        return this.activityEndTime;
    }

    public void setActivityEndTime(int activityEndTime) {
        this.activityEndTime = activityEndTime;
    }

    public int getDuration() {
        return this.activityDuration;
    }

    public void setActivityDuration(int activityDuration) {
        this.activityDuration = activityDuration;
    }

    public String toString() {
        return "\t Day: " + day + "\n"
                + "\t OrderID: " + orderId + "\n"
                + "\t Activity: " + activityType + "\n"
                + "\t Start time: " + activityStartTime + "\n"
                + "\t End time: " + activityEndTime + "\n"
                + "\t Duration: " + activityDuration + "\n\n";
    }

    @Override
    public Activity clone() {
        try {
            return (Activity) super.clone();

        } catch (Exception e) {
            System.out.println(e.toString());
            return null;
        }
    }
}
