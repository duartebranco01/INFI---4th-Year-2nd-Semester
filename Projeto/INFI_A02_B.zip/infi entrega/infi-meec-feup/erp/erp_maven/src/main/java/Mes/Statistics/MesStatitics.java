package Mes.Statistics;

import Common.Communication.OpcUa.*;
import Mes.Gui.MachineStatsGUI;

/**
 * MesStatitics
 */
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import Common.Communication.SQL.*;

import org.eclipse.milo.opcua.stack.core.UaException;

public class MesStatitics {

    public OpcUaCodesysClient total_time_1;
    public OpcUaCodesysClient total_piece_1;
    public OpcUaCodesysClient[] M1;

    public OpcUaCodesysClient total_time_2;
    public OpcUaCodesysClient total_piece_2;
    public OpcUaCodesysClient[] M2;

    public OpcUaCodesysClient total_time_3;
    public OpcUaCodesysClient total_piece_3;
    public OpcUaCodesysClient[] M3;

    public OpcUaCodesysClient total_time_4;
    public OpcUaCodesysClient total_piece_4;
    public OpcUaCodesysClient[] M4;

    public OpcUaCodesysClient total_piece_pusher1;
    public OpcUaCodesysClient[] Pusher1;

    public OpcUaCodesysClient total_piece_pusher2;
    public OpcUaCodesysClient[] Pusher2;

    public OpcUaCodesysClient total_piece_warehouse;

    public MesStatitics() {
        M1 = new OpcUaCodesysClient[11];
        total_time_1 = new OpcUaCodesysClient("total_time_1", "PLC_PROG");
        total_piece_1 = new OpcUaCodesysClient("total_piece_1", "PLC_PROG");
        M1[1] = new OpcUaCodesysClient("total_P1_1", "PLC_PROG");
        M1[2] = new OpcUaCodesysClient("total_P2_1", "PLC_PROG");
        M1[3] = new OpcUaCodesysClient("total_P3_1", "PLC_PROG");
        M1[4] = new OpcUaCodesysClient("total_P4_1", "PLC_PROG");
        M1[5] = new OpcUaCodesysClient("total_P5_1", "PLC_PROG");
        M1[6] = new OpcUaCodesysClient("total_P6_1", "PLC_PROG");
        M1[7] = new OpcUaCodesysClient("total_P7_1", "PLC_PROG");
        M1[8] = new OpcUaCodesysClient("total_P8_1", "PLC_PROG");
        M1[9] = new OpcUaCodesysClient("total_P9_1", "PLC_PROG");

        M2 = new OpcUaCodesysClient[11];
        total_time_2 = new OpcUaCodesysClient("total_time_2", "PLC_PROG");
        total_piece_2 = new OpcUaCodesysClient("total_piece_2", "PLC_PROG");
        M2[1] = new OpcUaCodesysClient("total_P1_2", "PLC_PROG");
        M2[2] = new OpcUaCodesysClient("total_P2_2", "PLC_PROG");
        M2[3] = new OpcUaCodesysClient("total_P3_2", "PLC_PROG");
        M2[4] = new OpcUaCodesysClient("total_P4_2", "PLC_PROG");
        M2[5] = new OpcUaCodesysClient("total_P5_2", "PLC_PROG");
        M2[6] = new OpcUaCodesysClient("total_P6_2", "PLC_PROG");
        M2[7] = new OpcUaCodesysClient("total_P7_2", "PLC_PROG");
        M2[8] = new OpcUaCodesysClient("total_P8_2", "PLC_PROG");
        M2[9] = new OpcUaCodesysClient("total_P9_2", "PLC_PROG");

        M3 = new OpcUaCodesysClient[11];
        total_time_3 = new OpcUaCodesysClient("total_time_3", "PLC_PROG");
        total_piece_3 = new OpcUaCodesysClient("total_piece_3", "PLC_PROG");
        M3[1] = new OpcUaCodesysClient("total_P1_3", "PLC_PROG");
        M3[2] = new OpcUaCodesysClient("total_P2_3", "PLC_PROG");
        M3[3] = new OpcUaCodesysClient("total_P3_3", "PLC_PROG");
        M3[4] = new OpcUaCodesysClient("total_P4_3", "PLC_PROG");
        M3[5] = new OpcUaCodesysClient("total_P5_3", "PLC_PROG");
        M3[6] = new OpcUaCodesysClient("total_P6_3", "PLC_PROG");
        M3[7] = new OpcUaCodesysClient("total_P7_3", "PLC_PROG");
        M3[8] = new OpcUaCodesysClient("total_P8_3", "PLC_PROG");
        M3[9] = new OpcUaCodesysClient("total_P9_3", "PLC_PROG");

        M4 = new OpcUaCodesysClient[11];
        total_time_4 = new OpcUaCodesysClient("total_time_4", "PLC_PROG");
        total_piece_4 = new OpcUaCodesysClient("total_piece_4", "PLC_PROG");
        M4[1] = new OpcUaCodesysClient("total_P1_4", "PLC_PROG");
        M4[2] = new OpcUaCodesysClient("total_P2_4", "PLC_PROG");
        M4[3] = new OpcUaCodesysClient("total_P3_4", "PLC_PROG");
        M4[4] = new OpcUaCodesysClient("total_P4_4", "PLC_PROG");
        M4[5] = new OpcUaCodesysClient("total_P5_4", "PLC_PROG");
        M4[6] = new OpcUaCodesysClient("total_P6_4", "PLC_PROG");
        M4[7] = new OpcUaCodesysClient("total_P7_4", "PLC_PROG");
        M4[8] = new OpcUaCodesysClient("total_P8_4", "PLC_PROG");
        M4[9] = new OpcUaCodesysClient("total_P9_4", "PLC_PROG");

        Pusher1 = new OpcUaCodesysClient[11];
        total_piece_pusher1 = new OpcUaCodesysClient("total_piece_CT4", "PLC_PROG");
        Pusher1[1] = new OpcUaCodesysClient("total_P1_CT4", "PLC_PROG");
        Pusher1[2] = new OpcUaCodesysClient("total_P2_CT4", "PLC_PROG");
        Pusher1[3] = new OpcUaCodesysClient("total_P3_CT4", "PLC_PROG");
        Pusher1[4] = new OpcUaCodesysClient("total_P4_CT4", "PLC_PROG");
        Pusher1[5] = new OpcUaCodesysClient("total_P5_CT4", "PLC_PROG");
        Pusher1[6] = new OpcUaCodesysClient("total_P6_CT4", "PLC_PROG");
        Pusher1[7] = new OpcUaCodesysClient("total_P7_CT4", "PLC_PROG");
        Pusher1[8] = new OpcUaCodesysClient("total_P8_CT4", "PLC_PROG");
        Pusher1[9] = new OpcUaCodesysClient("total_P9_CT4", "PLC_PROG");

        Pusher2 = new OpcUaCodesysClient[11];
        total_piece_pusher2 = new OpcUaCodesysClient("total_piece_CT5", "PLC_PROG");
        Pusher2[1] = new OpcUaCodesysClient("total_P1_CT5", "PLC_PROG");
        Pusher2[2] = new OpcUaCodesysClient("total_P2_CT5", "PLC_PROG");
        Pusher2[3] = new OpcUaCodesysClient("total_P3_CT5", "PLC_PROG");
        Pusher2[4] = new OpcUaCodesysClient("total_P4_CT5", "PLC_PROG");
        Pusher2[5] = new OpcUaCodesysClient("total_P5_CT5", "PLC_PROG");
        Pusher2[6] = new OpcUaCodesysClient("total_P6_CT5", "PLC_PROG");
        Pusher2[7] = new OpcUaCodesysClient("total_P7_CT5", "PLC_PROG");
        Pusher2[8] = new OpcUaCodesysClient("total_P8_CT5", "PLC_PROG");
        Pusher2[9] = new OpcUaCodesysClient("total_P9_CT5", "PLC_PROG");

        total_piece_warehouse = new OpcUaCodesysClient("curr_num_warehouse", "PLC_PROG");
    }

    public int getTotalPiecesMachines(int machineNumber, int pieceNumber)
            throws Exception {
        switch (machineNumber) {
            case 1:
                // System.out.println("\n\n\n\n");
                // System.out.println(M1[pieceNumber].getIdentifier());
                // System.out.println("\n\n\n\n");

                return M1[pieceNumber].readInt();

            case 2:
                return M2[pieceNumber].readInt();
            case 3:
                return M3[pieceNumber].readInt();
            case 4:
                return M4[pieceNumber].readInt();
        }
        return 0;
    }

    public int getTotalPiecesUnloading(int machineNumber, int pieceNumber)
            throws Exception {
        switch (machineNumber) {
            case 1:
                return Pusher1[pieceNumber].readInt();
            case 2:
                return Pusher2[pieceNumber].readInt();
        }
        return 0;
    }

    public static void main(String[] args) throws Exception {

        MesStatitics tt = new MesStatitics();
        InsertIntoTablesMES teste = new InsertIntoTablesMES();

        for (int i = 0; i < 4; i++) {
            ArrayList<MachineStatsGUI> machineStats = new ArrayList<>();

            for (int j = 1; j < 10; j++) {
                machineStats.add(new MachineStatsGUI("P" + Integer.toString(i), tt.getTotalPiecesMachines(i, j)));

            }
            teste.addMachineStats(machineStats, i);

        }
    }
}