package Common.Communication.OpcUa;

import org.eclipse.milo.opcua.sdk.client.OpcUaClient;
import org.eclipse.milo.opcua.sdk.client.nodes.UaVariableNode;
import org.eclipse.milo.opcua.stack.core.UaException;
import org.eclipse.milo.opcua.stack.core.types.builtin.DataValue;
import org.eclipse.milo.opcua.stack.core.types.builtin.NodeId;
import org.eclipse.milo.opcua.stack.core.types.builtin.StatusCode;
import org.eclipse.milo.opcua.stack.core.types.builtin.Variant;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class OpcUaCodesysClient {

    final String port = "4840";
    final int nodeSpaceIndex = 4;

    String hostname;
    String endPointUrl;
    String identifier;

    public OpcUaCodesysClient(String varName, String varType) {

        try {
            InetAddress address = InetAddress.getLocalHost();
            this.hostname = address.getHostName();
        } catch (UnknownHostException e) {
            System.err.println("Unable to determine hostname");
        }

        this.endPointUrl = "opc.tcp://" + hostname + ":" + port;
        StringBuilder sb = new StringBuilder();
        sb.append("|var|CODESYS Control Win V3 x64.Application.");
        sb.append(varType);
        sb.append(".");
        sb.append(varName);
        this.identifier = sb.toString();
    }

    public String getIdentifier() {
        return this.identifier;
    }

    public boolean writeInt(int value) throws InterruptedException, ExecutionException {
        short valueShort = (short) value;

        OpcUaClient client;
        try {
            client = OpcUaClient.create(endPointUrl);
        } catch (UaException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            System.out.println("could not get the opcua client");
            return false;
        }
        NodeId nodeId = new NodeId(nodeSpaceIndex, identifier);

        // synchronous connect
        client.connect().get();
        Variant variantValue = new Variant(valueShort);
        DataValue dataValue = new DataValue(variantValue);

        CompletableFuture<StatusCode> future = client.writeValue(nodeId, dataValue);
        StatusCode statusCode = future.get();

        client.disconnect().get();

        // System.out.println("Write " + Integer.toString(value) + " in var" +
        // identifier);
        return statusCode.isGood();
    }

    public int readBoolean() throws ExecutionException, InterruptedException, UaException {

        OpcUaClient client;
        try {
            client = OpcUaClient.create(endPointUrl);
        } catch (UaException e) {
            // TODO Auto-generated catch block
            System.out.println("could not get the opcua client reading bool");
            return -1;
        }
        NodeId nodeId = new NodeId(nodeSpaceIndex, identifier);

        // synchronous connect
        client.connect().get();

        // synchronous read request via VariableNode
        UaVariableNode node = client.getAddressSpace().getVariableNode(nodeId);
        DataValue dataValue = node.readValue();
        Boolean b = Boolean.parseBoolean(dataValue.getValue().getValue().toString());

        client.disconnect().get();
        if (b == true) {
            return 1;
        }
        return 0;
    }

    public int readInt() throws Exception {

        OpcUaClient client;
        try {
            client = OpcUaClient.create(endPointUrl);
        } catch (UaException e) {
            throw new Exception("Could not get the opcua client reading int");
        }
        NodeId nodeId = new NodeId(nodeSpaceIndex, identifier);

        // synchronous connect
        client.connect().get();

        // synchronous read request via VariableNode
        UaVariableNode node = client.getAddressSpace().getVariableNode(nodeId);
        DataValue dataValue = node.readValue();
        int ret = Integer.parseInt(dataValue.getValue().getValue().toString());

        client.disconnect().get();

        return ret;
    }
}
