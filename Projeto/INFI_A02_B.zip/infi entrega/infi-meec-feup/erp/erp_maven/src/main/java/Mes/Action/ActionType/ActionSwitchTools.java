package Mes.Action.ActionType;

import java.util.concurrent.ExecutionException;

import Common.Communication.OpcUa.OpcUaCodesysClient;
import Common.Constants.TimeConstants;
import Common.TimeCounting.FactoryTimeFormat;

public enum ActionSwitchTools implements ActionType {
    toTool1("Switch to tool 1", 1),
    toTool2("Switch to tool 2", 2),
    toTool3("Switch to tool 3", 3),
    toTool4("Switch to tool 4", 4);

    private final FactoryTimeFormat duration = new FactoryTimeFormat(0, TimeConstants.switchToolsTime);
    private String name;
    OpcUaCodesysClient requestToolVarClient;
    int toolNumber;

    ActionSwitchTools(String name, int toolNumber) {
        this.name = name;
        this.requestToolVarClient = new OpcUaCodesysClient("request_tool_manual", "PLC_PROG");
        this.toolNumber = toolNumber;

    }

    public void execute() throws InterruptedException, ExecutionException {
        requestToolVarClient.writeInt(toolNumber);
        return;
    }

    public FactoryTimeFormat getDuration() {
        return duration;
    }

    public String getName() {
        return name;
    }

    public String toString() {
        return "Switch tools";
    }
}
