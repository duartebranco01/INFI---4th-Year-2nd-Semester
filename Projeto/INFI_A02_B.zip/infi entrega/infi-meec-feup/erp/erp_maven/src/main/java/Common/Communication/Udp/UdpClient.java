package Common.Communication.Udp;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.*;

import Common.Piece.PieceType;
import Common.Piece.Transition;
import Products.*;

public class UdpClient {

    private DatagramSocket datagramSocket;
    private InetAddress inetAddress;

    private int clientPort;

    public UdpClient(String hostname, int port) throws UnknownHostException, SocketException {
        inetAddress = InetAddress.getByName(hostname);
        datagramSocket = new DatagramSocket();
        clientPort = port;

    }

    public String sendString(String string) {

        return sendBuffer(string.getBytes());
    }

    public String sendObject(Object object) throws IOException {

        // Convert the object to a byte array using serialization
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(bos);
        oos.writeObject(object);
        oos.flush();
        byte[] data = bos.toByteArray();

        return sendBuffer(data);
    }

    private String sendBuffer(byte buffer[]) {

        DatagramPacket datagramPacket = new DatagramPacket(buffer, buffer.length,
                inetAddress, clientPort);

        try {
            datagramSocket.send(datagramPacket);

        } catch (IOException e) {
            e.printStackTrace();
            datagramSocket.close();
        }

        String received = new String(
                datagramPacket.getData(), 0, datagramPacket.getLength());
        return received;

    }

    public static void main(String[] args) throws IOException {

        String hostname = "localhost";
        int port = 1234;

        UdpClient client = new UdpClient(hostname, port);

        Transition transitionToSend = new Transition(1, 1, 1, PieceType.P1, PieceType.P6);

        for (;;) {
            client.sendObject(transitionToSend);
        }
    }
}
