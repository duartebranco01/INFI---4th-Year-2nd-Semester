package Erp.Gui;

import MasterProductionPlan.Activity;
import MasterProductionPlan.ActivityType;
import MasterProductionPlan.Day;

import java.util.ArrayList;

public class DayGUI {
    private int dayGui;
    private String activityGui;

    public DayGUI(int dayGui, String activityGui) {
        this.dayGui = dayGui;
        this.activityGui = activityGui;
    }

    public int getDayGui() {
        return dayGui;
    }

    public void setDayGui(int dayGui) {
        this.dayGui = dayGui;
    }

    public String getActivityGui() {
        return activityGui;
    }

    public void setActivityGui(String activityGui) {
        this.activityGui = activityGui;
    }

    public static ArrayList<DayGUI> createDayGUIList(
            ArrayList<Day> daysList/* , ArrayList<Activity> activitiesList */) {

        ArrayList<DayGUI> dayGUIList = new ArrayList<>();

        for (Day day : daysList) {
            int dayNumber = day.getCurrDay();
            StringBuilder activitiesStringBuilder = new StringBuilder();

            for (Activity activity : day.getDayActivityList()) {
                if (activity.getDay() == dayNumber) {
                    activitiesStringBuilder.append(activity.getActivityType().toString()).append(", ");
                }
            }

            if (activitiesStringBuilder.length() > 2) {
                activitiesStringBuilder.setLength(activitiesStringBuilder.length() - 2);
            }

            DayGUI dayGUI = new DayGUI(dayNumber, activitiesStringBuilder.toString());
            dayGUIList.add(dayGUI);
        }

        return dayGUIList;
    }

    public String toString() {
        return "Day: " + dayGui + "\n" + "Activities: " + activityGui + "\n";
    }

    public static void main(String[] args) {

        ArrayList<Day> daysList = new ArrayList<>();
        daysList.add(new Day(1));
        daysList.add(new Day(2));
        daysList.add(new Day(3));

        ArrayList<Activity> activitiesList = new ArrayList<>();
        activitiesList.add(new Activity(ActivityType.Supplies, 8, 10, 2, 1, 1));
        activitiesList.add(new Activity(ActivityType.Production, 9, 12, 3, 3, 2));
        activitiesList.add(new Activity(ActivityType.Unloading, 10, 14, 4, 4, 2));
        activitiesList.add(new Activity(ActivityType.Supplies, 15, 17, 2, 5, 3));
        activitiesList.add(new Activity(ActivityType.Unloading, 11, 14, 3, 6, 3));

        // ArrayList<DayGUI> dayGUIList = createDayGUIList(daysList, activitiesList);

        // for (DayGUI dayGUI : dayGUIList) {
        // System.out.println(dayGUI);
        // }
    }

}
