package Common.TimeCounting;

import java.time.LocalTime;

public class TimeCounting {

    private int currentDay = 0;
    private int dayTime = 0;
    private LocalTime initTime = LocalTime.now();

    private void updateCurrentDay() {

        int secondsInDay = 60;
        LocalTime currentTime = LocalTime.now().minusSeconds(initTime.toSecondOfDay());
        currentDay = currentTime.toSecondOfDay() / secondsInDay;
        dayTime = currentTime.toSecondOfDay() % secondsInDay;
        // dayTime = dayTime * 24 / 60;
    }

    public LocalTime getinitTime() {
        return this.initTime;
    }

    public int getDay() {
        updateCurrentDay();
        return currentDay;
    }

    public int getDayTime() {
        updateCurrentDay();
        return dayTime;
    }

    public FactoryTimeFormat getCurrentTime() {
        updateCurrentDay();
        return new FactoryTimeFormat(currentDay, dayTime);
    }

    public void setInitTime(LocalTime initTime) {
        this.initTime = initTime;
    }

    public static void main(String[] args) {
        TimeCounting timeCouting = new TimeCounting();
        while (true) {

            System.out.println(timeCouting.getDayTime());

        }

    }

}
