package Mes.Gui;

public class MachineStatsGUI {

    public String pieceType;
    public int pieceNumber;

    public int machineNumber;

    public MachineStatsGUI(String pieceType, int pieceNumber) {
        if (pieceType == null) {
            throw new IllegalArgumentException("PieceType string is null");
        }
        this.pieceType = pieceType;
        this.pieceNumber = pieceNumber;
    }

    public String getPieceType() {
        return pieceType;
    }

    public void setPieceType(String pieceType) {
        this.pieceType = pieceType;
    }

    public int getPieceNumber() {
        return pieceNumber;
    }

    public void setPieceNumber(int pieceNumber) {
        this.pieceNumber = pieceNumber;
    }
}
