package Mes.Gui;

import Common.Piece.Piece;
import Common.Piece.PieceType;
import Common.TimeCounting.TimeCounting;
import Erp.Gui.*;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ListChangeListener;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MesGui extends Application {

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MesGui.class.getResource("mes-hello-view.fxml"));
        Parent root = fxmlLoader.load();
        HelloControllerMES controller = fxmlLoader.getController();

        Scene scene = new Scene(root);
        stage.setTitle("\u2728 \u273F MES  \u273F \u2728");

        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();

        startDatabaseUpdate(controller);

    }

    private void startDatabaseUpdate(HelloControllerMES controller) {

        TimeCounting time = new TimeCounting();

        Thread databaseUpdateThread = new Thread(() -> {
            while (true) {
                try {

                    Thread.sleep(5000);

                    Platform.runLater(() -> {
                        controller.connectDB();
                        controller.setmesDay(Integer.toString(time.getDay()));
                        controller.setmesDayTime(Integer.toString(time.getDayTime()));
                        controller.setM1StatsFromDatabase();
                        controller.setM2StatsFromDatabase();
                        controller.setM3StatsFromDatabase();
                        controller.setM4StatsFromDatabase();
                        controller.setU1StatsFromDatabase();
                        controller.setU2StatsFromDatabase();
                        controller.setOrderFromDatabase();
                        controller.setWarehousePiecesFromDatabase();
                        controller.disconnectDB();
                    });
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        databaseUpdateThread.setDaemon(true);
        databaseUpdateThread.start();
    }

    public static void startGUI() {
        launch();
    }

    public static void main(String[] args) {
        launch(args);
    }

}