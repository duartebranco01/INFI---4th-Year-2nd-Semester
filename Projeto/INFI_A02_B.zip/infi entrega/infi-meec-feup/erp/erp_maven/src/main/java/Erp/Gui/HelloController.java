package Erp.Gui;

import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.Map;
import java.util.Collections;
import java.util.HashMap;

import javafx.fxml.Initializable;
import javafx.scene.control.cell.PropertyValueFactory;
import Common.Communication.SQL.DataBase;

public class HelloController implements Initializable {
    @FXML
    private Label client_name;
    private Label orderCost;

    @FXML
    private TableView<DayGUI> tableView;

    @FXML
    private TableView<PurchasingPlanGUI> orderTableView;

    @FXML
    private TableView<OrderCostGUI> orderCostTable;

    @FXML
    private TableColumn<PurchasingPlanGUI, Integer> arrivalDateColumn;

    @FXML
    private TableColumn<PurchasingPlanGUI, Integer> pieceRequestColumn;

    @FXML
    private TableColumn<PurchasingPlanGUI, String> supplierTypeColumn;

    @FXML
    private TableColumn<PurchasingPlanGUI, String> pieceTypeColumn;

    @FXML
    private TableColumn<PurchasingPlanGUI, Integer> pieceQuantityColumn;

    @FXML
    private TableColumn<OrderCostGUI, Integer> orderIDColumn;

    @FXML
    private TableColumn<OrderCostGUI, Double> costColumn;

    @FXML
    private Label productionDay;

    @FXML
    private Label currentTime;

    private ArrayList<DayGUI> activities;
    private ArrayList<PurchasingPlanGUI> purchasingPlan;
    private ArrayList<OrderCostGUI> cost;
    Connection c = null;
    Statement st = null;
    ResultSet rs = null;

    public void initialize(URL url, ResourceBundle resourceBundle) {

        // startDatabasePolling();

        pieceRequestColumn.setCellValueFactory(new PropertyValueFactory<>("requestDate"));
        arrivalDateColumn.setCellValueFactory(new PropertyValueFactory<>("arrivalDate"));
        supplierTypeColumn.setCellValueFactory(new PropertyValueFactory<>("supplierType"));
        pieceTypeColumn.setCellValueFactory(new PropertyValueFactory<>("pieceType"));
        pieceQuantityColumn.setCellValueFactory(new PropertyValueFactory<>("pieceQuantity"));

    }

    public TableView<DayGUI> getTableView() {
        return tableView;
    }

    public void setProductionDay(String value) {
        productionDay.setText(value);
    }

    public void setProductionTime(String value) {
        currentTime.setText(value);
    }

    /// PRODUCTION PLAN

    public void setActivitiesFromDatabase() {
        ArrayList<DayGUI> activitiesData = getActivitiesDataFromDatabase();

        Platform.runLater(() -> {
            tableView.getItems().clear();
            tableView.getColumns().clear();

            Map<Integer, String> activitiesByDay = new HashMap<>();

            for (DayGUI day : activitiesData) {
                activitiesByDay.put(day.getDayGui(), day.getActivityGui());
            }

            List<Integer> days = new ArrayList<>(activitiesByDay.keySet());
            Collections.sort(days);

            for (int day : days) {
                TableColumn<DayGUI, String> dayColumn = new TableColumn<>("Day " + day);
                dayColumn.setCellValueFactory(cellData -> new SimpleStringProperty(activitiesByDay.get(day)));
                tableView.getColumns().add(dayColumn);
            }

            tableView.getItems().add(new DayGUI(0, ""));

            tableView.refresh();
        });
    }

    public ArrayList<DayGUI> getActivitiesDataFromDatabase() {
        ArrayList<DayGUI> activitiesData = new ArrayList<>();
        st = null;
        rs = null;

        try {
            st = c.createStatement();
            String query = "SELECT * FROM \"INFI\".\"ProductionPlan\"";
            rs = st.executeQuery(query);

            while (rs.next()) {
                int dayGui = rs.getInt("day");
                String activity = rs.getString("activities");

                DayGUI day = new DayGUI(dayGui, activity);
                activitiesData.add(day);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return activitiesData;
    }

    // PURCHASING PLAN

    public void setPurchasingPlanFromDatabase() {
        ArrayList<PurchasingPlanGUI> purchasingPlanData = getPurchasingPlanDataFromDatabase();

        Platform.runLater(() -> {
            orderTableView.getItems().clear();
            orderTableView.getColumns().clear();

            orderTableView.getItems().addAll(purchasingPlanData);

            TableColumn<PurchasingPlanGUI, Integer> pieceRequestColumn = new TableColumn<>("Request Date");
            pieceRequestColumn.setCellValueFactory(new PropertyValueFactory<>("requestDate"));

            TableColumn<PurchasingPlanGUI, String> arrivalDateColumn = new TableColumn<>("Arrival Date");
            arrivalDateColumn.setCellValueFactory(new PropertyValueFactory<>("arrivalDate"));

            TableColumn<PurchasingPlanGUI, String> supplierTypeColumn = new TableColumn<>("Supplier Type");
            supplierTypeColumn.setCellValueFactory(new PropertyValueFactory<>("supplierType"));

            TableColumn<PurchasingPlanGUI, String> pieceTypeColumn = new TableColumn<>("Piece Type");
            pieceTypeColumn.setCellValueFactory(new PropertyValueFactory<>("pieceType"));

            TableColumn<PurchasingPlanGUI, Integer> pieceQuantityColumn = new TableColumn<>("Piece Quantity");
            pieceQuantityColumn.setCellValueFactory(new PropertyValueFactory<>("pieceQuantity"));

            orderTableView.getColumns().addAll(pieceRequestColumn, arrivalDateColumn, supplierTypeColumn,
                    pieceTypeColumn, pieceQuantityColumn);

            orderTableView.refresh(); // Trigger UI refresh
        });
    }

    public ArrayList<PurchasingPlanGUI> getPurchasingPlanDataFromDatabase() {
        ArrayList<PurchasingPlanGUI> purchasingPlanData = new ArrayList<>();
        st = null;
        rs = null;

        try {
            st = c.createStatement();
            String query = "SELECT * FROM \"INFI\".\"PurchasingPlan\""; // Replace YourTableName with the actual table
                                                                        // name
            rs = st.executeQuery(query);

            while (rs.next()) {
                // Retrieve data from the result set
                int pieceRequest = rs.getInt("requestdate");
                int arrivalDate = rs.getInt("arrivaldate");
                String supplierType = rs.getString("supplier");
                String pieceType = rs.getString("pieceType");
                int pieceQuantity = rs.getInt("piecequantity");

                // Create a PurchasingPlanGUI object and add it to the list
                PurchasingPlanGUI purchasingPlan = new PurchasingPlanGUI(pieceRequest, arrivalDate, supplierType,
                        pieceType, pieceQuantity);
                purchasingPlanData.add(purchasingPlan);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return purchasingPlanData;
    }

    // ORDER COST

    public ArrayList<OrderCostGUI> getOrderCostDataFromDatabase() {
        ArrayList<OrderCostGUI> orderCostData = new ArrayList<>();
        st = null;
        rs = null;

        try {
            st = c.createStatement();
            String query = "SELECT * FROM \"INFI\".\"OrderCost\"";
            rs = st.executeQuery(query);

            while (rs.next()) {
                int orderID = rs.getInt("orderID");
                int cost = rs.getInt("cost");

                OrderCostGUI orderCost = new OrderCostGUI(orderID, cost);
                orderCostData.add(orderCost);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return orderCostData;
    }

    public void setOrderCostFromDatabase() {
        ArrayList<OrderCostGUI> orderCostData = getOrderCostDataFromDatabase();

        Platform.runLater(() -> {
            orderCostTable.getItems().clear();
            orderCostTable.getColumns().clear();

            orderCostTable.getItems().addAll(orderCostData);

            TableColumn<OrderCostGUI, Integer> orderIDColumn = new TableColumn<>("Order ID");
            orderIDColumn.setCellValueFactory(new PropertyValueFactory<>("orderID"));

            TableColumn<OrderCostGUI, Integer> costColumn = new TableColumn<>("Cost (€)");
            costColumn.setCellValueFactory(new PropertyValueFactory<>("cost"));

            orderCostTable.getColumns().addAll(orderIDColumn, costColumn);

            orderCostTable.refresh();
        });
    }

    public void disconnectDB() {
        try {
            if (st != null)
                st.close();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (rs != null)
                    rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (c != null)
                        c.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public Connection connectDB() {
        c = null;

        try {
            c = DataBase.connect();
            if (c == null) {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();

        }

        return c;
    }

}
