package Common.TimeCounting;

public class FactoryTimeFormat {

    int day;
    int hour;

    final int SECONDS_IN_A_DAY = 60;

    public FactoryTimeFormat(int day, int hour) {
        this.day = day;
        this.hour = hour;
    }

    public int getDay() {
        return this.day;
    }

    public void setDay(int day) {
        this.day = day;
    }

    public int getHour() {
        return this.hour;
    }

    public void setHour(int hour) {
        this.hour = hour;
    }

    public int toSeconds() {
        return this.day * SECONDS_IN_A_DAY + this.hour;
    }

    /**
     * Compares this time vs incoming time
     * 
     * @param time
     * @return negative number when the incoming is earlier, zero when its equal,
     *         and positive when is later
     */
    public FactoryTimeFormat difference(FactoryTimeFormat time) {

        if (null == time) {
            throw new IllegalArgumentException("Time is null in difference");
        }

        int currentInSeconds = this.toSeconds();
        int incomingInSeconds = time.toSeconds();

        int diff = currentInSeconds - incomingInSeconds;

        return FactoryTimeFormat.toFactoryTimeFormat(diff);
    }

    public FactoryTimeFormat add(FactoryTimeFormat time) {

        if (null == time) {
            throw new IllegalArgumentException("Time is null in add");
        }

        int currentInSeconds = this.toSeconds();
        int incomingInSeconds = time.toSeconds();

        int sum = currentInSeconds + incomingInSeconds;

        return FactoryTimeFormat.toFactoryTimeFormat(sum);
    }

    public static FactoryTimeFormat toFactoryTimeFormat(int diff) {
        FactoryTimeFormat ret = new FactoryTimeFormat(diff / 60, diff % 60);

        return ret;
    }

    @Override
    public String toString() {
        return String.format("Day %d, Hour %d", day, hour);
    }

}
