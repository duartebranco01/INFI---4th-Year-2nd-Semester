package Common.Communication.Tcp;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;

import Common.Piece.PieceType;
import Common.Piece.Transition;

public class TcpClient {

    private Socket socket;
    private ObjectOutputStream objectOutputStream;

    public TcpClient(String hostname, int port) throws IOException {
        socket = new Socket(hostname, port);
        objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
    }

    public void sendObject(Object object) throws IOException {

        objectOutputStream.writeObject(object);
    }

    public static void main(String[] args) throws IOException {

        String hostname = "localhost";
        int port = 1234;

        TcpClient client = new TcpClient(hostname, port);

        Transition transitionToSend = new Transition(1, 1, 1, PieceType.P1, PieceType.P6);

        for (;;) {
            client.sendObject(transitionToSend);
        }
    }
}
