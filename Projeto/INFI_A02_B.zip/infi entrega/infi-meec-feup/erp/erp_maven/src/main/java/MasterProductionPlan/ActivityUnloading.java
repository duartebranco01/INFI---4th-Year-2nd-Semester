package MasterProductionPlan;

import java.util.ArrayList;

import Common.Piece.Piece;
import Common.Piece.PieceType;
import Products.UnloadingDockType;

public class ActivityUnloading extends Activity {

    // private ArrayList<Integer> piecesToUnloadIDs;
    // private ArrayList<UnloadingDockType> unloadingDocks;

    // ActivityUnloading(int activityDuration, int orderId, ArrayList<Integer>
    // piecesToUnloadIDs, ArrayList<UnloadingDockType> unloadingDocks){
    // super(ActivityType.Unloading, activityDuration, orderId);
    // this.piecesToUnloadIDs = piecesToUnloadIDs;
    // this.unloadingDocks = unloadingDocks;
    // }

    private ArrayList<Piece> piecesToUnload;
    private ArrayList<UnloadingDockType> unloadingDocks;
    private Piece auxPiece;

    public ActivityUnloading(int activityDuration, int orderId, ArrayList<UnloadingDockType> unloadingDocks,
            ArrayList<Piece> piecesToUnload) {
        super(ActivityType.Unloading, activityDuration, orderId);
        this.unloadingDocks = unloadingDocks;
        this.piecesToUnload = piecesToUnload;
        this.auxPiece = this.piecesToUnload.get(0);
    }

    public ActivityUnloading(int activityStartTime, int activityEndTime,
            int activityDuration, int orderId, int day, ArrayList<Piece> piecesToUnload,
            ArrayList<UnloadingDockType> unloadingDocks) {
        super(ActivityType.Unloading, activityStartTime, activityEndTime, activityDuration, orderId, day);
        this.piecesToUnload = piecesToUnload;
        this.unloadingDocks = unloadingDocks;
        this.auxPiece = this.piecesToUnload.get(0);
    }

    public ArrayList<UnloadingDockType> getUnloadingDocks() {
        return this.unloadingDocks;
    }

    public ArrayList<Piece> getPiecesToUnload() {
        return this.piecesToUnload;
    }

    public String toString() {
        return super.toString()
                + "\t PieceType: " + auxPiece.getFinalType()
                + "\t Unloading docks: " + this.unloadingDocks.toString()
                + "\n\t Number of pieces: " + this.piecesToUnload.size()
                + "\t Pieces: " + this.piecesToUnload.toString();
    }

    public int getNumberOfPieces() {
        return this.piecesToUnload.size();
    }

    /**
     * Aux method to create schedule
     * 
     * @return
     */
    public PieceType getPieceType() {
        return this.piecesToUnload.get(0).getFinalType();
    }

    @Override
    public ActivityUnloading clone() {

        try {

            ActivityUnloading clone = (ActivityUnloading) super.clone();

            for (Piece currPiece : this.piecesToUnload) {
                clone.piecesToUnload.add(currPiece.clone());
            }
            for (UnloadingDockType currUnloadingDock : this.unloadingDocks) {
                clone.unloadingDocks.add(currUnloadingDock);
            }

            return clone;

        } catch (Exception e) {
            System.out.println(e.toString());
            return null;
        }

    }

}