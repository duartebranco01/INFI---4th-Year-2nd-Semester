package Common.Piece;

import java.io.Serializable;

import Common.Machine.MachineType;
import Common.Machine.ToolType;

public class Transition implements Serializable, Cloneable {

    private int pieceId;
    private int priorityInPiece; // can be used as a id
    private PieceType startType;
    private PieceType finalType;
    private int machiningTime;
    private ToolType neededTool;
    private int finalPriority;

    public Transition(int pieceId, int dueDate, int priorityInPiece, PieceType startType, PieceType finalType) {

        this.startType = startType;
        this.finalType = finalType;
        this.priorityInPiece = priorityInPiece;
        this.pieceId = pieceId;

        setMachiningTimeAndNeededTool();
        finalPriority = dueDate * 10 + priorityInPiece;
    }

    // // TODO VER MELHOR ISTO ASSUME QUE SO USO A MAQUINA 4 E CADA PECA SPAWNA
    // SOZINHA
    // public int worstCaseTransitionTime() {
    // return this.machiningTime + MachineType.M4.getTimeInConveyor();
    // }

    private void setMachiningTimeAndNeededTool() {
        switch (this.startType) {
            case P1:
                if (this.finalType == PieceType.P6) {
                    this.machiningTime = 20;
                    this.neededTool = ToolType.T1;
                }
                break;
            case P2:
                if (this.finalType == PieceType.P3) {
                    this.machiningTime = 10;
                    this.neededTool = ToolType.T2;
                } else if (this.finalType == PieceType.P4) {
                    this.machiningTime = 10;
                    this.neededTool = ToolType.T3;
                }
                break;
            case P3:
                if (this.finalType == PieceType.P6) {
                    this.machiningTime = 20;
                    this.neededTool = ToolType.T1;
                }
                break;
            case P4:
                if (this.finalType == PieceType.P7) {
                    this.machiningTime = 10;
                    this.neededTool = ToolType.T4;
                }
                break;
            case P5:
                break;
            case P6:
                if (this.finalType == PieceType.P8) {
                    this.machiningTime = 30;
                    this.neededTool = ToolType.T3;
                }
                break;
            case P7:
                if (this.finalType == PieceType.P9) {
                    this.machiningTime = 10;
                    this.neededTool = ToolType.T3;
                }
                break;
            case P8:
                break;
            case P9:
                if (this.finalType == PieceType.P5) {
                    this.machiningTime = 15;
                    this.neededTool = ToolType.T4;
                }
                break;
            default:
                break;

        }
    }

    public int getFinalPriority() {
        return this.finalPriority;
    }

    public void setFinalPriority(int finalPriority) {
        this.finalPriority = finalPriority;
    }

    public PieceType getStartType() {
        return startType;
    }

    public PieceType getFinalType() {
        return finalType;
    }

    public int getMachiningTime() {
        return machiningTime;
    }

    public int getPriorityInPiece() {
        return priorityInPiece;
    }

    public ToolType getNeededTool() {
        return neededTool;
    }

    public String toString() {
        return "\n\t\t\t\t Transition{\n" +
                "\t\t\t\t\t finalPriority=" + finalPriority +
                ",\n\t\t\t\t\t startType=" + startType +
                ",\n\t\t\t\t\t finalType=" + finalType +
                ",\n\t\t\t\t\t machiningTime=" + machiningTime +
                ",\n\t\t\t\t\t neededTool=" + neededTool +
                "\n\t\t\t\t}\n";
    }

    public String xmlStringToMes() {
        String xmlString = "<ErpTransition>\n";

        // xmlString += "<priorityInPiece>" + priorityInPiece + "</priorityInPiece>\n";
        xmlString += "<startType>" + startType + "</startType>\n";
        xmlString += "<finalType>" + finalType + "</finalType>\n";
        xmlString += "<neededTool>" + neededTool + "</neededTool>\n";
        // xmlString += "<finalPriority>" + finalPriority + "</finalPriority>\n";

        xmlString += "</ErpTransition>";

        return xmlString;
    }

    @Override
    public Transition clone() {
        try {
            return (Transition) super.clone();

        } catch (Exception e) {
            System.out.println(e.toString());
            return null;
        }
    }

}
