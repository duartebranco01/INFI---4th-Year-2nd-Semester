package Common.Communication.SQL;

import java.sql.Connection;
import java.sql.Statement;
import java.util.ArrayList;

import Common.Piece.Piece;
import Common.Piece.PieceType;
import Common.Suppliers.SupplierType;
import Erp.Gui.DayGUI;
import Erp.Gui.OrderCostGUI;
import Erp.Gui.PurchasingPlanGUI;
import MasterProductionPlan.Activity;
import MasterProductionPlan.ActivityProduction;
import MasterProductionPlan.ActivitySupplies;
import MasterProductionPlan.ActivityType;
import MasterProductionPlan.Day;
import Mes.Gui.OrderStatusGUI;

public class InsertIntoTablesERP extends DataBase {

    public boolean addOrderCost(ArrayList<OrderCostGUI> orderCostData) {

        Connection c = null;
        Statement st = null;

        c = super.connect();
        if (c == null)
            return false;

        try {
            String deleteQuery = "DELETE FROM \"INFI\".\"OrderCost\";";
            st = c.createStatement();
            st.executeUpdate(deleteQuery);

            for (int i = 0; i < orderCostData.size(); i++) {
                OrderCostGUI order = orderCostData.get(i);

                String query = "INSERT INTO \"INFI\".\"OrderCost\" (\"orderID\", \"cost\") VALUES ('"
                        + order.getOrderID() + "', '" + order.getCost() + "');";
                st = c.createStatement();
                st.executeUpdate(query);
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());

            return false;
        }
        return true;
    }

    public boolean addPurchasingPlan(ArrayList<PurchasingPlanGUI> purchasingPlanData) {

        Connection c = null;
        Statement st = null;

        c = super.connect();
        if (c == null)
            return false;

        try {
            String deleteQuery = "DELETE FROM \"INFI\".\"PurchasingPlan\";";
            st = c.createStatement();
            st.executeUpdate(deleteQuery);

            for (int i = 0; i < purchasingPlanData.size(); i++) {
                PurchasingPlanGUI orderP = purchasingPlanData.get(i);

                String query = "INSERT INTO \"INFI\".\"PurchasingPlan\" (\"requestdate\", \"arrivaldate\", \"supplier\", \"piecequantity\", \"pieceType\") VALUES ('"
                        + orderP.getRequestDate() + "', '" + orderP.getArrivalDate() + "', '"
                        + orderP.getSupplierType().toString()
                        + "', '" + orderP.getPieceQuantity() + "', '" + orderP.getPieceType().toString() + "');";
                st = c.createStatement();
                st.executeUpdate(query);
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());

            return false;
        }
        return true;
    }

    public boolean addProductionPlan(ArrayList<DayGUI> productionPlanData) {

        Connection c = null;
        Statement st = null;

        c = super.connect();
        if (c == null)
            return false;

        try {
            String deleteQuery = "DELETE FROM \"INFI\".\"ProductionPlan\";";
            st = c.createStatement();
            st.executeUpdate(deleteQuery);

            for (int i = 0; i < productionPlanData.size(); i++) {
                DayGUI orderPr = productionPlanData.get(i);

                String query = "INSERT INTO \"INFI\".\"ProductionPlan\" (\"day\", \"activities\") VALUES ('"
                        + orderPr.getDayGui() + "', '" + orderPr.getActivityGui() + "');";
                st = c.createStatement();
                st.executeUpdate(query);
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());

            return false;
        }
        return true;
    }

    public boolean addOrderStatusERP(int orderID, int totalPieces, int totalProductionTime, String status,
            int producedpieces, int pendingpieces) {
        Connection c = null;
        Statement st = null;

        c = super.connect();
        if (c == null)
            return false;

        try {
            // String deleteQuery = "DELETE FROM \"INFI\".\"OrderStats\";";
            // st = c.createStatement();
            // st.executeUpdate(deleteQuery);

            String query = "INSERT INTO \"INFI\".\"OrderStats\" (\"orderid\", \"status\", \"producedpieces\", \"pendingpieces\", \"totalproductiontime\", \"totalpieces\")  VALUES ('"
                    + orderID + "', '" + status + "', '" + producedpieces + "', '" + pendingpieces + "', '"
                    + totalProductionTime + "', '" + totalPieces + "')";

            st = c.createStatement();
            st.executeUpdate(query);

        } catch (Exception e) {
            System.out.println(e.getMessage());

            return false;
        }
        return true;
    }

    public static void main(String[] args) {

        ArrayList<Activity> activitiesList = new ArrayList<>();

        ArrayList<Piece> piecesFromSupplier2 = new ArrayList<Piece>();
        Piece p23 = new Piece(2, 3, 1, PieceType.P8);
        Piece p24 = new Piece(2, 4, 1, PieceType.P8);
        Piece p25 = new Piece(2, 5, 1, PieceType.P8);
        piecesFromSupplier2.add(p23);
        piecesFromSupplier2.add(p24);
        piecesFromSupplier2.add(p25);

        ArrayList<Piece> piecesFromSupplier3 = new ArrayList<Piece>();
        Piece p233 = new Piece(2, 3, 1, PieceType.P3);
        Piece p243 = new Piece(2, 4, 1, PieceType.P3);
        Piece p253 = new Piece(2, 5, 1, PieceType.P3);
        Piece p254 = new Piece(2, 5, 1, PieceType.P3);
        piecesFromSupplier3.add(p233);
        piecesFromSupplier3.add(p243);
        piecesFromSupplier3.add(p253);
        piecesFromSupplier3.add(p254);

        ActivitySupplies suppliesActivity1 = new ActivitySupplies(ActivityType.Supplies, 0, 15,
                40, 4, 8, SupplierType.A, piecesFromSupplier2);

        ActivitySupplies suppliesActivity2 = new ActivitySupplies(ActivityType.Supplies, 0, 15,
                40, 4, 15, SupplierType.B, piecesFromSupplier2);

        ActivitySupplies suppliesActivity3 = new ActivitySupplies(ActivityType.Supplies, 0, 15,
                40, 4, 5, SupplierType.C, piecesFromSupplier3);

        ActivityProduction production = new ActivityProduction(ActivityType.Production, 1, 1,
                1, 1, 1, piecesFromSupplier2, 1);
        ActivityProduction production2 = new ActivityProduction(ActivityType.Production, 1, 1,
                1, 1, 1, piecesFromSupplier2, 1);

        activitiesList.add(suppliesActivity1);
        activitiesList.add(production2);
        activitiesList.add(suppliesActivity2);
        activitiesList.add(production);
        activitiesList.add(suppliesActivity3);

        InsertIntoTablesERP insertIntoTables = new InsertIntoTablesERP();

        // ArrayList<PurchasingPlanGUI> purchasingPlanList =
        // PurchasingPlanGUI.createPurchasingPlanGUIList(activitiesList);
        /*
         * boolean success = insertIntoTables.addPurchasingPlan(purchasingPlanList);
         * 
         * if (success) {
         * System.out.println("Purchasing plan data added successfully.");
         * } else {
         * System.out.println("Failed to add purchasing plan data.");
         * }
         */

        ArrayList<Day> daysList = new ArrayList<>();
        daysList.add(new Day(1));
        daysList.add(new Day(2));
        daysList.add(new Day(3));

        ArrayList<Activity> activitiesList2 = new ArrayList<>();
        activitiesList2.add(new Activity(ActivityType.Supplies, 8, 10, 2, 1, 1));
        activitiesList2.add(new Activity(ActivityType.Production, 9, 12, 3, 3, 2));
        activitiesList2.add(new Activity(ActivityType.Unloading, 10, 14, 4, 4, 2));
        activitiesList2.add(new Activity(ActivityType.Supplies, 15, 17, 2, 5, 3));
        activitiesList2.add(new Activity(ActivityType.Unloading, 11, 14, 3, 6, 3));

        // ArrayList<DayGUI> dayGUIList = DayGUI.createDayGUIList(daysList,
        // activitiesList2);

        // for (DayGUI dayGUI : dayGUIList) {
        // System.out.println(dayGUI);
        // }

        // boolean success2 = insertIntoTables.addProductionPlan(dayGUIList);

        // if (success2) {
        // System.out.println("Production plan data added successfully.");
        // } else {
        // System.out.println("Failed to add Production plan data.");
        // }
    }
}
