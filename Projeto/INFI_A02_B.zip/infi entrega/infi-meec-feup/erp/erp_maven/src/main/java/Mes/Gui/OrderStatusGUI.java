package Mes.Gui;

public class OrderStatusGUI {

    public int orderID;

    public String status;

    public int producedPieces;

    public int pendingPieces;

    public int totalProductionTime;

    public int totalPieces;

    public OrderStatusGUI(int orderID, String status, int producedPieces, int pendingPieces, int totalPieces,
            int totalProductionTime) {
        this.orderID = orderID;
        this.status = status;
        this.producedPieces = producedPieces;
        this.pendingPieces = pendingPieces;
        this.totalPieces = totalPieces;
        this.totalProductionTime = totalProductionTime;
    }

    public OrderStatusGUI(int orderID, String status, int producedPieces, int pendingPieces,
            int totalProductionTime) {
        this.orderID = orderID;
        this.status = status;
        this.producedPieces = producedPieces;
        this.pendingPieces = pendingPieces;
        this.totalProductionTime = totalProductionTime;
    }

    public int getOrderID() {
        return orderID;
    }

    public void setOrderID(int orderID) {
        this.orderID = orderID;
    }

    public int getTotalPieces() {
        return totalPieces;
    }

    public void setTotalPieces(int totalPieces) {
        this.totalPieces = totalPieces;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getProducedPieces() {
        return producedPieces;
    }

    public void setProducedPieces(int producedPieces) {
        this.producedPieces = producedPieces;
    }

    public int getPendingPieces() {
        return pendingPieces;
    }

    public void setPendingPieces(int pendingPieces) {
        this.pendingPieces = pendingPieces;
    }

    public int getTotalProductionTime() {
        return totalProductionTime;
    }

    public void setTotalProductionTime(int totalProductionTime) {
        this.totalProductionTime = totalProductionTime;
    }
}
