package Mes.Main;

import java.io.IOException;
import java.net.SocketException;
import java.util.ArrayList;

import Common.Communication.Tcp.TcpServer;
import Common.Machine.Machine;
import Common.Machine.MachineType;
import Common.Machine.ToolType;
import Common.Piece.Piece;
import Common.Piece.PieceType;
import Common.TimeCounting.FactoryTimeFormat;
import Common.TimeCounting.TimeCounting;
import MasterProductionPlan.Activity;
import MasterProductionPlan.ActivityProduction;
import MasterProductionPlan.ActivitySwitchTools;
import MasterProductionPlan.Day;
import MasterProductionPlan.NewMasterProductionSchedule;
import Mes.Action.Action;
import Mes.Action.ActionType.ActionPath;
import Mes.Action.ActionType.ActionSwitchTools;
import Common.Communication.OpcUa.*;
import Common.Communication.SQL.InsertIntoTablesMES;
import Mes.Gui.HelloControllerMES;
import Mes.Gui.MachineStatsGUI;
import Mes.Gui.MesGui;
import Mes.Gui.UnloadingStatsGUI;
import Mes.Scheduler.*;
import Mes.Statistics.MesStatitics;

import org.eclipse.milo.opcua.stack.core.UaException;
import java.time.LocalTime;
import java.util.concurrent.ExecutionException;
import Common.Constants.*;

import static Mes.Gui.MesGui.startGUI;

public class MesMain {

    final static int recieveOrderTcpPort = 5555;
    static int currDay = -1;
    static TimeCounting dayCounter = new TimeCounting();
    static TcpServer recieveInitTimeTcpServer;
    static TcpServer receiveDayTcpServer;
    static MesScheduler scheduler;

    public static void testAction() throws ExecutionException, InterruptedException, UaException {

        OpcUaCodesysClient isPathAvailableCodesysVar;
        OpcUaCodesysClient isPathSixAvailableCodesysVar;

        ActionPath route1 = new ActionPath(1, 1, 3);
        isPathAvailableCodesysVar = new OpcUaCodesysClient("Init.x", "Machines_Paths");
        isPathSixAvailableCodesysVar = new OpcUaCodesysClient("Init.x", "Path6");
        // ActionPath unloading = new ActionPath(5);
        // ActionPath warehouse = new ActionPath(6);

        System.out.println(isPathAvailableCodesysVar.readBoolean());

        route1.execute();

    }

    public static void testTimelineExe() {

        ActionPath route1 = new ActionPath(1, 1, 3);
        ActionPath saveInWarehouse = new ActionPath(5, 1, 5);
        ActionPath sendToClient = new ActionPath(6, 5, 3);

        Action actionPath = new Action(route1, 1);
        Action actionSaveInWarehouse = new Action(saveInWarehouse, 2);
        Action ActionSendToClient = new Action(sendToClient, 3);
        Action ActionSwitchToTool = new Action(ActionSwitchTools.toTool3, 1);

        FactoryTimeFormat startTime = new FactoryTimeFormat(0, 0);

        Timeline timeline = new Timeline(startTime);

        try {
            // timeline.insertActionEarly(actionPath);
            // timeline.insertActionEarly(actionSaveInWarehouse);
            // timeline.insertActionEarly(ActionSendToClient);
            // timeline.insertActionEarly(ActionSwitchToTool);

        } catch (Exception e) {
            System.out.println("Error inserting actions");
            e.printStackTrace();
        }
        System.out.println(timeline);
        while (true) {

            timeline.execute(dayCounter.getCurrentTime());
        }

    }

    public static void OpcUaTest() throws UaException, ExecutionException, InterruptedException {

        OpcUaCodesysClient pathVarClient = new OpcUaCodesysClient("path", "PLC_PROG");// new OpcUaCodesysClient("path");
        pathVarClient.writeInt(1);
    }

    static void sincronizeClocksMes() throws IOException {

        Object receivedObject = recieveInitTimeTcpServer.receiveObject();
        LocalTime initTime = (LocalTime) receivedObject;
        dayCounter.setInitTime(initTime);
        System.out.println(initTime);
        recieveInitTimeTcpServer.stopServer();

    }

    static void updateStats() throws InterruptedException {

        System.out.println("updating stats...");
        // Update machine stats
        MesStatitics mesStatitics = new MesStatitics();
        InsertIntoTablesMES teste = new InsertIntoTablesMES();

        try {
            teste.addWarehouse(mesStatitics.total_piece_warehouse.readInt());
        } catch (Exception e) {
            System.out.println("error reading warehouse in opcua");
        }

        for (int machineNumber = 1; machineNumber < 5; machineNumber++) {
            ArrayList<MachineStatsGUI> machineStats = new ArrayList<>();

            for (int pieceNumber = 1; pieceNumber < 10; pieceNumber++) {
                Boolean checkRead = false;
                int retries = 0;
                while (!checkRead) {
                    try {
                        machineStats.add(new MachineStatsGUI("P" + Integer.toString(pieceNumber),
                                mesStatitics.getTotalPiecesMachines(machineNumber, pieceNumber)));
                        checkRead = true;
                    } catch (Exception e) {
                        System.out.println("Error reading opcua");
                        retries++;
                        if (retries == 3)
                            checkRead = true;
                        Thread.sleep(500);
                    }

                }

            }
            if (machineStats.size() == 9) {

                teste.addMachineStats(machineStats, machineNumber);
            }
        }

        for (int dockNumber = 1; dockNumber < 3; dockNumber++) {
            ArrayList<UnloadingStatsGUI> unloadingStats = new ArrayList<>();

            for (int pieceNumber = 1; pieceNumber < 10; pieceNumber++) {
                Boolean checkRead = false;
                int retries = 0;
                while (!checkRead) {
                    try {
                        unloadingStats.add(new UnloadingStatsGUI("P" + Integer.toString(pieceNumber),
                                mesStatitics.getTotalPiecesUnloading(dockNumber, pieceNumber)));
                        checkRead = true;
                    } catch (Exception e) {
                        retries++;
                        if (retries == 3)
                            checkRead = true;
                        System.out.println("Retrying to read from opcua");
                        Thread.sleep(500);
                    }

                }

            }
            System.out.println("size: " + unloadingStats.size());
            if (unloadingStats.size() == 9) {

                teste.addUnloadingStats(unloadingStats, dockNumber);
            }
        }

        try {
            teste.addUnloadingDockTime(1, mesStatitics.total_piece_pusher1.readInt());
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        try {
            teste.addUnloadingDockTime(1, mesStatitics.total_piece_pusher2.readInt());
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        try {
            int machiningTime1 = mesStatitics.total_time_1.readInt();
            int machiningTime2 = mesStatitics.total_time_2.readInt();
            int machiningTime3 = mesStatitics.total_time_3.readInt();
            int machiningTime4 = mesStatitics.total_time_4.readInt();

            if (0 != machiningTime1) {
                machiningTime1 /= 1000;
            }
            if (0 != machiningTime2) {
                machiningTime2 /= 1000;
            }
            if (0 != machiningTime3) {
                machiningTime3 /= 1000;
            }
            if (0 != machiningTime4) {
                machiningTime4 /= 1000;
            }

            teste.addMachineTime(1, machiningTime1);
            teste.addMachineTime(2, machiningTime2);
            teste.addMachineTime(3, machiningTime3);
            teste.addMachineTime(4, machiningTime4);

        } catch (Exception e) {
            System.out.println("Error sending machining total time");
        }
        Thread.sleep(60000);

        return;
    }

    static void setupMes() throws IOException {

        scheduler = new MesScheduler();
        receiveDayTcpServer = new TcpServer(CommunicationConstants.mesDayTcpPort);
        recieveInitTimeTcpServer = new TcpServer(CommunicationConstants.mesInitTimeTcpPort);

        receiveDayTcpServer.start();
        recieveInitTimeTcpServer.start();

        sincronizeClocksMes();

        System.out.println("Mes is starting...");
    }

    public static void main(String[] args) throws Exception {

        // MesGui.startGUI();
        setupMes();

        // Thread statsT = new Thread(() -> {
        // while (true) {
        // try {
        // updateStats();
        // } catch (InterruptedException e) {
        // // TODO Auto-generated catch block
        // e.printStackTrace();
        // }
        // }
        // });
        // statsT.start();

        int lastDay = 0;
        int firstDayWasRecieved = 0;

        while (true) {

            if (receiveDayTcpServer.getRunning() == false) {
                System.out.println("Server not running");
            }
            Day incoming = (Day) receiveDayTcpServer.receiveObject();
            if (null != incoming) {
                scheduler.insertNewDay(incoming, dayCounter.getCurrentTime());

                if (lastDay == dayCounter.getDay()) {
                    if (firstDayWasRecieved == 1) {
                        lastDay++;
                    } else {
                        firstDayWasRecieved = 1;
                    }
                }
            }
            scheduler.execute(dayCounter.getCurrentTime());
            if (dayCounter.getDayTime() > 12 && dayCounter.getDayTime() < 22) {
                scheduler.updateStats();
            }

        }
    }
}