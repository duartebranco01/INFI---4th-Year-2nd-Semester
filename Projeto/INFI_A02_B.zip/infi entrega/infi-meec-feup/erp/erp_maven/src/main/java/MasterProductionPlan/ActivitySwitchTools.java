package MasterProductionPlan;

import java.util.ArrayList;

import Common.Machine.MachineType;
import Common.Machine.ToolType;

public class ActivitySwitchTools extends Activity {

    private ToolType desiredTool;
    // private ArrayList<MachineType> machinesToChangeTool;

    public ActivitySwitchTools(int activityDuration, int orderId, ToolType desiredTool/*
                                                                                       * ,
                                                                                       * ArrayList<MachineType>
                                                                                       * machinesToChangeTool
                                                                                       */) {

        super(ActivityType.SwitchTools, activityDuration, orderId);

        if (desiredTool == null) {
            throw new IllegalArgumentException("Desired tool cannot be null");
        }

        // if (machinesToChangeTool == null || machinesToChangeTool.isEmpty()) {
        // throw new IllegalArgumentException("Machines to change tool cannot be null or
        // empty");
        // }

        this.desiredTool = desiredTool;
        // this.machinesToChangeTool = machinesToChangeTool;
    }

    public ActivitySwitchTools(ActivityType activityType, int activityStartTime, int activityEndTime,
            int activityDuration, int orderId, int day, ToolType desiredTool) {

        super(activityType, activityStartTime, activityEndTime, activityDuration, orderId, day);
        this.desiredTool = desiredTool;
    }

    public ToolType getDesiredTool() {
        return this.desiredTool;
    }

    // public ArrayList<MachineType> getMachineToChangeTool() {
    // return this.machinesToChangeTool;
    // }

    public String toString() {
        return super.toString()
                + "\t\t desiredTool: " + this.desiredTool.toString();
        // + "\n\t\t machines: " + this.machinesToChangeTool.toString();
    }

    @Override
    // TODO O SUPER.CLONE FAZ O CLONE DA PARTE DESTE LADO? OU REMTE SO AO SUPER DO
    // ACTIVITY?????
    public ActivitySwitchTools clone() {
        try {

            return (ActivitySwitchTools) super.clone();

        } catch (Exception e) {
            System.out.println(e.toString());
            return null;
        }
    }

}