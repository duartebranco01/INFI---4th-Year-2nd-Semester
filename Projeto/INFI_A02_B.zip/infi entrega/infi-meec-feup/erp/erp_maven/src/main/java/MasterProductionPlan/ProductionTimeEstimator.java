package MasterProductionPlan;

import Common.Machine.ToolType;
import javafx.util.Pair;
import Common.Constants.TimeConstants;
import Common.Machine.MachineType;

public class ProductionTimeEstimator {

    private static int timeToWarehouse(int numberOfMachinesUsed, int toolTypeNumber) {

        // ver os tempos no plc
        switch (toolTypeNumber) {
            case 1:
                switch (numberOfMachinesUsed) {
                    case 3:
                        return TimeConstants.warehouseTimeMachine4;

                    default:
                        return TimeConstants.warehouseTimeMachine1;

                }

            case 2:
                return TimeConstants.warehouseTimeMachine2;
            case 3:
                return TimeConstants.warehouseTimeMachine3;
            case 4:
                return TimeConstants.warehouseTimeMachine4;

            default:
                break;
        }

        return 0;

    }

    private static int calculateEndOfMachining(int numberPieces, ToolType toolNeeded) {

        int lastMachineNumber = calculateLastRoundNumberOfPieces(numberPieces, toolNeeded).getKey();
        switch (lastMachineNumber) {
            case 1:
                return TimeConstants.transportTimeMachine1;
            case 2:
                return TimeConstants.transportTimeMachine2;
            case 3:
                return TimeConstants.transportTimeMachine3;
            case 4:
                return TimeConstants.transportTimeMachine4;
            default:
                break;
        }

        return -1;
    }

    private static Pair<Integer, Integer> calculateLastRoundNumberOfPieces(int numberPieces, ToolType toolNeeded) {
        int unsignedPieces = numberPieces;
        int numberOfPiecesInAction = 0;
        int machineNumber = 5;
        int numberOfRounds = 0;

        while (unsignedPieces > 0) {
            switch (toolNeeded.toInt()) {
                case 2:
                    numberOfPiecesInAction = Math.min(unsignedPieces, 2);
                    break;
                case 3:
                    numberOfPiecesInAction = Math.min(unsignedPieces, 4);
                    break;
                default:
                    numberOfPiecesInAction = Math.min(unsignedPieces, 3);
                    break;
            }

            numberOfRounds++;
            unsignedPieces -= numberOfPiecesInAction;
            machineNumber = Math.min(machineNumber, numberOfPiecesInAction);
        }

        return new Pair<Integer, Integer>(machineNumber,
                numberOfRounds);
    }

    public static int calculateProductionTime(int numberPieces, ToolType toolNeeded, int machiningTime) {
        Pair<Integer, Integer> lastRound = calculateLastRoundNumberOfPieces(numberPieces, toolNeeded);
        int machineNumber = lastRound.getKey();
        int numberOfRounds = lastRound.getValue();
        int numberOfPiecesInLastRound = machineNumber;

        return calculateEndOfMachining(toolNeeded.maxPiecesForTools(), toolNeeded) * (numberOfRounds - 1)
                + numberOfRounds * machiningTime +
                calculateEndOfMachining(numberOfPiecesInLastRound, toolNeeded)
                + timeToWarehouse(numberOfPiecesInLastRound, toolNeeded.toInt());
    }

    public static void main(String[] args) {
        ToolType toolNeeded = ToolType.T3;
        int numberPieces = 5;
        int machiningTime = 10;

        // Pair<Integer, Integer> lastRound =
        // calculateLastRoundNumberOfPieces(numberPieces, toolNeeded);
        // int machineNumber = lastRound.getKey();
        // System.out.println("Last machine number" + machineNumber);

        // int productionTime = calculateEndOfMachining(numberPieces, ToolType.T1) + 10
        // + timeToWarehouse(numberPieces, toolNeeded.toInt());

        // System.out.println(calculateEndOfMachining(numberPieces, ToolType.T1));
        // System.out.println(timeToWarehouse(numberPieces, toolNeeded.toInt()));
        // System.out.println(productionTime);

        System.out.println(calculateProductionTime(numberPieces, toolNeeded, machiningTime));
    }
}