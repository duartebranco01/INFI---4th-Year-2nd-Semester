package Products;

import javafx.util.Pair;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

import Common.Piece.Piece;
import Common.Piece.PieceType;
import Common.Suppliers.SupplierType;;

public class Warehouse implements Serializable {

    private final int maxCapacity = 32;

    // pensar em array de pieces e metodos para contar peças tendo em conta que
    // podem estar alocado=ter orderId preenchidfo
    // diferenciar entre peças alocadas e peças efetivamente livres
    private ArrayList<Piece> storedPieces;

    public Warehouse(ArrayList<Piece> storedPieces) {

        if (storedPieces == null)
            this.storedPieces = new ArrayList<Piece>();
        else
            this.storedPieces = storedPieces;
    }

    public Warehouse() {
        this.storedPieces = new ArrayList<Piece>();
    }

    public int getMaxCapacity() {
        return maxCapacity;
    }

    public ArrayList<Piece> getStoredPieces() {
        return storedPieces;
    }

    public void setStoredPieces(ArrayList<Piece> storedPieces) {
        this.storedPieces = storedPieces;
    }

    // adicionar peças para a warehouse

    // TODO esta funçao vai ser inutil pq adiciona sempre a mesma peça (com o mesmo
    // pieceID)
    // depois é preciso ajustar como é que se vai adicionar as peças
    /*
     * public int addPiecesToWarehouse(Piece piece, int numberOfPieces) {
     * 
     * if (countTotalStoredPieces() + numberOfPieces <= maxCapacity) {
     * 
     * while(numberOfPieces != 0)
     * {
     * storedPieces.add(piece);
     * numberOfPieces--;
     * }
     * 
     * return 0;
     * }
     * 
     * else return -1;
     * }
     */

    // TODO im sorry god
    public Pair<ArrayList<Integer>, ArrayList<SupplierType>> removeFreePiecesByQuantityAndDay(int quantity,
            int dayIndex) {

        ArrayList<Integer> suppliedDays = new ArrayList<Integer>();
        ArrayList<SupplierType> supplierTypes = new ArrayList<SupplierType>();

        Iterator<Piece> iterator = this.storedPieces.iterator();
        int count = 0;

        while (iterator.hasNext() && count < quantity) {
            Piece currPieceInWarehouse = iterator.next();

            if (currPieceInWarehouse.getPieceId() < 0 && currPieceInWarehouse.getSuppliedArrivalDate() < dayIndex) {
                suppliedDays.add(currPieceInWarehouse.getSuppliedArrivalDate());
                supplierTypes.add(currPieceInWarehouse.getSupplierType());
                iterator.remove();
                count++;
            }
        }

        Pair<ArrayList<Integer>, ArrayList<SupplierType>> supplierDaysAndTypes = new Pair<ArrayList<Integer>, ArrayList<SupplierType>>(
                suppliedDays, supplierTypes);

        return supplierDaysAndTypes;
    }

    // TODO disgusting
    public void removePiecesFromWarehouseByPieceId(ArrayList<Piece> piecesToRemove) {
        Iterator<Piece> iterator = this.storedPieces.iterator();

        while (iterator.hasNext()) {
            Piece currPieceInWarehouse = iterator.next();

            for (Piece currPieceToRemove : piecesToRemove) {
                if (currPieceToRemove.getPieceId() == currPieceInWarehouse.getPieceId()) {
                    iterator.remove();
                    break;
                }
            }
        }
    }

    public int addPiecesToWarehouse(ArrayList<Piece> pieces) {

        if (countTotalStoredPieces() + pieces.size() <= maxCapacity) {
            for (Piece piece : pieces) {
                storedPieces.add(piece);
            }

            return 0;
        }

        else
            return -1;

    }

    //
    // contar as peças de um certo tipo
    public int countStoredPiecesOfType(PieceType pieceType) {
        int count = 0;

        for (Piece storedPiece : storedPieces) {
            if (storedPiece.getRawStartType().equals(pieceType)) {
                count++;
            }
        }
        return count;
    }

    // contar as peças de um certo tipo que ja estão alocadas
    public int countAllocatedPiecesOfType(PieceType pieceType) {
        int count = 0;

        for (Piece storedPiece : storedPieces) {
            if (storedPiece.getRawStartType().equals(pieceType) && storedPiece.getOrderId() > 0) {
                count++;
            }
        }
        return count;
    }

    // contar as peças de um certo tipo livres
    public int countFreePiecesOfTypeOnDay(PieceType pieceType, int dayIndex) {
        int count = 0;

        for (Piece storedPiece : storedPieces) {
            if (storedPiece.getRawStartType().equals(pieceType) && storedPiece.getOrderId() < 0
                    && storedPiece.getSuppliedArrivalDate() < dayIndex) {
                count++;
            }
        }
        return count;
    }

    public ArrayList<Piece> checkFreePiecesOfType(PieceType pieceType) {

        ArrayList<Piece> freePieces = new ArrayList<Piece>();

        for (Piece currPiece : this.storedPieces) {
            if (currPiece.getPieceId() < 0 && currPiece.getRawStartType() == pieceType)
                freePieces.add(currPiece);
        }

        return freePieces;
    }

    // contar todas as peças no armazem
    public int countTotalStoredPieces() {
        return storedPieces.size();
    }

    // contar todas as peças no armazem livres
    public int countTotalFreePieces() {
        int count = 0;

        for (Piece storedPiece : storedPieces) {
            if (storedPiece.getOrderId() < 0)
                count++;
        }
        return count;
    }

    // contar todas as peças no armazem já alocadas

    public int countTotalAllocatedPieces() {
        return countTotalStoredPieces() - countTotalFreePieces();
    }

    public int freeSpace() {
        return getMaxCapacity() - countTotalStoredPieces();
    }

    // TODO ESTE METODO ERA SUPER SUS PORQUE OS OBJETOS FREE PIECES CRIADOS NAO
    // PERTENCEM À LISTA PASSADA DOS IN PICES,
    // LOGO ERA IMPOSSIVEL ALTERAR OS SEUS VALORES POR REFERENCIA MAIS TARDE
    // É MELHOR REMOVER AS FREE PIECES E ADICIONAR AS INPIECES QUE CABIAM NAS FREE
    // PIECES (kill me)
    // public void allocateFreePieces(PieceType startingPieceType, PieceType
    // finalPieceType,
    // ArrayList<Transition> transitionList, int startingOrderID, int quantity, int
    // dueDate) {
    // int count = 0;

    // for (Piece storedPiece : storedPieces) {
    // if (count > quantity) {
    // break;
    // }

    // if (storedPiece.getRawStartType().equals(startingPieceType) &&
    // storedPiece.getOrderId() < 0) {
    // System.out.println("Origianal Stored Piece: " + storedPiece);
    // storedPiece.setOrderId(startingOrderID);
    // // storedPiece.setRawStartType(startingPieceType);
    // storedPiece.setFinalType(finalPieceType);
    // storedPiece.setDueDate(dueDate);
    // storedPiece.setOrderedTransitionsList(transitionList);
    // startingOrderID++;
    // count++;
    // System.out.println("After allocating Stored Piece: " + storedPiece);
    // }
    // }
    // }

    public void removeOrderIdFromPiece(PieceType pieceType, int orderID, int numberOfPiecesToRemove) {
        int count = 0;

        for (Piece piece : storedPieces) {
            if (piece.getRawStartType() == pieceType && piece.getOrderId() == orderID) {
                piece.setOrderId(-1);
                count++;

                if (count == numberOfPiecesToRemove)
                    break;

            }
        }
    }

    public static void main(String[] args) {
        /*
         * 
         * ArrayList<Piece> warehousePieces = new ArrayList<>();
         * 
         * Warehouse warehouse = new Warehouse(warehousePieces);
         * 
         * // test addPiecesToWarehouse
         * 
         * warehouse.addPiecesToWarehouse(new Piece(1, P1), 1);
         * warehouse.addPiecesToWarehouse(new Piece(2, P2), 1);
         * warehouse.addPiecesToWarehouse(new Piece(3, P2), 1);
         * warehouse.addPiecesToWarehouse(new Piece(0, P5), 1);
         * warehouse.addPiecesToWarehouse(new Piece(7, P5), 1);
         * 
         * 
         * // test countStoredPieces
         * int count1 = warehouse.countStoredPieces(PieceType.P1);
         * System.out.println(PieceType.P1.toString() + " Stored Pieces = " + count1);
         * 
         * int count2 = warehouse.countStoredPieces(PieceType.P2);
         * System.out.println(PieceType.P2.toString() + " StoredPieces = " + count2);
         * 
         * int count3 = warehouse.countStoredPieces(PieceType.P5);
         * System.out.println(PieceType.P5.toString() + " StoredPieces = " + count3);
         * 
         * System.out.println("\n");
         * 
         * // test countAllocatedPieces
         * int count4 = warehouse.countAllocatedPieces(PieceType.P1);
         * System.out.println(PieceType.P1.toString() + " Allocated Pieces = " +
         * count4);
         * 
         * int count5 = warehouse.countAllocatedPieces(PieceType.P2);
         * System.out.println(PieceType.P2.toString() + " Allocated Pieces = " +
         * count5);
         * 
         * int count6 = warehouse.countAllocatedPieces(PieceType.P5);
         * System.out.println(PieceType.P5.toString() + " Allocated Pieces = " +
         * count6);
         * 
         * System.out.println("\n");
         * 
         * // test countFreePieces
         * int count7 = warehouse.countFreePieces(PieceType.P1);
         * System.out.println(PieceType.P1.toString() +" Free Pieces = " + count7);
         * 
         * int count8 = warehouse.countFreePieces(PieceType.P2);
         * System.out.println(PieceType.P2.toString() +" Free Pieces = " + count8);
         * 
         * int count9 = warehouse.countFreePieces(PieceType.P5);
         * System.out.println(PieceType.P5.toString() +" Free Pieces = " + count9);
         * 
         * System.out.println("\n");
         * 
         * 
         * // test the countTotalStoredPieces method
         * int count10 = warehouse.countTotalStoredPieces();
         * System.out.println("Total Stored Pieces = " + count10);
         * 
         * // test the countTotalFreePieces method
         * int count11 = warehouse.countTotalFreePieces();
         * System.out.println("Total Free Pieces = " + count11);
         * 
         * // test the countTotalAllocatedPieces method
         * int count12 = warehouse.countTotalAllocatedPieces();
         * System.out.println("Total Allocated Pieces result = " + count12);
         * System.out.println("\n");
         * 
         * System.out.println("Free Space = " + warehouse.freeSpace());
         * System.out.println("\n");
         * 
         */

    }

}
