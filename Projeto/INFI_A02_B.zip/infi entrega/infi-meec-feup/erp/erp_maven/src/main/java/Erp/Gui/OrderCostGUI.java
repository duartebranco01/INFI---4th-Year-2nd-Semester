package Erp.Gui;

public class OrderCostGUI {

    public int orderID;
    public int cost;

    public OrderCostGUI(int orderID, int cost) {
        this.orderID = orderID;
        this.cost = cost;
    }

    public int getOrderID() {
        return orderID;
    }

    public void setOrderID(int orderID) {
        this.orderID = orderID;
    }

    public int getCost() {
        return cost;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }
}
