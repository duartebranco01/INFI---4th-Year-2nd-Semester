package Erp.OrderInfo;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import Common.Piece.PieceType;
import Common.Piece.Transition;

import org.w3c.dom.Node;

public class XmlParser {

    private NodeList nodesList;

    public NodeList readXml(String incomingXml) throws Exception {
        incomingXml = incomingXml.replaceAll("\n", "").replaceAll("\r", "").replaceAll(">\\s+<", "><");

        InputSource inputSource = new InputSource(new StringReader(incomingXml));
        DocumentBuilder documentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        Document document = documentBuilder.parse(inputSource);

        if (document.hasChildNodes()) {
            nodesList = document.getChildNodes();
        }

        return nodesList;
    }

    public ArrayList<OrderInfo> createOrderInfo() {
        NodeList orderList = nodesList.item(1).getChildNodes();

        if (orderList == null) {
            throw new IllegalArgumentException("orderList is null");
        }
        if (orderList.item(1).toString() == "[PRODUCTION_ORDERS: null]") {
            orderList = nodesList.item(1).getChildNodes();
        }
        Node clientNode = orderList.item(0);
        if (clientNode == null) {
            throw new IllegalArgumentException("clientNode is null");
        }
        String clientName = clientNode.getAttributes().getNamedItem("NameId").getNodeValue();
        ArrayList<OrderInfo> orderInfos = new ArrayList<>();
        Node rootNode = nodesList.item(1);

        Element rootElement;
        if (rootNode instanceof Element) {
            rootElement = (Element) rootNode;
            // Rest of your code for processing the root element
        } else {
            throw new IllegalArgumentException("Root node is not an Element");
        }

        NodeList orders = rootElement.getElementsByTagName("Order");
        for (int i = 0; i < orders.getLength(); i++) {
            Element order = (Element) orders.item(i);
            int number = Integer.parseInt(order.getAttribute("Number"));
            PieceType finalType = PieceType.fromString(order.getAttribute("WorkPiece"));
            int quantity = Integer.parseInt(order.getAttribute("Quantity"));
            int dueDate = Integer.parseInt(order.getAttribute("DueDate"));
            int latePen = Integer.parseInt(order.getAttribute("LatePen"));
            int earlyPen = Integer.parseInt(order.getAttribute("EarlyPen"));
            OrderInfo orderInfo = new OrderInfo(clientName, number, finalType, quantity,
                    dueDate, latePen, earlyPen);
            orderInfos.add(orderInfo);
        }
        return orderInfos;
    }

    public ArrayList<Transition> createTransitionsList() {
        ArrayList<Transition> transitionsList = new ArrayList<Transition>();

        return transitionsList;

    }

    public static void main(String[] args) {
        String xmlString = "<?xml version=\"1.0\"?><class><Client NameId=\"FEUP\" /><Order Number=\"001\" WorkPiece=\"P6\" Quantity=\"50\" DueDate=\"10\" LatePen=\"11\" EarlyPen=\"15\"></Order><Order Number=\"002\" WorkPiece=\"P4\" Quantity=\"52\" DueDate=\"70\" LatePen=\"14\" EarlyPen=\"25\"></Order><Order Number=\"003\" WorkPiece=\"P5\" Quantity=\"80\" DueDate=\"00\" LatePen=\"12\" EarlyPen=\"17\"></Order><Order Number=\"004\" WorkPiece=\"P3\" Quantity=\"30\" DueDate=\"40\" LatePen=\"19\" EarlyPen=\"16\"></Order></class>";
        XmlParser parser = new XmlParser();
        try {
            NodeList nodes = parser.readXml(xmlString);
            System.out.println("Root element: " + nodes.item(0).getNodeName());
            List<OrderInfo> orderList = parser.createOrderInfo();
            System.out.println("Parsed orders: " + orderList);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
