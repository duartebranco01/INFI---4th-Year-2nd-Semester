package Mes.Scheduler;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.ExecutionException;
import org.eclipse.milo.opcua.stack.core.UaException;
import Common.Communication.OpcUa.OpcUaCodesysClient;
import Common.Communication.SQL.InsertIntoTablesMES;
import Common.Machine.ToolType;
import Common.TimeCounting.FactoryTimeFormat;
import MasterProductionPlan.Activity;
import MasterProductionPlan.ActivityProduction;
import MasterProductionPlan.ActivitySupplies;
import MasterProductionPlan.ActivitySwitchTools;
import MasterProductionPlan.ActivityTransportToMachines;
import MasterProductionPlan.ActivityUnloading;
import MasterProductionPlan.Day;
import Mes.Action.Action;
import Mes.Action.ActionType.*;
import Mes.Gui.MachineStatsGUI;
import Mes.Gui.OrderStatusGUI;
import Mes.Gui.UnloadingStatsGUI;
import Mes.Statistics.MesStatitics;

public class MesScheduler {

    Timeline productionTimeline;
    Timeline switchToolsTimeline;
    int lastDayRecieved = -1;
    FactoryTimeFormat currentTime;

    int currentTool = 0;

    ArrayList<ToolType> currentToolSet;

    OpcUaCodesysClient isPathAvailableCodesysVar;
    OpcUaCodesysClient isPathSixAvailableCodesysVar;

    public MesScheduler() {
        FactoryTimeFormat startTime = new FactoryTimeFormat(0, 0);
        this.productionTimeline = new Timeline(startTime);
        this.switchToolsTimeline = new Timeline(startTime);

        // if(Machine_Paths.Init.x)
        isPathAvailableCodesysVar = new OpcUaCodesysClient("waiting", "Machine_Paths");

        isPathSixAvailableCodesysVar = new OpcUaCodesysClient("Init.x", "Path6");
        new OpcUaCodesysClient(null, "Prog.PLC_PROG");
    }

    public Timeline getProductionTimeline() {
        return this.productionTimeline;
    }

    private void setCurrentTime(FactoryTimeFormat currentTime) {
        this.currentTime = currentTime;
    }

    public void updateStats() throws InterruptedException {

        if ((this.productionTimeline.getSize() + this.switchToolsTimeline.getSize()) != 0) {
            return;

        }

        System.out.println("updating stats...");
        // Update machine stats
        MesStatitics mesStatitics = new MesStatitics();
        InsertIntoTablesMES teste = new InsertIntoTablesMES();

        try {
            teste.addWarehouse(mesStatitics.total_piece_warehouse.readInt());
        } catch (Exception e) {
            System.out.println("error reading warehouse in opcua");
        }

        for (int machineNumber = 1; machineNumber < 5; machineNumber++) {
            ArrayList<MachineStatsGUI> machineStats = new ArrayList<>();

            for (int pieceNumber = 1; pieceNumber < 10; pieceNumber++) {
                Boolean checkRead = false;
                int retries = 0;
                while (!checkRead) {
                    try {
                        machineStats.add(new MachineStatsGUI("P" + Integer.toString(pieceNumber),
                                mesStatitics.getTotalPiecesMachines(machineNumber, pieceNumber)));
                        checkRead = true;
                    } catch (Exception e) {
                        System.out.println("Error reading opcua");
                        retries++;
                        if (retries == 3)
                            checkRead = true;
                        Thread.sleep(500);
                    }

                }

            }
            if (machineStats.size() == 9) {

                teste.addMachineStats(machineStats, machineNumber);
            }
        }

        for (int dockNumber = 1; dockNumber < 3; dockNumber++) {
            ArrayList<UnloadingStatsGUI> unloadingStats = new ArrayList<>();

            for (int pieceNumber = 1; pieceNumber < 10; pieceNumber++) {
                Boolean checkRead = false;
                int retries = 0;
                while (!checkRead) {
                    try {
                        unloadingStats.add(new UnloadingStatsGUI("P" + Integer.toString(pieceNumber),
                                mesStatitics.getTotalPiecesUnloading(dockNumber, pieceNumber)));
                        checkRead = true;
                    } catch (Exception e) {
                        retries++;
                        if (retries == 3)
                            checkRead = true;
                        System.out.println("Retrying to read from opcua");
                        Thread.sleep(500);
                    }

                }

            }
            System.out.println("size: " + unloadingStats.size());
            if (unloadingStats.size() == 9) {

                teste.addUnloadingStats(unloadingStats, dockNumber);
            }
        }

        try {
            teste.addUnloadingDockTime(1, mesStatitics.total_piece_pusher1.readInt());
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        try {
            teste.addUnloadingDockTime(2, mesStatitics.total_piece_pusher2.readInt());
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        try {
            int machiningTime1 = mesStatitics.total_time_1.readInt();
            int machiningTime2 = mesStatitics.total_time_2.readInt();
            int machiningTime3 = mesStatitics.total_time_3.readInt();
            int machiningTime4 = mesStatitics.total_time_4.readInt();

            if (0 != machiningTime1) {
                machiningTime1 /= 1000;
            }
            if (0 != machiningTime2) {
                machiningTime2 /= 1000;
            }
            if (0 != machiningTime3) {
                machiningTime3 /= 1000;
            }
            if (0 != machiningTime4) {
                machiningTime4 /= 1000;
            }

            teste.addMachineTime(1, machiningTime1);
            teste.addMachineTime(2, machiningTime2);
            teste.addMachineTime(3, machiningTime3);
            teste.addMachineTime(4, machiningTime4);

        } catch (Exception e) {
            System.out.println("Error sending machining total time");
        }

        return;
    }

    public void insertNewDay(Day day, FactoryTimeFormat time) throws Exception {
        setCurrentTime(time);

        if (lastDayRecieved == day.getCurrDay()) {
            return;
        }
        lastDayRecieved = day.getCurrDay();
        System.out.println("Recieved day " + lastDayRecieved);
        Schedule(day);
        toString(lastDayRecieved);
        updateStats();
    }

    // public String fullSceduleString() {
    // StringBuilder sb = new StringBuilder();
    // for()
    // }

    private void insertActionInTimelines(ArrayList<Action> actionsList) throws Exception {

        Collections.sort(actionsList, Comparator.comparing(Action::getPriority));

        for (Action action : actionsList) {

            if (action.getActionType() instanceof ActionPath) {
                // if (switchToolsTimeline.getSize() != 0) {
                // action.setDuration(action.getDuration().add(new FactoryTimeFormat(0, 20)));
                // }
                System.out.println("Inserting action:\n");
                productionTimeline.insertActionEarly(action, currentTime);
            }
            if (action.getActionType() instanceof ActionSwitchTools) {
                System.out.println("Inserting action:\n");
                switchToolsTimeline.insertActionEarly(action, currentTime);
            }
        }
    }

    private FactoryTimeFormat Schedule(Day day) throws Exception {

        InsertIntoTablesMES t = new InsertIntoTablesMES();

        ArrayList<Activity> activitiesList = day.getDayActivityList();

        if (null == activitiesList) {
            throw new IllegalArgumentException("day activity list is null");
        }
        if (0 == activitiesList.size()) {
            System.out.println("Activities list is empty");
            return new FactoryTimeFormat(day.getCurrDay(), 0);
        }

        ArrayList<Action> actionList = new ArrayList<Action>();
        ArrayList<Action> prodActionsList = new ArrayList<Action>();
        ArrayList<Action> stActionsList = new ArrayList<Action>();
        ArrayList<Action> unActionsList = new ArrayList<Action>();

        int donePieces = 0;
        for (Activity currActivity : day.getDayActivityList()) {

            if (currActivity instanceof ActivityTransportToMachines) {
                ActivityTransportToMachines act = (ActivityTransportToMachines) currActivity;
                prodActionsList.addAll(actProdToActions(act));

            }

            else if (currActivity instanceof ActivitySwitchTools) {

                ActivitySwitchTools act = (ActivitySwitchTools) currActivity;
                stActionsList.add(actSwitchToolsToActions(act));

            }

            else if (currActivity instanceof ActivitySupplies) {
                ActivitySupplies act = (ActivitySupplies) currActivity;
                actionList.add(actSuppliesToActions(act));
            } else if (currActivity instanceof ActivityUnloading) {
                ActivityUnloading act = (ActivityUnloading) currActivity;
                unActionsList.add(actUnToActions(act));
                donePieces = act.getNumberOfPieces();

            }

            else if (currActivity instanceof ActivityProduction) {
                continue;
            } else {
                throw new Exception("No valid instance of activity");
            }
        }

        actionList.addAll(prodActionsList);
        actionList.addAll(stActionsList);
        actionList.addAll(unActionsList);

        if (actionList.isEmpty()) {
            throw new IllegalArgumentException("Created action list is empty");
        }

        int orderId = day.getDayActivityList().get(0).getOrderId();
        String status = day.getDayActivityList().get(0).getActivityType().toString();

        if (status == "supplies") {
            status = "waiting";
        }

        insertActionInTimelines(actionList);
        int totalPieces = t.getTotalPiecesOrderStatusDataFromDatabase(orderId);
        int producedPieces = t.getProducedPiecesOrderStatusDataFromDatabase(orderId);
        producedPieces += donePieces;
        int pendingPieces = totalPieces - producedPieces;

        OrderStatusGUI order = new OrderStatusGUI(orderId, status, producedPieces, pendingPieces, totalPieces, 0);
        ArrayList<OrderStatusGUI> qwerty = new ArrayList<>();
        qwerty.add(order);

        t.addOrderStatus(qwerty);

        FactoryTimeFormat timeline1EndTime = this.productionTimeline.getLastActionEndTime();
        FactoryTimeFormat timeline2EndTime = this.switchToolsTimeline.getLastActionEndTime();

        if (timeline1EndTime.toSeconds() > timeline2EndTime.toSeconds()) {
            return timeline1EndTime;
        }

        return timeline2EndTime;
    }

    public void execute(FactoryTimeFormat currentTime) throws ExecutionException, InterruptedException, UaException {
        // if (Machine_Paths.Init.x)
        if (isPathAvailableCodesysVar.readBoolean() == 1) {
            productionTimeline.execute(currentTime);
            switchToolsTimeline.execute(currentTime);
        }
    }

    public String toString(int dayNumber) throws Exception {

        // int dayNumber = this.day.getCurrDay();
        StringBuilder sb = new StringBuilder();

        sb.append("\nDay " + dayNumber + ":\n\n");
        sb.append(Timeline.upperScale() + '\n');

        sb.append(productionTimeline.dayString(dayNumber) + '\n');
        sb.append(switchToolsTimeline.dayString(dayNumber) + '\n');

        sb.append(Timeline.downScale() + '\n');

        return sb.toString();

    }

    private ArrayList<Action> actProdToActions(ActivityTransportToMachines activity) {

        ArrayList<Action> actionsList = new ArrayList<Action>();

        int pathNumber = activity.getNeededTool().toInt();
        int StartTypeNumber = activity.getNextTransitionStartType().toInt();
        int unsignedPieces = activity.getNumberOfPieces();

        while (unsignedPieces > 0) {
            ActionPath actionPath;
            Action action;
            int numberOfPiecesInAction = 0;

            switch (pathNumber) {
                case 2:
                    numberOfPiecesInAction = Math.min(unsignedPieces, 2);
                case 3:
                    numberOfPiecesInAction = Math.min(unsignedPieces, 4);
                    break;
                default:
                    numberOfPiecesInAction = Math.min(unsignedPieces, 3);
                    break;
            }

            unsignedPieces -= numberOfPiecesInAction;
            if (numberOfPiecesInAction > 0) {
                actionPath = new ActionPath(pathNumber, StartTypeNumber, numberOfPiecesInAction);
                action = new Action(actionPath, activity.getStartTime());
                actionsList.add(action);
            }
        }
        return actionsList;
    }

    private Action actSwitchToolsToActions(ActivitySwitchTools activity) {

        int toolNumber = activity.getDesiredTool().toInt();

        switch (toolNumber) {
            case 1:
                return new Action(ActionSwitchTools.toTool1, activity.getStartTime());
            case 2:
                return new Action(ActionSwitchTools.toTool2, activity.getStartTime());
            case 3:
                return new Action(ActionSwitchTools.toTool3, activity.getStartTime());
            case 4:
                return new Action(ActionSwitchTools.toTool4, activity.getStartTime());

            default:
                break;
        }
        return null;
    }

    private Action actUnToActions(ActivityUnloading activity) {
        int pathNumber = 6;
        int StartTypeNumber = activity.getPieceType().toInt();
        int numberOfPiecesInAction = activity.getNumberOfPieces();
        ActionPath actionPath = new ActionPath(pathNumber, StartTypeNumber, numberOfPiecesInAction);

        return new Action(actionPath, activity.getStartTime());
    }

    public Action actSuppliesToActions(ActivitySupplies activity) {

        int pieceTypeNumber = activity.getPieceType().toInt();

        if (pieceTypeNumber != 1 && pieceTypeNumber != 2) {
            throw new IllegalArgumentException(
                    "Invalid activities supplies piece type\nRecieved piece type " + pieceTypeNumber);
        }

        ActionPath actionPath = new ActionPath(5, pieceTypeNumber, activity.getNumberOfPieces());

        Action action = new Action(actionPath, activity.getStartTime());

        return action;
    }

    public ArrayList<Action> getActionsList() {
        return this.switchToolsTimeline.getActionsList();
    }

    public static void main(String[] args) throws Exception {

        // MesScheduler sc = new MesScheduler();
        // sc.insertNewDay(Day.produceT7_test(), new FactoryTimeFormat(1, 0));

        // MesScheduler

        // System.out.println(sc.toString(0));
        // System.out.println(sc.toString(1));
        // System.out.println(sc.toString(2));

        OpcUaCodesysClient isPathAvailableCodesysVar = new OpcUaCodesysClient("waiting", "Machine_Paths");
        System.out.println(isPathAvailableCodesysVar.getIdentifier());
        System.out.println(isPathAvailableCodesysVar.readBoolean());

    }
}
