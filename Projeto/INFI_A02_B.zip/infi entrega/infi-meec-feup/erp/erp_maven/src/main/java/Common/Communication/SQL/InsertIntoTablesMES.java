package Common.Communication.SQL;

import Common.Communication.SQL.DataBase;
import Erp.Gui.OrderCostGUI;
import Mes.Gui.MachineStatsGUI;
import Mes.Gui.OrderStatusGUI;
import Mes.Gui.UnloadingStatsGUI;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class InsertIntoTablesMES extends DataBase {

    public boolean addOrderStatus(ArrayList<OrderStatusGUI> orderStatusGUI) {
        Connection c = null;
        Statement st = null;

        c = super.connect();
        if (c == null)
            return false;

        try {

            OrderStatusGUI order = orderStatusGUI.get(0);

            String updateQuery = "UPDATE \"INFI\".\"OrderStats\" SET status = '" + order.getStatus()
                    + "', producedpieces = " + order.getProducedPieces() + ", pendingpieces = "
                    + order.getPendingPieces()
                    + " WHERE orderid = " + order.getOrderID() + ";";

            st = c.createStatement();
            st.executeUpdate(updateQuery);

        } catch (Exception e) {
            System.out.println(e.getMessage());

            return false;
        }
        return true;
    }

    public boolean addMachineStats(ArrayList<MachineStatsGUI> machineStatsData, int machineNumber) {
        Connection c = null;
        Statement st = null;

        c = super.connect();
        if (c == null)
            return false;

        try {
            String deleteQuery = "DELETE FROM \"INFI\".\"MachineStats\" WHERE machineNumber = " + machineNumber + ";";
            st = c.createStatement();
            st.executeUpdate(deleteQuery);

            for (int i = 0; i < machineStatsData.size(); i++) {
                MachineStatsGUI order = machineStatsData.get(i);

                String query = "INSERT INTO \"INFI\".\"MachineStats\" (\"machinenumber\", \"piecetype\", \"numberpieces\") VALUES ('"
                        + machineNumber + "', '" + order.getPieceType() + "', '" + order.getPieceNumber() + "');";
                st = c.createStatement();
                st.executeUpdate(query);
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());

            return false;
        }
        return true;
    }

    public boolean addUnloadingStats(ArrayList<UnloadingStatsGUI> unloadingStatsData, int unloadingDockNumber) {
        Connection c = null;
        Statement st = null;

        c = super.connect();
        if (c == null)
            return false;
        try {
            String deleteQuery = "DELETE FROM \"INFI\".\"UnloadingStats\"WHERE unloadingdocknumber = "
                    + unloadingDockNumber + ";";
            st = c.createStatement();
            st.executeUpdate(deleteQuery);

            for (int i = 0; i < unloadingStatsData.size(); i++) {
                UnloadingStatsGUI order = unloadingStatsData.get(i);

                String query = "INSERT INTO \"INFI\".\"UnloadingStats\" (\"unloadingdocknumber\", \"piecetype\", \"numberunloadedpieces\") VALUES ('"
                        + unloadingDockNumber + "', '" + order.getPieceType() + "', '" + order.getPieceNumber() + "');";
                // String query = "INSERT INTO \"INFI\".\"UnloadingStats\"
                // (\"unloadingdocknumber\", \"piecetype\", \"numberunloadedpieces\") VALUES ('"
                // + "1" + "', '" + "P1" + "', '" + "2" + "');";

                st = c.createStatement();
                st.executeUpdate(query);
            }

        } catch (Exception e) {
            System.out.println(e.getMessage());

            return false;
        }
        return true;
    }

    public boolean addWarehouse(int pieceNumber) {
        Connection c = null;
        Statement st = null;

        c = super.connect();
        if (c == null)
            return false;

        try {
            String deleteQuery = "DELETE FROM \"INFI\".\"warehouse\";";
            st = c.createStatement();
            st.executeUpdate(deleteQuery);

            String query = "INSERT INTO \"INFI\".\"warehouse\" (\"warehousestoredpieces\") VALUES ('"
                    + pieceNumber + "');";
            st = c.createStatement();
            st.executeUpdate(query);

        } catch (Exception e) {
            System.out.println(e.getMessage());

            return false;
        }
        return true;
    }

    public boolean addMachineTime(int machineNumber, int totalOperationTime) {
        Connection c = null;
        Statement st = null;

        c = super.connect();
        if (c == null)
            return false;

        try {
            String deleteQuery = "DELETE FROM \"INFI\".\"machinetime\" WHERE machineNumber = " + machineNumber;
            st = c.createStatement();
            st.executeUpdate(deleteQuery);

            String query = "INSERT INTO \"INFI\".\"machinetime\" (\"machinenumber\", \"totaloperationtime\") VALUES ('"
                    + machineNumber + "', '" + totalOperationTime + "');";
            st = c.createStatement();
            st.executeUpdate(query);

        } catch (Exception e) {
            System.out.println(e.getMessage());

            return false;
        }
        return true;
    }

    public boolean addUnloadingDockTime(int unloadingDockNumber, int unloadedPieces) {
        Connection c = null;
        Statement st = null;

        c = super.connect();
        if (c == null)
            return false;

        try {
            String deleteQuery = "DELETE FROM \"INFI\".\"unloadingdocktotal\" WHERE unloadingdocknumber = "
                    + unloadingDockNumber;
            st = c.createStatement();
            st.executeUpdate(deleteQuery);

            String query = "INSERT INTO \"INFI\".\"unloadingdocktotal\" (\"unloadingdocknumber\", \"totalunloadedpieces\") VALUES ('"
                    + unloadingDockNumber + "', '" + unloadedPieces + "');";
            st = c.createStatement();
            st.executeUpdate(query);

        } catch (Exception e) {
            System.out.println(e.getMessage());

            return false;
        }
        return true;
    }

    public int getTotalPiecesOrderStatusDataFromDatabase(int orderID) {

        Connection c = null;
        Statement st = null;
        ResultSet rs = null;

        c = super.connect();
        if (c == null)
            return -1;

        int totalPieces = 0;

        try {
            st = c.createStatement();
            String query = "SELECT totalpieces FROM \"INFI\".\"OrderStats\" WHERE orderid = " + orderID + ";";
            rs = st.executeQuery(query);

            while (rs.next()) {
                totalPieces = rs.getInt("totalpieces");

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return totalPieces;
    }

    public int getProducedPiecesOrderStatusDataFromDatabase(int orderID) {

        Connection c = null;
        Statement st = null;
        ResultSet rs = null;
        int producedPieces = 0;

        c = super.connect();
        if (c == null)
            return -1;

        try {
            st = c.createStatement();
            String query = "SELECT producedpieces FROM \"INFI\".\"OrderStats\" WHERE orderid = " + orderID + ";";
            rs = st.executeQuery(query);

            while (rs.next()) {
                producedPieces = rs.getInt("producedpieces");

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return producedPieces;
    }
}
