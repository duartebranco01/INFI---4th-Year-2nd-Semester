package Mes.Gui;

import Erp.Gui.HelloApplication;

public class RunMES {

    public static void main(String[] args) throws Exception {

        MesGui.startGUI();

    }
}
