package Mes.Action.ActionType;

import Common.Suppliers.SupplierType;
import Common.TimeCounting.FactoryTimeFormat;

public enum ActionSupplies implements ActionType {

    SpA(SupplierType.A),
    SpB(SupplierType.B),
    SpC(SupplierType.C);

    SupplierType supplier;

    ActionSupplies(SupplierType supplier) {
        this.supplier = supplier;
    }

    public void execute() {
        return;
    }

    public FactoryTimeFormat getDuration() {
        return FactoryTimeFormat.toFactoryTimeFormat(supplier.getSupplierTime());
    }

    public String getName() {
        return supplier.toString();
    }

    public String toString() {
        return null;
    }

}
