package Erp.OrderInfo;

import java.io.Serializable;
import java.util.ArrayList;

import Common.Piece.Piece;
import Common.Piece.PieceType;
import Common.Piece.Transition;

public class OrderInfo implements Serializable {
    private String clientName;
    private int number;
    private PieceType finalType;
    private int quantity;
    private int dueDate;
    private int latePen;
    private int earlyPen;

    ArrayList<Piece> pieceList;

    public OrderInfo(String clientName, int orderNumber, PieceType finalType, int quantity, int dueDate, int latePen,
            int earlyPen) {
        this.clientName = clientName;
        this.number = orderNumber;
        this.finalType = finalType;
        this.quantity = quantity;
        this.dueDate = dueDate;
        this.latePen = latePen;
        this.earlyPen = earlyPen;

        decomposeOrderByPieces();

    }

    public static OrderInfo getTestObj() {

        return new OrderInfo("Client BB", 0042, PieceType.P8, 3, 4, 10, 5);

    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Client Name: ").append(clientName).append("\n");
        sb.append("Order Number: ").append(number).append("\n");
        sb.append("Final Type: ").append(finalType).append("\n");
        sb.append("Quantity: ").append(quantity).append("\n");
        sb.append("Due Date: ").append(dueDate).append("\n");
        sb.append("Late Penalty: ").append(latePen).append("\n");
        sb.append("Early Penalty: ").append(earlyPen).append("\n");

        return sb.toString();
    }

    public ArrayList<Piece> decomposeOrderByPieces() {
        ArrayList<Piece> pieceList = new ArrayList<>();

        int pieceDueDate = dueDate;

        for (int i = 0; i < getQuantity(); i++) {
            int pieceId = this.number * 100 + i;

            Piece currentPiece = new Piece(this.number, pieceId, pieceDueDate, this.finalType);

            pieceList.add(currentPiece);
        }

        setPieceList(pieceList);

        return pieceList;
    }

    public int getNumber() {
        return this.number;
    }

    public void setClientNameId(String incoming) {
        this.clientName = incoming;
    }

    public PieceType getFinalType() {
        return this.finalType;
    }

    public int getDueDate() {
        return this.dueDate;
    }

    public int getQuantity() {
        return this.quantity;
    }

    public int getLatePen() {
        return this.latePen;
    }

    public ArrayList<Piece> getPieceList() {
        return this.pieceList;
    }

    public void setPieceList(ArrayList<Piece> pieceList) {
        this.pieceList = pieceList;
    }

    public ArrayList<Transition> orderedTransitionsList() {
        ArrayList<Transition> concatenatedTransitions = new ArrayList<>();

        ArrayList<Piece> pieces = getPieceList();
        for (Piece piece : pieces) {
            ArrayList<Transition> transitions = piece.getOrderedTransitionsList();
            concatenatedTransitions.addAll(transitions);
        }

        // Sort the concatenated transitions by TransitionPriority using QuickSort
        quickSort(concatenatedTransitions, 0, concatenatedTransitions.size() - 1);

        return concatenatedTransitions;
    }

    private void quickSort(ArrayList<Transition> arr, int left, int right) {
        if (left < right) {
            int pivotIndex = partition(arr, left, right);
            quickSort(arr, left, pivotIndex - 1);
            quickSort(arr, pivotIndex + 1, right);
        }
    }

    private int partition(ArrayList<Transition> arr, int left, int right) {
        int pivotIndex = (left + right) / 2;
        Transition pivotValue = arr.get(pivotIndex);

        swap(arr, pivotIndex, right);

        int storeIndex = left;
        for (int i = left; i < right; i++) {
            if (arr.get(i).getPriorityInPiece() <= pivotValue.getPriorityInPiece()) {
                swap(arr, i, storeIndex);
                storeIndex++;
            }
        }

        swap(arr, storeIndex, right);

        return storeIndex;
    }

    private void swap(ArrayList<Transition> arr, int i, int j) {
        Transition tmp = arr.get(i);
        arr.set(i, arr.get(j));
        arr.set(j, tmp);
    }
}
