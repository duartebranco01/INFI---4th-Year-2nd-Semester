package MasterProductionPlan;

import Common.Machine.ToolType;
import Common.Piece.Piece;
import Common.Piece.PieceType;

import java.util.ArrayList;

public class ActivityTransportToMachines extends Activity {

    private ArrayList<Piece> piecesToTransportToMachines;
    private int currTransitionIndex;
    private Piece auxPiece;

    public ActivityTransportToMachines(ActivityType activityType, int activityStartTime, int activityEndTime,
            int activityDuration,
            int orderId, int day, ArrayList<Piece> piecesToTransportToMachines, int currTransitionIndex) {

        super(activityType, activityStartTime, activityEndTime, activityDuration, orderId, day);
        this.piecesToTransportToMachines = piecesToTransportToMachines;
        this.currTransitionIndex = currTransitionIndex;
        this.auxPiece = this.piecesToTransportToMachines.get(0);
    }

    public ArrayList<Piece> getPiecesToTransportToMachines() {
        return piecesToTransportToMachines;
    }

    public void setPiecesToTransportToMachines(ArrayList<Piece> piecesToTransportToMachine) {
        this.piecesToTransportToMachines = piecesToTransportToMachine;
    }

    public String toString() {
        return super.toString()
                + "\t PieceType: "
                + piecesToTransportToMachines.get(0).getOrderedTransitionsList().get(currTransitionIndex).getStartType()
                + "->"
                + piecesToTransportToMachines.get(0).getOrderedTransitionsList().get(currTransitionIndex).getFinalType()
                + '\n'
                + "\t Transported pieces: " + this.piecesToTransportToMachines.size() + "\n";
        // + this.piecesFromSupplier.toString() + "\n";
    }

    public int getCurrTransitionIndex() {
        return this.currTransitionIndex;
    }

    /**
     * Auxiliary method
     * Needed to create production action
     * 
     * @return number of pieces to produce
     */
    public int getNumberOfPieces() {
        return this.piecesToTransportToMachines.size();
    }

    /**
     * Auxiliary method
     * Needed to create production action
     * 
     * @return the needed tool to performe the next transition
     */
    public ToolType getNeededTool() {
        return auxPiece.getOrderedTransitionsList().get(currTransitionIndex).getNeededTool();
    }

    /**
     * Auxiliary method
     * Needed to create production action
     * 
     * @return the start type for the next transition
     */
    public PieceType getNextTransitionStartType() {
        return auxPiece.getOrderedTransitionsList().get(this.getCurrTransitionIndex()).getStartType();
    }
}
