package Mes.Action.ActionType;

import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

import org.eclipse.milo.opcua.stack.core.UaException;

import Common.Communication.OpcUa.OpcUaCodesysClient;
import Common.Constants.TimeConstants;
import Common.TimeCounting.FactoryTimeFormat;

public class ActionPath implements ActionType {

    // Route options
    private int numberOfPieces;
    private int pieceIntialTypeNumber;
    private int pathNumber;

    OpcUaCodesysClient pathVarClient;
    OpcUaCodesysClient pieceTypeVarClient;
    OpcUaCodesysClient numPieceVarClient;

    private String name;
    private FactoryTimeFormat duration;

    public ActionPath(int pathNumber, int pieceIntialTypeNumber, int numberOfPieces) {

        if (pathNumber > 6) {
            throw new IllegalArgumentException("Invalid path number");
        }

        if (pathNumber == 5) {
            this.name = "Supplies";
        } else if (pathNumber == 6) {
            this.name = "Unloading";
        } else {
            this.name = "Machining with tool " + String.valueOf(pathNumber);
        }

        this.pathNumber = pathNumber;
        this.pieceIntialTypeNumber = pieceIntialTypeNumber;
        this.numberOfPieces = numberOfPieces;

        this.pathVarClient = new OpcUaCodesysClient("path", "PLC_PROG");
        this.pieceTypeVarClient = new OpcUaCodesysClient("piece_type", "PLC_PROG");
        this.numPieceVarClient = new OpcUaCodesysClient("num_piece", "PLC_PROG");

    }

    public FactoryTimeFormat getDuration() {
        switch (this.pathNumber) {
            case 1:
                return new FactoryTimeFormat(0, TimeConstants.path1);
            case 2:
                return new FactoryTimeFormat(0, TimeConstants.path2);
            case 3:
                return new FactoryTimeFormat(0, TimeConstants.path3);
            case 4:
                return new FactoryTimeFormat(0, TimeConstants.path4);
            case 5:
                return new FactoryTimeFormat(0, TimeConstants.path5);
            case 6:
                return new FactoryTimeFormat(0, TimeConstants.path6);
        }

        return this.duration;
    }

    public String getName() {
        return this.name;
    }

    // TODO
    public void execute() {
        try {
            pieceTypeVarClient.writeInt(pieceIntialTypeNumber);
            numPieceVarClient.writeInt(numberOfPieces);
            pathVarClient.writeInt(pathNumber);
        } catch (ExecutionException | InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("pathNumber: ").append(pathNumber)
                .append(", pieceIntialTypeNumber: ").append(pieceIntialTypeNumber)
                .append(", numberOfPieces: ").append(numberOfPieces);
        return sb.toString();
    }
}
