package Common.Constants;

import org.bouncycastle.jcajce.provider.asymmetric.dsa.DSASigner.stdDSA;

public class TimeConstants {
    public final static int path1 = 30;
    public final static int path2 = 30;
    public final static int path3 = 30;
    public final static int path4 = 30;
    public final static int path5 = 30;
    public final static int path6 = 30;

    public final static int transportTimeMachine1 = 8;
    public final static int transportTimeMachine2 = 9;
    public final static int transportTimeMachine3 = 11;
    public final static int transportTimeMachine4 = 12;

    public final static int warehouseTimeMachine1 = 9;
    public final static int warehouseTimeMachine2 = 8;
    public final static int warehouseTimeMachine3 = 19;
    public final static int warehouseTimeMachine4 = 22;

    public final static int suppliesTrasnportTime = 20;

    public final static int productionTransportTimeToMachines = 5;
    public final static int productionTransportTimeBackToWarehouse = 5;

    public final static int unloadingTransportTime = 10;

    public final static int poppingOutWarehouse = 4;
    public final static int poppingInWarehouse = 0;

    public final static int poppingInSupplies = 2;

    public final static int poppingInUnloading = 2;

    public static int switchToolsTime = 30;

    public static int getSuppliesTransportTime() {
        return suppliesTrasnportTime;
    }

    public static int getProductionTransportTimeBackToWarehouse() {
        return productionTransportTimeBackToWarehouse;
    }

    public static int getUnloadingTransportTime() {
        return unloadingTransportTime;
    }

    public static int getPoppingOutWarehouse() {
        return poppingOutWarehouse;
    }

    public static int getPoppingInWarehouse() {
        return poppingInWarehouse;
    }

    public static int getPoppingInSupplies() {
        return poppingInSupplies;
    }

    public static int getPoppingInUnloading() {
        return poppingInUnloading;
    }

    public static int getProductionTransportTimeToMachines() {
        return productionTransportTimeToMachines;
    }
}
